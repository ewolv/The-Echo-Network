# Fire Echos S1 — Fresh results summary

This file summarizes actual local executions accompanying the 23-page white paper. It is not a production-security certificate or a financial forecast. Complete counts and exact amounts are in `results/`.

| Evidence | Fresh execution | Result and scope |
|---|---|---|
| E1 — `v5_fresh_rerun.json` | Original 16-group v5 suite, mixed seed 20260926 | PASS; 1,800 paid jobs; 469 EXECUTE / 1,331 DELIVER; 63 tampered receipts and 44 subquorum preparations rejected; 19 rollback/retry cases; exact final Fire [1,0], 3,673 live notes, zero pending jobs. |
| E2 — `v5_reward_rerun.json` | Unchanged reward audit rerun | Counterexample reproduced. Equal-price jobs: old gross-fee share 66.40625%. Targeted variable-price jobs: old 256 fee units, young 33,153; old share 0.7662606%, despite old receiving more jobs. |
| E3 — `symbolic_results.json` | SymPy computer algebra and finite enumeration | PASS; 12 recorded zero-residual identities; 256 Boolean functions across eight inputs = 2,048 outcomes; 9,280 old/new/age transitions; 98,304 signed-cube relabeling round trips; quorum pairs enumerated. |
| E4 — `s1_results.json` | New integrated fixed-ticket, continuation, reuse, courier and mixed suite | PASS; 1,024 targeted-price tickets allocated old 682 / young 342, giving old 66.6015625% of measured gross speaker fees; 32 tickets carried a 256-transition computation; 128 repeated requests used only eight worker-plus-listener transitions; 800 additional mixed tickets; 600 signed courier payments. |
| E5 — `s1_seed2.json` | Independent mixed seed 20260929 | PASS; 600 tickets; 71 EXECUTE / 529 DELIVER; 21 bad receipts and 15 subquorum preparations rejected; seven rollback/retry cases; exact final Fire [1,0], zero pending. |
| E6 — `boolean_bridge_results.json` | Frozen Boolean-program bridge | PASS; 2,048 compiled finite-board executions; eight funded inputs on one unchanged parity program gave outputs 0,1,1,0,1,0,0,1; exact final Fire [1,0]. |

## Headline totals and controls

The listed S1 service experiments total **2,592 paid service tickets**: 1,024 targeted-income + 160 continuation/reuse + 1,400 mixed + eight Boolean-bridge tickets. This excludes setup transfers, one separate deterministic safety ticket and the separate **600 courier payments**. The original baseline's 1,800 jobs are reported separately.

The 600 courier payments created **2,401 courier outputs**. Twenty bad recipient acceptances, 17 subquorum attempts and 14 replays were rejected. Only one accepted, sender-capped, recipient-signed chain is paid from each input. Copied offers do not create new money.

A 64-way fracture caused **zero owner-allocation changes over 8,192 fixed-snapshot coordinates**. One hundred regroupings of the same 4,096-ticket sequence also left allocation unchanged. These controls do not establish immunity to changing membership, strategic availability or Sybil topology.

Every independent completed S1 monetary workload retained exact total Fire `[1,0]` and zero pending jobs. Negative tests may intentionally retain reserved state; absence of mutation is not the same as successful delivery or progress.

## What the iteration changed

The original v5 rule allocated one scheduling turn per variable-price job. S1 instead allocates one fixed-price reservation for at most eight verified machine transitions or one certified-result delivery. This corrected the measured job-share/fee-share failure under the tested stable tariff and eligibility conditions. It does not guarantee profit: in the targeted S1 case the old worker performed one new transition while the young worker performed 2,736. Gross revenue and physical costs differ.

The age rule is `M = w[1 + sum_i(1 - phi^(-min(age_i,144)))/3]`, with `w <= M < 2w`. Changing one bit forfeits only its part of this bounded priority. The rule is increasing but concave before its cap. Symbolic analysis rejected an unbounded quadratic monetary change levy and documented a bounded, nonimplemented alternative.

## Evidence limits

These experiments use a trusted local reducer, real signatures with public deterministic TEST keys, exact phi arithmetic, local SQLite transactions, modeled contact graphs and a fixed seven-witness abstraction. They do not establish production Byzantine consensus, secure physical time, independent identity, real network performance, live-money safety, increasing market purchasing power or universal immunity to attacks. A fully general claim that every adversary switches off the whole physical network before corruption is not supported.

The white paper separates algebraic proof, exhaustive finite-domain checks, randomized modeled workloads and outstanding deployment conditions.
