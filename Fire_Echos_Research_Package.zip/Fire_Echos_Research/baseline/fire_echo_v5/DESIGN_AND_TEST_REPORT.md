# Fire Echo φ Paper v5
## Preserved choices, funded execution, reusable history

Concept: Eric James Wolverton. Executable research iteration and measured results, 6 September 2026.

**Research-only software. All included signing keys are publicly derivable test keys. Do not use them for actual money. This is a local protocol model, not deployed peer-to-peer infrastructure or full Byzantine consensus.**

## 1. The operational connection

The paper is one immutable accounting state within a linked computation-and-service graph. Its three choices are persistent dispatch policies. Their certified ages give its existing principal a bounded service-selection weight. Allocated work is funded before it runs. A speaker computes a bounded Turing-machine quantum, and a listener checks it. A checked result and its receipt become immutable history. An atomic settlement pays existing Fire and renews the service papers. The next request can continue the machine or reuse an already-certified result.

```text
three persistent policies
        ↓ certified age
exact Fire-weighted service allocation
        ↓ funded request
execute / retrieve → check / authenticate → signed return postcard
        ↓ atomic settlement
new paper heads + young fee papers + reusable checked result
        ↓
same money-backed service ports, next authorized computation
```

The important separation is between **age**, **knowledge**, and **principal**. Age is protocol seniority. A retained checked result is reusable knowledge. Fire is conserved principal. None is silently substituted for another.

The earlier v4 already linked choice age to actually paid Turing work. v5 does not present that as a new discovery. It adds a distinct reusable-result identity, single-use payment identity, stable paper-derived routing ports, exact dependency checks, and atomic persistence of result knowledge with settlement.

## 2. What the three choices mean

| Choice | Implemented dispatch policy |
|---|---|
| Inside / outside | Offer service to the same requester key / a different requester key. |
| East / west | Route through cached logical contacts in increasing / decreasing hash direction. |
| Speak / listen | Propose an execution or deliver a certified result / replay-check or authenticate the result. |

All eight combinations were exercised. These are not claims about physical compass directions, confidentiality, independent human identities, or the truth of arbitrary statements.

The policies do not replace the Turing machine's control state, head, program and tape. Reading, writing and moving the tape head do not reset service-policy ages. Otherwise a nontrivial execution would destroy the very continuity it is meant to value.

Changing a bit under the same owner pays a fee and resets only that clock. Two unchanged clocks survive. Ownership transfer resets all three clocks. Service renewal preserves all three clocks. A newly earned fee paper starts young. Same-owner fracture distributes the existing principal without duplicating its aggregate seniority weight.

Under the project's time convention, committed choice origins, execution receipts and checked results are the past; the bounded checked transition is the present; authorized continuations and possible future policy changes remain future variables. This convention makes no claim about changing physical history.

## 3. Age has an exact, bounded operational value

For paper p with principal w and certified epoch t:

```text
a_i = t - since_i
h_i = 1 - φ^(-min(a_i,144))
M(p,t) = w × (1 + (h_1+h_2+h_3)/3)
```

The multiplier is in [1,2). The allocator actually uses W=3M, avoiding division:

```text
W(p,t) = w × (6 - Σ_i φ^(-min(a_i,144)))
```

Its arithmetic and comparisons use exact pairs a+bφ, with φ²=φ+1. Floating point is not used to authorize spending or choose a scheduling branch. The 144-epoch cap and twofold limit are chosen engineering policy, not natural constants. Epochs are supplied by the harness and sequentially certified; no secure physical-time service is implemented.

Each note owns a disjoint half-open interval [lo,hi) of the original [0,1) Fire interval. Its amount is hi-lo. A split uses w = wφ^-1 + wφ^-2. Because service weight is linear in principal:

```text
W(parent,t) = W(child_1,t) + W(child_2,t)
```

for unchanged policies, age and owner. The sum tree orders offered intervals by genesis position and stores exact subtree weights. Selection is a descent through those weights using a deterministic reserved scheduling coordinate. For a fixed eligible snapshot, inserting split boundaries does not change the owner covering that coordinate.

Measured: splitting one service interval into 64 descendants produced **0 owner-selection differences across 4,096 scheduling coordinates**. This checks fixed-snapshot allocation, not every possible strategy involving changing membership, job timing, identities or topology.

Old-versus-young equal principal selected 2,731 old and 1,365 young slots out of 4,096. This approaches the 2:1 ratio deliberately specified by the policy. It is not evidence that physical hardware became twice as fast.

## 4. The data structure contains the executable loop

The fixed interpreter reads an explicit transition table:

```text
δ(control_state, read_symbol) = (next_state, write_symbol, L/R/S)
```

The finite table is canonicalized by sorting transition keys and halt states. Reordering equivalent rows does not create a new result identity. General semantic equivalence of arbitrary Python programs is not being decided.

Programs, initial states, bounded execution results, authorizations, postcards, settlements and paper heads are canonical content-addressed objects. The interpreter and implementation are pinned by the protocol manifest. The result's final state can become the next request's initial state. Successful program completion is HALTED; successful exhaustion of a quantum with work remaining is SUSPENDED. A protocol rejection is a separate failure outcome.

The Lion Lens remains concrete: reflection of tape coordinates i→-i, together with swapping L/R in the transition table, transports the execution. The inherited regression suite again checked 500 random-program reflection cases and 325 stop/resume cases. This is an explicit bijection test, not a universal claim that different computations mean the same thing.

Here CAS means **content-addressed storage**. Exact φ arithmetic and the finite program canonicalizer are implemented; an unrestricted computer-algebra engine is not.

A data structure does not execute without an interpreter and a machine. The implemented relationship is reciprocal in a precise sense: the table is executable data, execution produces checked data, and that data determines which successor wallet and service state can exist.

## 5. Reuse the result; never reuse a payment authorization

v5 gives an immutable checked result its own key:

```text
result_key = H(VM_id, authorization_namespace, program_id,
               full_initial_state_id, quantum_budget)
```

The payment job has a different identity. It additionally commits to the funding input, selected current service heads, epoch, snapshot, reserved slot, quote and routing paths. One result may answer several independently authorized requests. One job may settle only once.

A **checked-result capsule** contains the result's exact dependencies, final state, logical step count, trace hash and HALTED/SUSPENDED status. On the first request, the speaker executes and the listener replays. The fixed witness model certifies the validated capsule. Its certificate is scoped to the result key and capsule hash. The capsule, certificate index and money settlement become visible in the same SQLite transaction.

On a repeated identical request, the program retrieves the capsule, verifies its content hashes and its existing authorized certificate, and binds it to a new funded delivery receipt. No TM transitions are falsely represented as newly executed. This is certificate-backed reuse under the stated fixed-committee/trusted-validator model, not proof that remote hardware performed fresh cycles and not a succinct cryptographic computation proof.

Two quoted service modes are explicit:

```text
EXECUTE: fee = delivery_price + price_per_new_step × replay-verified steps
DELIVER: fee = delivery_price; newly executed TM steps = 0
```

The demonstration uses φ^-32 Fire for each new step and φ^-32 Fire for one bounded result delivery. The speaker receives fee×φ^-1 and the listener receives fee×φ^-2. Their sum equals the fee exactly. These are test tariffs, not a realistic market quote covering every hardware, storage, network, cancellation and denial-of-service cost.

A changed input, program, VM, scope namespace or quantum budget cannot borrow an unrelated result. A changed east/west route does not change a deterministic computation's mathematical input, so the old checked result remains reusable; only the route clock resets. Inside namespaces are not aliases for public results, but the model is not encrypted storage.

A young paper is allowed to use a public checked result. Artificially withholding reusable knowledge to make old paper look valuable would not demonstrate computational efficiency. Seniority and publicly reusable knowledge are intentionally separate.

## 6. Preserve a service address while its state changes

The previous live-note-hash-only address changed at every successful service renewal. Cached peers then held obsolete addresses unless the simulator rebuilt their membership view. The negative control reproduced this failure with the actual v4 source.

v5 keeps the immutable paper state ID and derives a separate service port from the paper itself:

```text
state_id = H(canonical_current_paper)
port_id  = H(root_id, owner_id, right_interval_boundary)
```

Paying fees from the left edge of the payer interval preserves its right boundary. A speaker/listener renewal preserves the full service interval. Normal settlement therefore changes state IDs while preserving the relevant ports. Fracture or ownership changes can introduce new ports; those require explicit joining/discovery rather than appearing magically in every peer's contacts.

Port updates are accepted from committed transitions: input consumption, output construction, the certificate, and current live output heads are checked. A port is not permission to serve a stale or already-spent head. The tests kept each existing cached neighbor table unchanged through normal job settlement, while publishing new certified heads locally.

The logical service overlay is backed by money-state identities. Physical processors, network links, transport addresses and storage still have to exist. One owner can host many papers; many paper vertices do not demonstrate many independent people or machines. The main simulation uses a local ledger/CAS and supplied initial contacts, not distributed discovery or distributed data replication.

## 7. Measured results from this turn

### A. Actual fee income from aged choices

Two equal-principal speaker papers competed at epoch 21, one with ages (21,21,21), the other with (0,0,0). A synthetic repeated-request workload issued 384 funded requests.

| Measurement | Older choices | Newer choices |
|---|---:|---:|
| Allocated and paid requests | 255 | 129 |
| Speaker fee income, Fire | 0.0000828554447827 | 0.0000369233299108 |

There were 32 first computations and 352 certified-result deliveries. The requester funded the fees, listeners were separately paid, and exact total Fire ended at [1,0]. The measurement demonstrates the specified earning-opportunity mechanism. It is not a guaranteed income forecast; different demand, request costs, availability and competitor states can change income. Frozen deterministic slots are not a universal fairness guarantee for unequal job costs or strategic requester timing.

### B. Useful retained computation

For 128 identical requests, each representing a 32-transition calculation:

| Measurement | Without result reuse | v5 reuse |
|---|---:|---:|
| Speaker + listener TM transitions | 8,192 | 64 |
| First computations | 128 | 1 |
| Cached result deliveries | 0 | 127 |
| Neighbor-table rebuilds in v5 | — | 0 |

The reduction in interpreter transitions was **99.21875%**. Under the demonstration tariff, fee units fell from 4,224 to 160, a **96.2121%** reduction. Neither figure is a wall-clock speedup or a real-world price forecast. Hashing, signature verification, database transactions, result transmission and cache retention still cost resources. A workload with no matching requests gets no result-cache hits.

The cold-computation negative control required 16 steps at ages 0, 21 and 144. Aging alone did not make a program execute faster.

### C. Mixed workloads after the final correction

| Measurement | Across three independent runs |
|---|---:|
| Seeds | 20260906, 20260907, 20260908 |
| Completed paid jobs | 2,400 |
| EXECUTE / DELIVER | 670 / 1730 |
| Logical TM transitions represented in deliveries | 22,467 |
| Newly computed TM transitions paid | 6,108 |
| Tampered receipts rejected | 84 |
| Subquorum preparations rejected | 60 |
| Injected settlement rollbacks and retries | 27 |
| Paid route-policy changes | 21 |
| Pending jobs after each successful workload | 0 |
| Exact total Fire after each independent run | [1,0] |

The successful new computations were each replayed once by the listener. Rejected checks and crash retries incurred additional measured interpreter work; the JSON logs retain those separate counters rather than disguising them as productive throughput. The principal partition was audited as disjoint full coverage of [0,1), not merely as a scalar sum.

### D. Availability is not silently counted as success

The stale-contact mesh experiment had 128 logical ports on 32 modeled owners. All 2,000 healthy routes delivered; mean hops were 2.7925 and maximum hops 5. Taking 10 whole owners offline left 88 ports. Of 2,000 subsequent routes using stale local contacts, **1928 delivered and 72 halted**. All 500 deliberately cross-partition requests halted. No global contact-table reconstruction was used to turn those failures into successes.

## 8. Actual iteration, including the failing case

First, the original v4 full suite was rerun with 1,000 paid quanta. It passed in 76.174 seconds on this container. That is a local test measurement, not network throughput.

The initial v5 suite then passed its 1,200-job workload, reusable-result checks, safety regressions and stale-contact tests. An additional adversarial boundary probe nonetheless found that a valid input with 8,192 occupied tape cells could produce 8,193 cells, which violated the interpreter's own next-input limit. That observed counterexample is preserved with the initial v5 source.

The final correction validates every resulting continuation against the same state bounds as the next input. A capsule therefore cannot certify an inadmissible successor state. It also pins VM identity to the implementation hash. The boundary regression now rejects the oversized tape and an oversized head coordinate without payment. Its deliberately invalid funded job remains reserved, not lost or fabricated; certified cancellation is not implemented.

The entire revised suite was rerun, followed by two more 600-job workload seeds. The main final suite passed in 74.851 seconds. The logs include 18 inherited safety/recovery checks, 14 additional cache/receipt/crash checks, the new continuation-boundary regressions, 5,000 algebra trials, 513 exact fracture depths, and the Turing/Lens tests.

Tests interrupted settlement after consuming inputs, after its first output and before commit. An abrupt child-process exit with code 73 also left no partial output live after restart. The exact original job then completed once. The tests concern application-process failure and the configured SQLite transactions, not every disk, power-loss or hardware scenario.

## 9. What the fail-closed claim means here

Funding is reserved before work. Result verification occurs before payment. Settlement consumes the payer and two service inputs and creates payer change, two renewed service papers and two fresh fee papers. Result knowledge and those outputs commit together. Repeating a completed receipt returns the original outcome without paying again.

The witness model has seven fixed, publicly known test identities and requires five distinct authorized signatures. With at most two faulty sign-once witnesses, conflicting five-member quorums must intersect in an honest member. Exhaustive modeled vote assignments found no conflicting pair within that bound. With three faulty witnesses, **6 of 81 assignments admitted a conflict**, and the negative control constructed conflicting signed certificates. The bound is not hidden.

The executable model remains a local trusted transition reducer plus persistent sign-once witness stores. Those stores do not independently run the complete application/consensus state machine on remote hosts. Certificates provide the modeled authority boundary; they do not turn a centralized test into a fully Byzantine-resilient deployment.

Missing or corrupted required data, an invalid request or receipt, stale/unreachable service, or insufficient quorum causes rejection or retains the previous reserved state. Unknown progress can mean a pending job remains locked, including freezing the reference epoch schedule. That is an availability sacrifice, not a balance correction by guesswork.

An unconditional claim that every adversary makes the entire physical network switch off before any corruption is **not established**. Remaining deployment work includes independently validating replicas and consensus/view changes, membership and key management, secure time, cancellation/escrow recovery, transport/discovery, distributed CAS retention, realistic resource quotes and denial-of-service limits. Mathematical unlimited subdivision also does not supply unlimited storage or computation: amount sizes, tape sizes and quantum budgets are explicitly finite here.

## 10. Reproduce the work

Tested with Python 3.13.5 and cryptography 46.0.4. The pin reproduces this research environment and is not an assurance of indefinite production security support.

```sh
python -m pip install -r requirements.txt
python fire_echo_v5.py demo --jobs 12
python test_fire_echo_v5.py --jobs 1200 --seed 20260906 --out local_results.json
python test_fire_echo_v5.py --stress-only --jobs 600 --seed 20260907 --out seed2.json
python test_fire_echo_v5.py --stress-only --jobs 600 --seed 20260908 --out seed3.json
```

The file `combined_results.json` collects the measured final runs. `test_results_v5_initial.json` is explicitly historical: it passed before the extra state-limit counterexample was found. `iteration_counterexample.json` and `iterations/v5_initial.py` preserve that evidence. The baseline code and rerun records are included separately. No user-supplied original artifact was overwritten.

Editing the protocol source changes its manifest hash and protocol identity. Use a new database for changed rules; do not reuse a database under a different pinned implementation.

Final protocol ID:

```text
2a8c0bb9fbfbe11305f6b42e43a803a3fabfe8c90d458d638134f2e7426cb836
```

## 11. Related primary foundations

These sources explain established techniques; they do not endorse Fire Echo or prove this prototype secure.

[R1] Acar, Blelloch and Harper, *Selective Memoization*, POPL 2003. Exact dependencies and controlled reuse of computations. Author manuscript: https://www.cs.cmu.edu/~rwh/papers/memoization/popl.pdf

[R2] Haeberlen, Aditya, Rodrigues and Druschel, *Accountable Virtual Machines*, OSDI 2010. Replay-oriented execution accountability. https://www.usenix.org/conference/osdi10/accountable-virtual-machines

[R3] IPFS documentation, *Immutability*. Mutable current-state references built over immutable content identities. https://docs.ipfs.tech/concepts/immutability/

[R4] SQLite documentation, *Atomic Commit in SQLite*. Database atomicity and its implementation assumptions. https://sqlite.org/atomiccommit.html

[R5] Castro and Liskov, *Practical Byzantine Fault Tolerance*, OSDI 1999. Byzantine fault bounds and replicated state-machine design; substantially more than this simulator's witness abstraction. https://www.usenix.org/legacy/publications/library/proceedings/osdi99/full_papers/castro/castro_html/castro.html

## The abstract principle

**Preserve a choice as an ongoing service policy. Let its certified age weight access to funded work. Preserve checked computation as reusable history. Consume payment authority once. Renew the money-backed service state without inventing principal or erasing useful knowledge.**
