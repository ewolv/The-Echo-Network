# Fire Echo v5 research prototype

**PUBLIC TEST KEYS. DO NOT USE FOR ACTUAL FUNDS. Not a deployed network or full BFT consensus.**

Read DESIGN_AND_TEST_REPORT.md for the exact model, observed failures, corrections and limits.

```sh
python -m pip install -r requirements.txt
python fire_echo_v5.py demo --jobs 12
python test_fire_echo_v5.py --jobs 1200 --out local_results.json
```

The main program uses a temporary SQLite database by default. The Python Protocol API also accepts a persistent directory; keep the source and user configuration unchanged when reopening it. All identities are deliberately reproducible public test identities. No real network service is started and no real money is transmitted.

EXECUTE performs and independently replays a bounded deterministic TM quantum. DELIVER authenticates an existing checked-result capsule and charges the example delivery tariff, not new computation. The CLI demo prints both modes. Policies (inside/outside, east/west, speak/listen) remain stable while program state evolves.

- fire_echo_v5.py: protocol, exact arithmetic, interpreter, local overlay, demo.
- test_fire_echo_v5.py: regression, negative-control and workload entry point.
- legacy_regressions.py: imported test helpers (not the recommended CLI).
- combined_results.json: final main suite plus two extra workload seeds.
- iterations/v5_initial.py and iteration_counterexample.json: observed pre-fix boundary defect.
- baseline_v4.py and baseline_v4_tests.py: unchanged prior protocol and compatible baseline test harness.
- v4_baseline_rerun.json/log: baseline results from this turn.

The source hash is pinned in the manifest. Altering the protocol file creates a new protocol identity and requires a new database. Test results are finite local experiments, not a proof of production safety, distributed uptime, profitability or universal speedup.
