from pathlib import Path
p=Path(__file__).with_name('fire_echo_v5.py')
s=p.read_text()
s=s.replace('Fire Echo v4:', 'Fire Echo v5:')
s=s.replace("'name': 'Fire Echo', 'version': 4,", "'name': 'Fire Echo', 'version': 5,")
s=s.replace("'fire-echo-v4-certificate'", "'fire-echo-v5-certificate'")
s=s.replace("'compute_price': 'accepted demo quote phi^-32 per verified TM transition, independent of funding-note size',", "'compute_price': 'demo quote phi^-32 per newly replayed TM transition plus phi^-32 per bounded result delivery',\n    'reuse': 'certified immutable result capsules; pure-result identity separate from one-use payment identity',\n    'ports': 'hash(root,owner,right_interval_boundary); state hashes change without rotating every contact',")
s=s.replace('UNIT_PRICE = invpow(32)', "UNIT_PRICE = invpow(32)\nDELIVERY_PRICE = UNIT_PRICE\nVM_ID = digest({'vm':'fire-echo-deterministic-sparse-tape-v5','step_limit':MAX_QUANTUM})")
s=s.replace('    @property\n    def fire(self)', '''    @property
    def port(self) -> str:
        # A live, disjoint principal interval has a unique right boundary.
        # Paying from its left edge renews state without changing this address.
        return digest({'root':self.root,'owner':self.owner,'right':self.hi.pair()})

    @property
    def fire(self)''')
s=s.replace("require(type(initial['head']) is int and type(initial['cells']) is list", "require(type(initial['head']) is int and abs(initial['head']).bit_length() <= 63\n            and type(initial['cells']) is list")
s=s.replace("and type(row[1]) is str and 0 < len(row[1]) <= 32", "and abs(row[0]).bit_length() <= 63\n                and type(row[1]) is str and 0 < len(row[1]) <= 32")
a=s.index('class LocalOverlay:'); b=s.index('\ndef validate_program',a)
s=s[:a]+'''class PaperMesh:
    """Local cached contacts backed by paper-derived ports, NOT global discovery.

    Initial neighbors are simulator-supplied. Normal state renewal updates only
    existing port heads. No neighbor list is rebuilt by publish(). New ports
    require a subsequent explicit membership/peer-discovery step (not provided).
    Hosts are modeled by owner keys, not independent people or machines.
    """
    def __init__(self, papers: Sequence[Paper], online: Iterable[str] | None = None):
        require(bool(papers), 'empty mesh')
        self.heads={p.port:p for p in papers}
        require(len(self.heads)==len(papers), 'duplicate paper-derived port')
        ids=sorted(self.heads)
        self.online=set(ids if online is None else online)
        self.contacts={}
        steps=[1,2,3];a,b=3,5
        while b < len(ids):
            steps.append(b);a,b=b,a+b
        for i,h in enumerate(ids):
            self.contacts[h]=tuple(tuple(ids[(i+sign*d)%len(ids)] for d in steps if d < len(ids))
                                   for sign in (1,-1))

    def route(self, source: str, target: str, direction: int, ttl: int=128) -> tuple[str,...]:
        require(source in self.online and target in self.online, 'endpoint unavailable')
        require(type(direction) is int and direction in (0,1), 'bad direction')
        path=[source];current=source;mod=1<<256
        dist=lambda a,b: ((int(b,16)-int(a,16)) if direction==0 else (int(a,16)-int(b,16)))%mod
        while current != target:
            require(len(path)<=ttl, 'routing fuel exhausted')
            remaining=dist(current,target)
            candidates=[p for p in self.contacts.get(current,((),()))[direction]
                        if p in self.online and 0 < dist(current,p) <= remaining]
            require(bool(candidates),'local routing knowledge insufficient')
            current=max(candidates,key=lambda p:dist(current,p));path.append(current)
        return tuple(path)

    def dispatch(self, service: Paper, requester: str, source: Paper, role: int) -> tuple[str,...]:
        require(service.choice.bits[2]==role,'speak/listen role mismatch')
        external=service.owner != requester
        require(external==bool(service.choice.bits[0]),'inside/outside scope mismatch')
        require(service.port in self.heads and self.heads[service.port].id==service.id,
                'stale service head: require committed renewal')
        require(source.port in self.heads and self.heads[source.port].id==source.id,
                'stale source head: require committed renewal')
        require(service.port in self.online and source.port in self.online,'service unavailable')
        if not external and source.owner==service.owner:
            return (source.port,service.port) if source.port!=service.port else (source.port,)
        return self.route(source.port,service.port,service.choice.bits[1])

    def publish(self, protocol: Protocol, inputs: Sequence[Paper], outputs: Sequence[Paper]) -> None:
        """Consume a committed transition announcement, not an invented alias."""
        require(bool(outputs) and len({p.parent for p in outputs})==1,'mixed announcements')
        tx=outputs[0].parent;intent=protocol.get(tx)
        require(intent['inputs']==[p.id for p in inputs],'wrong predecessor heads')
        require([p.body() for p in protocol._make_outputs(intent)]==[p.body() for p in outputs],
                'announcement outputs differ from commit')
        saved=protocol.db.execute('SELECT certificate FROM commits WHERE tx=?',(tx,)).fetchone()
        require(saved is not None,'uncertified announcement')
        cert=protocol.get(saved[0])['certificate']
        resources=(["result:"+intent['details']['job']] if intent['kind']=='settle-quantum'
                   else ['note:'+x for x in intent['inputs']])
        protocol.quorum.verify(cert,protocol.quorum.envelope(tx,resources,intent))
        for p in inputs:
            row=protocol.db.execute('SELECT tx FROM spent WHERE id=?',(p.id,)).fetchone()
            require(row is not None and row[0]==tx,'unconsumed announcement input')
        for p in outputs:
            protocol.live(p.id)
        old_ports={p.port for p in inputs};new={p.port:p for p in outputs}
        # Contacts keep stable ports; only witnessed state heads change.
        for port in old_ports & self.heads.keys():
            if port in new:
                self.heads[port]=new[port]
            else:
                self.online.discard(port)
        # New reward/fracture ports are real paper, but are not magically known peers.


LocalOverlay=PaperMesh
''' + s[b:]
# Canonical program meaning within this finite transition-table language.
a=s.index('\ndef initial_state')
s=s[:a]+'''
def canonical_program(spec: dict) -> dict:
    validate_program(spec)
    return {'start':spec['start'],'halt':sorted(spec['halt']),'blank':spec['blank'],
            'table':sorted([list(row) for row in spec['table']],key=lambda r:(r[0],r[1]))}


def memo_key(namespace: str, program: str, initial: str, budget: int) -> str:
    return digest({'domain':'pure-machine-result','vm':VM_ID,'namespace':namespace,
                   'program':program,'initial':initial,'budget':budget})


def capsule(run: dict, namespace: str) -> dict:
    return {'kind':'checked-machine-capsule','vm':VM_ID,'namespace':namespace,
            'program':run['program'],'initial':run['input'],'budget':run['budget'],
            'steps':run['steps'],'status':run['status'],'final':run['final'],'trace':run['trace']}


def delivery_receipt(body: dict, cap: dict) -> dict:
    key=memo_key(cap['namespace'],cap['program'],cap['initial'],cap['budget'])
    require(key==body['memo_key'] and cap['vm']==VM_ID, 'capsule bound to another computation')
    require(cap['program']==body['program'] and cap['initial']==body['initial']
            and cap['budget']==body['budget'], 'capsule request mismatch')
    fresh=body['mode']=='EXECUTE'
    return {'kind':'execution-receipt','job':digest(body),'program':cap['program'],'input':cap['initial'],
            'budget':cap['budget'],'steps':cap['steps'],'status':cap['status'],'final':cap['final'],
            'trace':cap['trace'],'mode':body['mode'],'capsule':digest(cap),
            'new_steps':cap['steps'] if fresh else 0,'delivery_units':1}

''' + s[a:]
s=s.replace("            CREATE TABLE IF NOT EXISTS reservations (note TEXT PRIMARY KEY, job TEXT NOT NULL);", "            CREATE TABLE IF NOT EXISTS reservations (note TEXT PRIMARY KEY, job TEXT NOT NULL);\n            CREATE TABLE IF NOT EXISTS memos (key TEXT PRIMARY KEY, capsule TEXT NOT NULL, certificate TEXT NOT NULL);")
s=s.replace("fail_at:str|None=None, job:str|None=None, receipt:str|None=None) -> list[Paper]:", "fail_at:str|None=None, job:str|None=None, receipt:str|None=None,\n               memo:tuple[str,str,str]|None=None) -> list[Paper]:")
s=s.replace("            if fail_at == 'before_commit':\n                raise OSError('injected I/O failure before commit')", "            if memo:\n                key,cap,cert_id=memo\n                self.db.execute('INSERT OR IGNORE INTO memos VALUES (?,?,?)',memo)\n                row=self.db.execute('SELECT capsule FROM memos WHERE key=?',(key,)).fetchone()\n                require(row is not None and row[0]==cap, 'conflicting result cache')\n            if fail_at == 'before_commit':\n                raise OSError('injected I/O failure before commit')")
# Add cache read, including full certificate binding, before prepare.
a=s.index('    def prepare(')
s=s[:a]+'''    def checked_memo(self,key:str) -> tuple[dict,str] | None:
        row=self.db.execute('SELECT capsule,certificate FROM memos WHERE key=?',(key,)).fetchone()
        if row is None:
            return None
        cap=self.get(row[0]);saved=self.get(row[1])
        require(type(cap) is dict and cap.get('kind')=='checked-machine-capsule','invalid capsule')
        require(cap.get('vm')==VM_ID,'foreign VM capsule')
        require(key==memo_key(cap['namespace'],cap['program'],cap['initial'],cap['budget']),
                'cache index points to another computation')
        payload={'kind':'certified-machine-result','key':key,'capsule':row[0]}
        require(saved.get('payload')==payload,'capsule certificate mismatch')
        expected=self.quorum.envelope(digest(payload),['memo:'+key],payload)
        self.quorum.verify(saved['certificate'],expected)
        return cap,row[1]

''' + s[a:]
s=s.replace("        validate_program(spec)\n        # Validate/bound", "        spec=canonical_program(spec)\n        # Validate/bound")
s=s.replace("        price=UNIT_PRICE  # Accepted per-step service quote, NOT a fraction of the payer balance.\n        require(price*budget < p.fire,'budget exceeds funding')", "        price=UNIT_PRICE\n        namespace='public' if a.choice.bits[0] else 'owner:'+p.owner\n        key=memo_key(namespace,digest(spec),digest(initial),budget)\n        cached=self.checked_memo(key)\n        mode='DELIVER' if cached is not None else 'EXECUTE'\n        maximum=DELIVERY_PRICE+(price*budget if cached is None else ZERO)\n        require(maximum < p.fire,'budget exceeds funding')")
s=s.replace("'outward':list(outward),'echo':list(echo)}", "'outward':list(outward),'echo':list(echo),\n              'mode':mode,'namespace':namespace,'memo_key':key,\n              'capsule':digest(cached[0]) if cached is not None else None,\n              'memo_certificate':cached[1] if cached is not None else None,\n              'delivery_price':DELIVERY_PRICE.pair()}")
s=s.replace("'max_fee':(price*budget).pair()", "'max_fee':maximum.pair()")
# Replace work method.
a=s.index('    def work(');b=s.index('    def settle(',a)
s=s[:a]+'''    def work(self,job:str) -> dict:
        body=self.get(job)
        a=self.live(body['speaker'],job)
        require(a.choice.bits[2]==0,'only speak services propose or deliver')
        if body['mode']=='DELIVER':
            cached=self.checked_memo(body['memo_key'])
            require(cached is not None and digest(cached[0])==body['capsule']
                    and cached[1]==body['memo_certificate'],'prepared capsule unavailable or changed')
            cap=cached[0]
        else:
            require(body['mode']=='EXECUTE','invalid execution mode')
            cap=capsule(run_quantum(self.get(body['program']),self.get(body['initial']),
                                    body['budget'],job),body['namespace'])
        return delivery_receipt(body,cap)

''' + s[b:]
s=s.replace("        expected=run_quantum(self.get(body['program']),self.get(body['initial']),body['budget'],job)\n        require(receipt == expected,'wrong input, result, job, trace or budget')", "        memo=None;extra=[]\n        if body['mode']=='DELIVER':\n            cached=self.checked_memo(body['memo_key'])\n            require(cached is not None and digest(cached[0])==body['capsule']\n                    and cached[1]==body['memo_certificate'],'prepared capsule unavailable or changed')\n            cap=cached[0]\n        else:\n            require(body['mode']=='EXECUTE','invalid execution mode')\n            cap=capsule(run_quantum(self.get(body['program']),self.get(body['initial']),\n                                    body['budget'],job),body['namespace'])\n        expected=delivery_receipt(body,cap)\n        require(canon(receipt)==canon(expected),'wrong input, result, job, trace, mode or budget')")
s=s.replace("        fee=Phi.parse(body['price'])*receipt['steps']; fa,fb=fee*INV,fee*invpow(2)", "        if body['mode']=='EXECUTE':\n            payload={'kind':'certified-machine-result','key':body['memo_key'],'capsule':digest(cap)}\n            ccert=self.quorum.certify(digest(payload),['memo:'+body['memo_key']],payload,reachable)\n            saved={'payload':payload,'certificate':ccert}\n            extra=[cap,saved];memo=(body['memo_key'],digest(cap),digest(saved))\n        fee=Phi.parse(body['price'])*receipt['new_steps']+Phi.parse(body['delivery_price'])\n        fa,fb=fee*INV,fee*invpow(2)")
s=s.replace("'details':{'job':job,'receipt':rh,'steps':receipt['steps']}}", "'details':{'job':job,'receipt':rh,'steps':receipt['steps'],\n                           'mode':body['mode'],'new_steps':receipt['new_steps'],'memo_key':body['memo_key'],\n                           'fee':fee.pair(),'capsule':digest(cap),\n                           'memo_certificate':memo[2] if memo else body['memo_certificate']}}")
s=s.replace("return self._apply(intent,cert,(p,a,b),[receipt,receipt['final'],", "return self._apply(intent,cert,(p,a,b),extra+[receipt,receipt['final'],")
s=s.replace("                           fail_at,job,rh)", "                           fail_at,job,rh,memo)")
s=s.replace("        return {'supply':self.total().pair(),'live_papers':len(notes),", "        for (key,) in self.db.execute('SELECT key FROM memos'):\n            self.checked_memo(key)\n        return {'supply':self.total().pair(),'live_papers':len(notes),\n                'certified_result_capsules':self.db.execute('SELECT count(*) FROM memos').fetchone()[0],")
s=s.replace("snap=p.snapshot([s,l]); states=[]", "snap=p.snapshot([s,l]);mesh=PaperMesh(p.notes());states=[]")
s=s.replace("job=p.prepare(payer.id,p.users[0],snap,spec,initial,8)\n        receipt=p.work(job); payer,*_=p.settle(job,receipt)\n        states.append({'job':job,'steps':receipt['steps'],'status':receipt['status']})", "job=p.prepare(payer.id,p.users[0],snap,spec,initial,8,overlay=mesh)\n        body=p.get(job);inputs=[p.live(body[k],job) for k in ('payer','speaker','listener')]\n        receipt=p.work(job);out=p.settle(job,receipt);mesh.publish(p,inputs,out);payer=out[0]\n        states.append({'job':job,'logical_steps':receipt['steps'],'new_steps':receipt['new_steps'],\n                       'mode':receipt['mode'],'status':receipt['status']})")
s=s.replace("'model':'Fire Echo v4; not production'", "'model':'Fire Echo v5; public test keys, not production'")
p.write_text(s)
