#!/usr/bin/env python3
"""Reproducible adversarial/property tests: python test_fire_echo_v4.py --jobs 1000"""
from __future__ import annotations
import argparse, copy, itertools, json, random, statistics, tempfile, time, subprocess, sys
from dataclasses import replace
from pathlib import Path
import baseline_v4 as f
SEED=20260906

def expect_halt(fn):
    try: fn()
    except f.Halt: return
    raise AssertionError('unsafe operation did not halt')

def fingerprint(p):
    return tuple(sorted(x.id for x in p.notes())),p.total().pair()

def fixture(path=None):
    p=f.Protocol(path);g=p.bootstrap();payer,r=p.fracture(g.id,p.users[0]);a,b=p.fracture(r.id,p.users[0])
    a,_=p.transfer(a.id,p.users[0],p.users[1],(1,0,0))
    b,_=p.transfer(b.id,p.users[0],p.users[2],(1,1,1))
    for _ in range(5):p.advance()
    snap=p.snapshot([a,b])
    return p,payer,a,b,snap

def funded(p,payer,snap):
    return p.prepare(payer.id,p.keys[payer.owner],snap,f.UNARY,f.initial_state(f.UNARY,'111'),8)

def exact_properties():
    rng=random.Random(SEED)
    for n in range(513):
        w=f.invpow(n);assert w.positive() and w*f.INV+w*f.invpow(2)==w
    for _ in range(5000):
        x,y,z=[f.Phi(rng.randrange(-1000,1000),rng.randrange(-1000,1000)) for _ in range(3)]
        assert (x+y)+z==x+(y+z) and x*(y+z)==x*y+x*z and x*y==y*x and (x<y)==(y-x).positive()
    assert f.digest({'a':1,'b':2})==f.digest({'b':2,'a':1})
    expect_halt(lambda:f.canon({'x':float('nan')}))
    expect_halt(lambda:f.Choice((0.1,0,0),(0,0,0)))
    expect_halt(lambda:f.Choice((True,0,0),(0,0,0)))
    expect_halt(lambda:f.Choice((0,0,0),(-1,0,0)))
    expect_halt(lambda:f.Choice((0,0,0),(10,0,0)).ages(9))
    return {'exact_fracture_depths':513,'random_algebra_trials':5000,'phi_minus_100_display':f.invpow(100).display()}

def synthetic(lo,hi,owner,ages=(21,21,21),bits=(1,0,0),epoch=21):
    return f.Paper('selection-only-root',owner,lo,hi,f.Choice(bits,tuple(epoch-a for a in ages)),'fixture',0)

def scheduler_properties():
    w=f.invpow(3);a=synthetic(f.ZERO,w,'A');b=synthetic(w,2*w,'B');group=[a]
    for depth in range(6):
        ng=[]
        for p in group:
            mid=p.lo+p.fire*f.INV
            ng.extend([replace(p,hi=mid,parent=f'split-{depth}',index=0),replace(p,lo=mid,parent=f'split-{depth}',index=1)])
        group=ng
    plain=f.MassTree([a,b],21);split=f.MassTree(group+[b],21);assert plain.mass==split.mass
    mismatches=sum(plain.select(*f.slot_fraction(i)).owner!=split.select(*f.slot_fraction(i)).owner for i in range(4096))
    assert mismatches==0
    young=replace(b,choice=f.Choice.fresh(b.choice.bits,21));tree=f.MassTree([a,young],21)
    old_count=sum(tree.select(*f.slot_fraction(i)).owner=='A' for i in range(4096))
    old_mass=float(a.mass(21).display());young_mass=float(young.mass(21).display());theory=old_mass/(old_mass+young_mass)
    assert abs(old_count/4096-theory)<.001
    factors=[]
    for k in range(4):
        c=f.Choice((1,0,0),tuple(0 if i<k else 21 for i in range(3)));factors.append(float(c.density(21).display())/3)
    assert synthetic(f.ZERO,f.invpow(512),'tiny').mass(21)>f.ZERO
    return {'split_fragments':len(group),'identical_schedule_slots':4096,'split_selection_mismatches':mismatches,
            'old_selected':old_count,'young_selected':4096-old_count,'old_share':old_count/4096,
            'old_theoretical_share':theory,'factors_for_0_1_2_3_aged_channels':factors}

def machine_properties():
    cases=transitions=0
    for n in range(65):
        initial=f.initial_state(f.UNARY,'1'*n);complete=f.run_quantum(f.UNARY,initial,128,'one')
        assert len(complete['final']['cells'])==n+1
        for budget in (1,2,3,8,16):
            state=initial;total=0
            for j in range(100):
                r=f.run_quantum(f.UNARY,state,budget,str(j));total+=r['steps'];state=r['final']
                if r['status']=='HALTED':break
            assert state==complete['final'] and total==n+1
            cases+=1;transitions+=total
    rng=random.Random(SEED)
    for i in range(500):
        table=[]
        for q in ('a','b','c'):
            for s in ('_','1'):table.append([q,s,rng.choice(('a','b','c','H')),rng.choice(('_','1')),rng.choice(('L','R','S'))])
        spec={'start':'a','halt':['H'],'blank':'_','table':table};initial=f.initial_state(spec,'1'*rng.randrange(8));budget=rng.randrange(1,65)
        original=f.run_quantum(spec,initial,budget,'x')
        mirrored=f.run_quantum(f.mirror_program(spec),f.mirror_state(initial),budget,'x')
        assert f.mirror_state(mirrored['final'])==original['final'] and mirrored['steps']==original['steps']
        assert f.mirror_state(f.mirror_state(initial))==initial
    state=f.initial_state(f.LOOP,[])
    for i in range(64):
        r=f.run_quantum(f.LOOP,state,32,str(i));state=r['final'];assert r['status']=='SUSPENDED' and r['steps']==32
    assert state['head']==2048
    for bad in (0,-1,True,f.MAX_QUANTUM+1):expect_halt(lambda bad=bad:f.run_quantum(f.UNARY,f.initial_state(f.UNARY,'11'),bad,'bad'))
    duplicate=copy.deepcopy(f.UNARY);duplicate['table'].append(duplicate['table'][0])
    expect_halt(lambda:f.run_quantum(duplicate,f.initial_state(duplicate,'1'),5,'bad'))
    return {'resumption_cases':cases,'resumption_TM_transitions':transitions,'random_program_lens_conjugacy_cases':500,'nonhalting_chunk_steps':2048}

def safety_and_recovery():
    checks=[];p,payer,a,b,snap=fixture();before=fingerprint(p)
    expect_halt(p.bootstrap);assert fingerprint(p)==before;checks.append('one genesis only')
    expected=p.quorum.envelope('fake',['fake-resource'],{'kind':'fake'})
    cert={'message':expected,'signatures':[{'signer':u.id,'signature':u.sign(expected)} for u in p.users[3:8]]}
    expect_halt(lambda:p.quorum.verify(cert,expected));checks.append('noncommittee signers rejected')
    e=p.epoch;expect_halt(lambda:p.advance([0,1,2,3]));assert p.epoch==e;checks.append('subquorum epoch rejected')
    expect_halt(lambda:p.prepare(payer.id,p.users[0],snap,f.UNARY,f.initial_state(f.UNARY,'111'),8,reachable=[0,1,2,3]))
    assert fingerprint(p)==before and p.audit()['pending_jobs']==0;checks.append('subquorum prepare leaves funds unreserved')
    job=funded(p,payer,snap);original=fingerprint(p)
    expect_halt(lambda:p.transfer(payer.id,p.users[0],p.users[3]));checks.append('escrow cannot be spent elsewhere')
    wrong=f.run_quantum(f.UNARY,f.initial_state(f.UNARY,'1'),8,job)
    expect_halt(lambda:p.settle(job,wrong));assert fingerprint(p)==original;checks.append('valid proof for wrong input rejected')
    correct=p.work(job)
    for field,value in [('job','foreign-job'),('budget',7),('trace','00'*32),('steps',999)]:
        bad=dict(correct);bad[field]=value;expect_halt(lambda bad=bad:p.settle(job,bad));assert fingerprint(p)==original
    checks.append('job budget trace and metering bindings enforced')
    expect_halt(lambda:p.settle(job,correct,bad_signature=True));assert fingerprint(p)==original;checks.append('forged result postcard rejected')
    expect_halt(lambda:p.settle(job,correct,reachable=[0,1,2,3]));assert fingerprint(p)==original;checks.append('subquorum settlement retains escrow')
    out=p.settle(job,correct);before_replay=fingerprint(p)
    assert [x.id for x in p.settle(job,correct)]==[x.id for x in out] and fingerprint(p)==before_replay
    checks.append('settlement replay idempotent')
    assert out[1].choice==a.choice and out[2].choice==b.choice and out[1].service_seq==a.service_seq+1
    assert out[3].choice.ages(p.epoch)==out[4].choice.ages(p.epoch)==(0,0,0)
    checks.append('continuity preserved; rewards start young')
    expect_halt(lambda:p.fracture(payer.id,p.users[0]));checks.append('consumed payer cannot double-spend')
    changed,_=p.transfer(out[1].id,p.users[1],p.users[1],(1,1,0))
    assert changed.choice.ages(p.epoch)==(5,0,5) and changed.fire<out[1].fire
    checks.append('paid bit change resets only that clock')
    transferred,_=p.transfer(changed.id,p.users[1],p.users[4]);assert transferred.choice.ages(p.epoch)==(0,0,0)
    checks.append('recipient change resets all clocks');p.audit();p.close()
    for point in ('after_consume','after_first_output','before_commit'):
        with tempfile.TemporaryDirectory() as path:
            p,payer,a,b,snap=fixture(path);job=funded(p,payer,snap);receipt=p.work(job);before=fingerprint(p)
            try:p.settle(job,receipt,fail_at=point)
            except OSError:pass
            else:raise AssertionError('failure injection did not occur')
            assert fingerprint(p)==before and p.audit()['pending_jobs']==1
            p.close();p=f.Protocol(path);assert fingerprint(p)==before
            p.settle(job,receipt);assert p.audit()['pending_jobs']==0 and p.total()==f.ONE;p.close()
        checks.append('rollback and restart recovery: '+point)
    p,payer,a,b,snap=fixture();before=fingerprint(p)
    with p.db:p.db.execute('UPDATE cas SET data=? WHERE id=?',(b'{"tampered":1}',payer.id))
    expect_halt(lambda:p.live(payer.id));assert fingerprint(p)==before;p.close();checks.append('CAS tamper rejected')
    return {'passed_checks':checks,'check_count':len(checks)}

def quorum_bound():
    counts={}
    for faults in (0,1,2,3):
        cases=dual=0
        for signs in itertools.product((0,1,2),repeat=7-faults):
            cases+=1;dual+=faults+signs.count(1)>=5 and faults+signs.count(2)>=5
        counts[str(faults)]={'assignments':cases,'conflicting_quorums':dual}
    assert all(counts[str(k)]['conflicting_quorums']==0 for k in (0,1,2)) and counts['3']['conflicting_quorums']>0
    with tempfile.TemporaryDirectory() as path:
        q=f.Quorum(Path(path),'boundary-test',faulty=3)
        a=q.certify('A',['same-input'],{'tx':'A'},[0,1,2,3,4]);b=q.certify('B',['same-input'],{'tx':'B'},[0,1,2,5,6])
        q.verify(a,q.envelope('A',['same-input'],{'tx':'A'}));q.verify(b,q.envelope('B',['same-input'],{'tx':'B'}));q.close()
    return {'exhaustive_results':counts,'negative_control_three_faults_breaks_guarantee':True}

def topology_and_modes():
    rng=random.Random(SEED);pool=[synthetic(f.ZERO,f.ONE,'peer-0')]
    for depth in range(7):
        nxt=[]
        for p in pool:
            mid=p.lo+p.fire*f.INV
            nxt.extend([replace(p,hi=mid,parent=f'depth-{depth}',index=0),replace(p,lo=mid,parent=f'depth-{depth}',index=1)])
        pool=nxt
    pool=[replace(p,owner=f'peer-{i%32}',index=i) for i,p in enumerate(pool)]
    net=f.LocalOverlay(pool);ids=list(net.papers);hops=[]
    for i in range(2000):
        source,target=rng.sample(ids,2);path=net.route(source,target,i%2);assert path[-1]==target;hops.append(len(path)-1)
    offline_owners=set(rng.sample(sorted({p.owner for p in pool}),10))
    online={p.id for p in pool if p.owner not in offline_owners};net.online=online;survivors=sorted(online)
    churn_success=churn_fail=0;churn_hops=[]
    for i in range(2000):
        source,target=rng.sample(survivors,2)
        try:path=net.route(source,target,i%2);churn_success+=1;churn_hops.append(len(path)-1)
        except f.Halt:churn_fail+=1
    net=f.LocalOverlay(pool);ordered=sorted(net.papers);left=set(ordered[:64]);right=set(ordered[64:])
    for n,dirs in list(net.contacts.items()):
        group=left if n in left else right;net.contacts[n]=tuple(tuple(x for x in contacts if x in group) for contacts in dirs)
    for i in range(500):
        source=rng.choice(sorted(left));target=rng.choice(sorted(right));expect_halt(lambda:net.route(source,target,i%2))
    mode_results=[]
    for scope,direction,role in itertools.product((0,1),repeat=3):
        source=pool[0];service=replace(pool[1],owner=source.owner if scope==0 else 'other-owner',choice=f.Choice((scope,direction,role),(0,0,0)))
        modes_net=f.LocalOverlay([source,service]+pool[2:]);path=modes_net.dispatch(service,source.owner,source,role)
        result=f.run_quantum(f.UNARY,f.initial_state(f.UNARY,'111'),8,'mode-test')
        if role==1:assert result==f.run_quantum(f.UNARY,f.initial_state(f.UNARY,'111'),8,'mode-test')
        expect_halt(lambda:modes_net.dispatch(service,source.owner,source,1-role))
        mode_results.append({'bits':[scope,direction,role],'operation':'execute' if role==0 else 'replay-check',
                            'scope':'inside' if scope==0 else 'outside','direction':'east' if direction==0 else 'west',
                            'delivery_vertices':len(path),'TM_steps':result['steps']})
    return {'vertices':128,'physical_owners':32,'clean_routes':2000,'clean_mean_hops':statistics.mean(hops),'clean_max_hops':max(hops),
            'offline_owners':10,'churn_surviving_vertices':len(survivors),'churn_routes_delivered':churn_success,
            'churn_routes_halted':churn_fail,'churn_mean_delivered_hops':statistics.mean(churn_hops),
            'cross_partition_attempts_halted':500,'all_eight_dispatch_modes':mode_results}

def paid_age_demonstration(jobs=192):
    p=f.Protocol();g=p.bootstrap();left,old=p.fracture(g.id,p.users[0]);young,rest=p.fracture(left.id,p.users[0]);payer,listener=p.fracture(rest.id,p.users[0])
    old,_=p.transfer(old.id,p.users[0],p.users[1],(1,0,0));listener,_=p.transfer(listener.id,p.users[0],p.users[3],(1,1,1))
    for _ in range(21):p.advance()
    young,_=p.transfer(young.id,p.users[0],p.users[2],(1,0,0));assert old.fire==young.fire
    snap=p.snapshot([old,young,listener]);counts={old.owner:0,young.owner:0};rewards={old.owner:f.ZERO,young.owner:f.ZERO};steps=0
    for _ in range(jobs):
        job=funded(p,payer,snap);receipt=p.work(job);out=p.settle(job,receipt);payer=out[0]
        counts[out[1].owner]+=1;rewards[out[3].owner]+=out[3].fire;steps+=receipt['steps']
    report={'paid_jobs':jobs,'actual_TM_steps':steps,'old_completed':counts[old.owner],'young_completed':counts[young.owner],
            'old_earned_Fire_display':rewards[old.owner].display(),'young_earned_Fire_display':rewards[young.owner].display(),
            'old_job_share':counts[old.owner]/jobs,'exact_final_supply':p.audit()['supply'],
            'old_choice_ages':[21]*3,'young_choice_ages':[0]*3,'equal_initial_service_principal':True}
    assert abs(report['old_job_share']-2/3)<.015;p.close();return report

def self_work_does_not_mint():
    p=f.Protocol();g=p.bootstrap();payer,r=p.fracture(g.id,p.users[0]);a,b=p.fracture(r.id,p.users[0]);b,_=p.transfer(b.id,p.users[0],p.users[0],(0,0,1))
    snap=p.snapshot([a,b]);before=sum((x.fire for x in p.notes() if x.owner==p.users[0].id),f.ZERO)
    job=funded(p,payer,snap);p.settle(job,p.work(job));after=sum((x.fire for x in p.notes() if x.owner==p.users[0].id),f.ZERO)
    assert before==after and p.total()==f.ONE;p.close();return {'self_execution_net_Fire_gain':[0,0]}

def stress(jobs=1000):
    rng=random.Random(SEED);p=f.Protocol(users=40);g=p.bootstrap();pool=[g]
    for _ in range(5):
        nxt=[]
        for note in pool:nxt.extend(p.fracture(note.id,p.users[0]))
        pool=nxt
    payers=pool[:8];services={}
    for i,n in enumerate(pool[8:]):
        service,_=p.transfer(n.id,p.users[0],p.users[i+1],(1,rng.randrange(2),i%2));services[service.id]=service
        if i%4==0:p.advance()
    for _ in range(6):p.advance()
    snap=p.snapshot(list(services.values()))
    counts={'rejected_bad_proofs':0,'subquorum_prepares':0,'injected_rollbacks':0,'choice_changes':0,
            'halted_quanta':0,'suspended_quanta':0,'actual_worker_TM_steps':0,'resumed_quanta':0,'reward_papers_reused_as_funding':0,'reward_funded_jobs':0}
    checkpoint=f.initial_state(f.LOOP,[])
    for i in range(jobs):
        if i and i%100==0:
            p.advance();old=rng.choice(list(services.values()));bits=list(old.choice.bits);bits[1]^=1
            new,_=p.transfer(old.id,p.keys[old.owner],p.keys[old.owner],bits)
            del services[old.id];services[new.id]=new;counts['choice_changes']+=1;snap=p.snapshot(list(services.values()))
        payers=[n for n in payers if f.UNIT_PRICE < n.fire]
        pi=rng.randrange(len(payers));payer=payers[pi];kind=rng.randrange(3)
        if kind==0:spec=f.UNARY;initial=f.initial_state(spec,'1'*rng.randrange(1,25));budget=32
        elif kind==1:spec=f.LEFT;initial=f.initial_state(spec,'111');budget=8
        else:spec=f.LOOP;initial=checkpoint;budget=rng.randrange(1,17);counts['resumed_quanta']+=1
        while f.UNIT_PRICE*budget >= payer.fire:
            budget-=1
        assert budget >= 1
        if i%41==0:
            before=fingerprint(p);expect_halt(lambda:p.prepare(payer.id,p.keys[payer.owner],snap,spec,initial,budget,reachable=[0,1,2,3]))
            assert fingerprint(p)==before;counts['subquorum_prepares']+=1
        if payer.owner != p.users[0].id: counts['reward_funded_jobs']+=1
        job=p.prepare(payer.id,p.keys[payer.owner],snap,spec,initial,budget);body=p.get(job);receipt=p.work(job)
        if i%29==0:
            bad=dict(receipt,trace='not-the-trace');before=fingerprint(p);expect_halt(lambda:p.settle(job,bad));assert fingerprint(p)==before;counts['rejected_bad_proofs']+=1
        if i%97==0:
            before=fingerprint(p)
            try:p.settle(job,receipt,fail_at='after_first_output')
            except OSError:pass
            else:raise AssertionError('rollback injection failed')
            assert fingerprint(p)==before;counts['injected_rollbacks']+=1
        out=p.settle(job,receipt)
        del services[body['speaker']];del services[body['listener']];services[out[1].id]=out[1];services[out[2].id]=out[2];payers[pi]=out[0]
        if i%67==0 and out[3].fire > f.UNIT_PRICE:
            payers.append(out[3]);counts['reward_papers_reused_as_funding']+=1
        if kind==2:checkpoint=receipt['final']
        counts['actual_worker_TM_steps']+=receipt['steps'];counts['halted_quanta' if receipt['status']=='HALTED' else 'suspended_quanta']+=1
        if i%100==0:assert p.total()==f.ONE
    audit=p.audit();assert audit['paid_jobs']==jobs and audit['pending_jobs']==0 and audit['supply']==[1,0]
    counts['listener_replay_TM_steps']=counts['actual_worker_TM_steps']
    p.close();return {'completed_paid_quanta':jobs,'metrics':counts,'final_audit':audit}


def abrupt_process_crash():
    with tempfile.TemporaryDirectory() as path:
        p,payer,a,b,snap=fixture(path);job=funded(p,payer,snap);receipt=p.work(job);before=fingerprint(p)
        Path(path,'request.json').write_text(json.dumps({'job':job,'receipt':receipt}))
        p.close()
        script = """import json,os,sys
from pathlib import Path
import baseline_v4 as f
p=f.Protocol(sys.argv[1]);request=json.loads(Path(sys.argv[1],'request.json').read_text())
original=p._insert
def interrupted(note):
    original(note)
    os._exit(73)
p._insert=interrupted
p.settle(request['job'],request['receipt'])
"""
        child=subprocess.run([sys.executable,'-c',script,path],cwd=Path(__file__).parent,timeout=20)
        assert child.returncode==73
        p=f.Protocol(path);assert fingerprint(p)==before and p.audit()['pending_jobs']==1
        p.settle(job,receipt);audit=p.audit();assert audit['pending_jobs']==0 and audit['supply']==[1,0]
        p.close()
    return {'abrupt_child_exit_code':73,'uncommitted_outputs_after_restart':0,
            'identical_job_recovery':'PASS','power_loss_or_faulty_disk_tested':False}


def pricing_is_not_paper_size():
    prices=[];sizes=[]
    for shrink in (False,True):
        p,payer,a,b,snap=fixture()
        if shrink:
            # Maintenance changes only the payer, not the frozen service offers.
            payer,_=p.fracture(payer.id,p.keys[payer.owner])
        job=funded(p,payer,snap);body=p.get(job);prices.append(body['price']);sizes.append(payer.fire.pair())
        assert f.Phi.parse(body['price'])==f.UNIT_PRICE
        p.settle(job,p.work(job));p.close()
    assert sizes[0]!=sizes[1] and prices[0]==prices[1]
    # An arbitrarily tiny paper does not buy an arbitrarily cheap fixed-size computation.
    assert f.invpow(100)<f.UNIT_PRICE
    return {'different_funding_principal':sizes,'same_exact_per_step_prices':prices,
            'demo_unit_price_display':f.UNIT_PRICE.display(),
            'age_or_splitting_does_not_change_quote':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--jobs',type=int,default=1000);parser.add_argument('--out',default='test_results.json');args=parser.parse_args()
    result={'seed':SEED,'protocol_id':f.PROTOCOL,'status':'RUNNING','tests':{}};start=time.perf_counter()
    tests=[('exact_arithmetic',exact_properties),('deterministic_scheduler',scheduler_properties),('turing_machine',machine_properties),
           ('safety_recovery',safety_and_recovery),('quorum_assumption_boundary',quorum_bound),('abrupt_process_crash',abrupt_process_crash),
           ('pricing_split_resistance',pricing_is_not_paper_size),('local_network_and_choices',topology_and_modes),
           ('paid_age_demonstration',paid_age_demonstration),('self_work',self_work_does_not_mint),('randomized_paid_network',lambda:stress(args.jobs))]
    for name,fn in tests:
        tick=time.perf_counter();print('RUN',name,flush=True);result['tests'][name]=fn();print('PASS',name,round(time.perf_counter()-tick,3),'seconds',flush=True)
        Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
    result['status']='PASS';result['elapsed_seconds']=round(time.perf_counter()-start,3);Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'elapsed_seconds':result['elapsed_seconds'],'results':args.out},indent=2))

if __name__=='__main__':main()
