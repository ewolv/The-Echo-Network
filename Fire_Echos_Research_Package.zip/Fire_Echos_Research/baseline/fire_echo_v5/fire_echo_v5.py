#!/usr/bin/env python3
"""Fire Echo v5: executable research model, NOT a deployable money network.

Exact phi-interval principal; three persistent dispatch choices; deterministic
age-weighted service scheduling; metered/resumable Turing execution; funded
jobs; recipient postcards; content-addressed lineage; transactional settlement.

SECURITY BOUNDARY: identities below use PUBLIC, DETERMINISTIC TEST SEEDS. Never
use them for money. Seven witness databases simulate a fixed committee, not
independent network hosts or a complete BFT consensus implementation. Epochs
are supplied by the test harness, not a secure real-time oracle. Routing uses
local cached contacts initialized from a simulator-supplied membership view.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from functools import lru_cache, total_ordering, cached_property
from typing import Any, Iterable, Sequence
from decimal import Decimal, localcontext
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import tempfile

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization


class Halt(RuntimeError):
    """No accounting commit; reserved jobs may remain locked for recovery."""


def require(ok: bool, why: str) -> None:
    if not ok:
        raise Halt(why)


@total_ordering
@dataclass(frozen=True)
class Phi:
    a: int = 0
    b: int = 0

    def __post_init__(self) -> None:
        require(type(self.a) is int and type(self.b) is int, 'non-integer phi coefficients')
        require(max(abs(self.a).bit_length(), abs(self.b).bit_length()) <= 65536,
                'configured exact-amount size limit exceeded')

    def __add__(self, x: Phi) -> Phi:
        return Phi(self.a + x.a, self.b + x.b)

    def __sub__(self, x: Phi) -> Phi:
        return Phi(self.a - x.a, self.b - x.b)

    def __mul__(self, x: Phi | int) -> Phi:
        if type(x) is int:
            return Phi(self.a * x, self.b * x)
        return Phi(self.a*x.a+self.b*x.b, self.a*x.b+self.b*x.a+self.b*x.b)

    def __rmul__(self, x: int) -> Phi:
        return self * x

    def positive(self) -> bool:
        p, q = 2*self.a+self.b, self.b
        if q == 0:
            return p > 0
        if q > 0:
            return p >= 0 or 5*q*q > p*p
        return p > 0 and p*p > 5*q*q

    def __lt__(self, x: Phi) -> bool:
        return (x-self).positive()

    def pair(self) -> list[int]:
        return [self.a, self.b]

    @staticmethod
    def parse(x: Any) -> Phi:
        require(type(x) is list and len(x) == 2, 'invalid phi pair')
        return Phi(x[0], x[1])

    def display(self, digits: int = 12) -> str:
        # Display only. Precision includes cancellation margin; never used to decide validity.
        bits = max(abs(self.a).bit_length(), abs(self.b).bit_length())
        with localcontext() as ctx:
            ctx.prec = max(50, int(bits*0.6021)+digits+30)
            phi = (Decimal(1)+Decimal(5).sqrt())/2
            return format(Decimal(self.a)+Decimal(self.b)*phi, f'.{digits}g')


ZERO, ONE, INV = Phi(), Phi(1), Phi(-1, 1)


@lru_cache(maxsize=4096)
def invpow(n: int) -> Phi:
    require(type(n) is int and 0 <= n <= 4096, 'phi exponent outside model limit')
    result, base = ONE, INV
    while n:
        if n & 1:
            result = result * base
        base = base * base
        n >>= 1
    return result


def normalize(x: Any) -> Any:
    if x is None or type(x) in (str, int, bool):
        return x
    if type(x) in (tuple, list):
        return [normalize(y) for y in x]
    if type(x) is dict:
        require(all(type(k) is str for k in x), 'canonical map requires string keys')
        return {k: normalize(v) for k, v in x.items()}
    raise Halt('canonical format forbids floats and executable Python objects')


def canon(x: Any) -> bytes:
    return json.dumps(normalize(x), sort_keys=True, ensure_ascii=True,
                      allow_nan=False, separators=(',', ':')).encode()


def digest(x: Any) -> str:
    return hashlib.sha256(canon(x)).hexdigest()


INSCRIPTION = '''Eric James Wolverton ~ Born Aug 13, 1986
Son of Craig Brian Hissong
Fˣ(a) ≔ x⁻¹(F(x(a)))
Fˣ(a,b) ≔ x⁻¹(F(x(a), x(b)))
Press 0'''
HORIZON = 144
MAX_QUANTUM = 256
MANIFEST = {
    'name': 'Fire Echo', 'version': 5,
    'choices': [['inside', 'outside'], ['east', 'west'], ['speak', 'listen']],
    'age_horizon': HORIZON,
    'mass': 'interval_length * (6 - sum(phi^-min(age_i,144)))',
    'scheduler': 'mass-ordered Merkle-sum tree; global van-der-Corput slot cursor',
    'vm': 'deterministic transition-table TM; resumable metered quanta',
    'quantum_limit': MAX_QUANTUM,
    'compute_price': 'demo quote phi^-32 per newly replayed TM transition plus phi^-32 per bounded result delivery',
    'reuse': 'certified immutable result capsules; pure-result identity separate from one-use payment identity',
    'ports': 'hash(root,owner,right_interval_boundary); state hashes change without rotating every contact',
    'reward_split': 'speaker:phi^-1; listener:phi^-2; both fresh ages',
    'choice_fee': 'input * phi^-12 per changed bit, fresh service fee',
    'scope': 'inside=same requester key; outside=different requester key',
    'authority': 'fixed 7-member committee, threshold 5, at most 2 Byzantine',
    'failure': 'reject or retain recoverable reservation; never invent balances',
}
MANIFEST['implementation_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
PROTOCOL = digest(MANIFEST)
UNIT_PRICE = invpow(32)
DELIVERY_PRICE = UNIT_PRICE
VM_ID = digest({'vm':'fire-echo-deterministic-sparse-tape-v5','step_limit':MAX_QUANTUM,
                'implementation':MANIFEST['implementation_sha256']})


class Identity:
    """Insecure deterministic TEST key; never an actual wallet key."""
    def __init__(self, label: str):
        seed = hashlib.sha256(('PUBLIC TEST KEY ONLY/' + label).encode()).digest()
        self.key = Ed25519PrivateKey.from_private_bytes(seed)
        self.pub = self.key.public_key().public_bytes(serialization.Encoding.Raw,
                                                     serialization.PublicFormat.Raw)
        self.id = hashlib.sha256(self.pub).hexdigest()
        self.label = label

    def sign(self, body: Any) -> str:
        return self.key.sign(canon(body)).hex()

    @staticmethod
    def verify(pub: bytes, body: Any, signature: str) -> bool:
        try:
            Ed25519PublicKey.from_public_bytes(pub).verify(bytes.fromhex(signature), canon(body))
            return True
        except Exception:
            return False


@dataclass(frozen=True)
class Choice:
    bits: tuple[int, int, int]
    since: tuple[int, int, int]

    def __post_init__(self):
        require(len(self.bits) == len(self.since) == 3, 'exactly three choice clocks required')
        require(all(type(b) is int and b in (0, 1) for b in self.bits), 'invalid choice bit')
        require(all(type(e) is int and e >= 0 for e in self.since), 'invalid choice epoch')

    def ages(self, epoch: int) -> tuple[int, ...]:
        require(type(epoch) is int and all(e <= epoch for e in self.since), 'future choice epoch')
        return tuple(epoch-e for e in self.since)

    def density(self, epoch: int) -> Phi:
        # Three times the old 1..2 factor; avoids inexact division by 3.
        return Phi(6)-sum((invpow(min(a,HORIZON)) for a in self.ages(epoch)), ZERO)

    def change(self, bits: Sequence[int], epoch: int) -> Choice:
        require(len(bits) == 3 and all(type(b) is int and b in (0,1) for b in bits), 'invalid bits')
        self.ages(epoch)
        return Choice(tuple(bits), tuple(epoch if x != y else t
                      for x,y,t in zip(self.bits,bits,self.since)))

    @staticmethod
    def fresh(bits: Sequence[int], epoch: int) -> Choice:
        return Choice(tuple(bits), (epoch,)*3)

    def body(self) -> dict:
        return {'bits': list(self.bits), 'since': list(self.since)}


@dataclass(frozen=True)
class Paper:
    root: str
    owner: str
    lo: Phi
    hi: Phi
    choice: Choice
    parent: str
    index: int
    service_seq: int = 0
    service_head: str | None = None

    def __post_init__(self):
        require(ZERO <= self.lo < self.hi <= ONE, 'invalid principal interval')
        require(type(self.service_seq) is int and self.service_seq >= 0, 'bad service sequence')

    @property
    def port(self) -> str:
        # A live, disjoint principal interval has a unique right boundary.
        # Paying from its left edge renews state without changing this address.
        return digest({'root':self.root,'owner':self.owner,'right':self.hi.pair()})

    @property
    def fire(self) -> Phi:
        return self.hi-self.lo

    def mass(self, epoch: int) -> Phi:
        return self.fire*self.choice.density(epoch)

    def spec(self) -> dict:
        return {'owner':self.owner, 'lo':self.lo.pair(), 'hi':self.hi.pair(),
                'choice':self.choice.body(), 'service_seq':self.service_seq,
                'service_head':self.service_head}

    def body(self) -> dict:
        return dict(self.spec(), root=self.root, parent=self.parent,
                    index=self.index, protocol=PROTOCOL)

    @cached_property
    def id(self) -> str:
        return digest(self.body())

    @staticmethod
    def from_body(x: dict) -> Paper:
        require(x['protocol'] == PROTOCOL, 'foreign protocol')
        return Paper(x['root'], x['owner'], Phi.parse(x['lo']), Phi.parse(x['hi']),
                     Choice(tuple(x['choice']['bits']),tuple(x['choice']['since'])),
                     x['parent'], x['index'], x['service_seq'], x['service_head'])


def output(p: Paper, *, lo: Phi | None = None, hi: Phi | None = None,
           owner: str | None = None, choice: Choice | None = None,
           service_seq: int | None = None, service_head: str | None = None,
           reset_service: bool = False) -> dict:
    return {
        'owner': p.owner if owner is None else owner,
        'lo': (p.lo if lo is None else lo).pair(),
        'hi': (p.hi if hi is None else hi).pair(),
        'choice': (p.choice if choice is None else choice).body(),
        'service_seq': 0 if reset_service else (p.service_seq if service_seq is None else service_seq),
        'service_head': None if reset_service else (p.service_head if service_head is None else service_head),
    }


class MassTree:
    """The selection algorithm is descent through this authenticated sum structure."""
    def __init__(self, notes: Sequence[Paper], epoch: int):
        require(bool(notes), 'no eligible offered service')
        ordered = sorted(notes, key=lambda p:p.lo)
        require(all(a.hi <= b.lo for a,b in zip(ordered,ordered[1:])), 'overlapping service offers')
        self.epoch = epoch
        self.paper = ordered[0] if len(ordered) == 1 else None
        if self.paper is not None:
            self.left = self.right = None
            self.mass = self.paper.mass(epoch)
            self.hash = digest({'leaf':self.paper.id,'epoch':epoch,'mass':self.mass.pair()})
        else:
            k = len(ordered)//2
            self.left, self.right = MassTree(ordered[:k],epoch), MassTree(ordered[k:],epoch)
            self.mass = self.left.mass+self.right.mass
            self.hash = digest({'left':self.left.hash,'right':self.right.hash,'mass':self.mass.pair()})

    def select(self, numerator: int, denominator: int) -> Paper:
        require(type(numerator) is type(denominator) is int and 0 <= numerator < denominator,
                'invalid scheduling fraction')
        node, target = self, self.mass*numerator
        while node.paper is None:
            boundary = node.left.mass*denominator
            if target < boundary:
                node = node.left
            else:
                target = target-boundary
                node = node.right
        return node.paper


def slot_fraction(slot: int) -> tuple[int,int]:
    """Deterministic binary radical inverse of slot+1, in (0,1)."""
    require(type(slot) is int and slot >= 0, 'invalid slot')
    n, r, d = slot+1, 0, 1
    while n:
        r, d, n = (r<<1)|(n&1), d<<1, n>>1
    return r,d


@dataclass(frozen=True)
class Snapshot:
    epoch: int
    offers: tuple[Paper, ...]

    @cached_property
    def id(self) -> str:
        return digest(self.body())

    def body(self) -> dict:
        return {'kind':'service-snapshot','epoch':self.epoch,
                'offers':[p.body() for p in sorted(self.offers,key=lambda p:p.lo)]}

    def select(self, payer: Paper, role: int, slot: int, exclude_owner: str | None = None) -> Paper:
        eligible = [p for p in self.offers if p.id != payer.id and p.choice.bits[2] == role
                    and (p.owner != payer.owner) == bool(p.choice.bits[0])
                    and p.owner != exclude_owner]
        return MassTree(eligible,self.epoch).select(*slot_fraction(slot))


class PaperMesh:
    """Local cached contacts backed by paper-derived ports, NOT global discovery.

    Initial neighbors are simulator-supplied. Normal state renewal updates only
    existing port heads. No neighbor list is rebuilt by publish(). New ports
    require a subsequent explicit membership/peer-discovery step (not provided).
    Hosts are modeled by owner keys, not independent people or machines.
    """
    def __init__(self, papers: Sequence[Paper], online: Iterable[str] | None = None):
        require(bool(papers), 'empty mesh')
        self.heads={p.port:p for p in papers}
        require(len(self.heads)==len(papers), 'duplicate paper-derived port')
        ids=sorted(self.heads)
        self.online=set(ids if online is None else online)
        self.contacts={}
        steps=[1,2,3];a,b=3,5
        while b < len(ids):
            steps.append(b);a,b=b,a+b
        for i,h in enumerate(ids):
            self.contacts[h]=tuple(tuple(ids[(i+sign*d)%len(ids)] for d in steps if d < len(ids))
                                   for sign in (1,-1))

    def route(self, source: str, target: str, direction: int, ttl: int=128) -> tuple[str,...]:
        require(source in self.online and target in self.online, 'endpoint unavailable')
        require(type(direction) is int and direction in (0,1), 'bad direction')
        path=[source];current=source;mod=1<<256
        dist=lambda a,b: ((int(b,16)-int(a,16)) if direction==0 else (int(a,16)-int(b,16)))%mod
        while current != target:
            require(len(path)<=ttl, 'routing fuel exhausted')
            remaining=dist(current,target)
            candidates=[p for p in self.contacts.get(current,((),()))[direction]
                        if p in self.online and 0 < dist(current,p) <= remaining]
            require(bool(candidates),'local routing knowledge insufficient')
            current=max(candidates,key=lambda p:dist(current,p));path.append(current)
        return tuple(path)

    def dispatch(self, service: Paper, requester: str, source: Paper, role: int) -> tuple[str,...]:
        require(service.choice.bits[2]==role,'speak/listen role mismatch')
        external=service.owner != requester
        require(external==bool(service.choice.bits[0]),'inside/outside scope mismatch')
        require(service.port in self.heads and self.heads[service.port].id==service.id,
                'stale service head: require committed renewal')
        require(source.port in self.heads and self.heads[source.port].id==source.id,
                'stale source head: require committed renewal')
        require(service.port in self.online and source.port in self.online,'service unavailable')
        if not external and source.owner==service.owner:
            return (source.port,service.port) if source.port!=service.port else (source.port,)
        return self.route(source.port,service.port,service.choice.bits[1])

    def publish(self, protocol: Protocol, inputs: Sequence[Paper], outputs: Sequence[Paper]) -> None:
        """Consume a committed transition announcement, not an invented alias."""
        require(bool(outputs) and len({p.parent for p in outputs})==1,'mixed announcements')
        tx=outputs[0].parent;intent=protocol.get(tx)
        require(intent['inputs']==[p.id for p in inputs],'wrong predecessor heads')
        require([p.body() for p in protocol._make_outputs(intent)]==[p.body() for p in outputs],
                'announcement outputs differ from commit')
        saved=protocol.db.execute('SELECT certificate FROM commits WHERE tx=?',(tx,)).fetchone()
        require(saved is not None,'uncertified announcement')
        cert=protocol.get(saved[0])['certificate']
        resources=(["result:"+intent['details']['job']] if intent['kind']=='settle-quantum'
                   else ['note:'+x for x in intent['inputs']])
        protocol.quorum.verify(cert,protocol.quorum.envelope(tx,resources,intent))
        for p in inputs:
            row=protocol.db.execute('SELECT tx FROM spent WHERE id=?',(p.id,)).fetchone()
            require(row is not None and row[0]==tx,'unconsumed announcement input')
        for p in outputs:
            protocol.live(p.id)
        old_ports={p.port for p in inputs};new={p.port:p for p in outputs}
        # Contacts keep stable ports; only witnessed state heads change.
        for port in old_ports & self.heads.keys():
            if port in new:
                self.heads[port]=new[port]
            else:
                self.online.discard(port)
        # New reward/fracture ports are real paper, but are not magically known peers.


LocalOverlay=PaperMesh

def validate_program(spec: dict) -> dict:
    require(type(spec) is dict and set(spec) == {'start','halt','blank','table'}, 'invalid program fields')
    require(all(type(spec[x]) is str and 0 < len(spec[x]) <= 32 for x in ('start','blank')), 'invalid start state or blank')
    require(type(spec['table']) is list and 1 <= len(spec['table']) <= 256, 'program size limit')
    require(type(spec['halt']) is list and 1 <= len(spec['halt']) <= 256
            and all(type(x) is str and 0 < len(x) <= 32 for x in spec['halt'])
            and len(set(spec['halt'])) == len(spec['halt']), 'invalid halt states')
    table={}
    for row in spec['table']:
        require(type(row) is list and len(row) == 5, 'bad transition row')
        q,s,n,w,d=row
        require(all(type(x) is str and 0 < len(x) <= 32 for x in (q,s,n,w)), 'bad state or symbol')
        require(d in ('L','R','S') and (q,s) not in table, 'non-deterministic or invalid transition')
        table[q,s]=(n,w,d)
    return table


def canonical_program(spec: dict) -> dict:
    validate_program(spec)
    return {'start':spec['start'],'halt':sorted(spec['halt']),'blank':spec['blank'],
            'table':sorted([list(row) for row in spec['table']],key=lambda r:(r[0],r[1]))}


def memo_key(namespace: str, program: str, initial: str, budget: int) -> str:
    return digest({'domain':'pure-machine-result','vm':VM_ID,'namespace':namespace,
                   'program':program,'initial':initial,'budget':budget})


def capsule(run: dict, namespace: str) -> dict:
    return {'kind':'checked-machine-capsule','vm':VM_ID,'namespace':namespace,
            'program':run['program'],'initial':run['input'],'budget':run['budget'],
            'steps':run['steps'],'status':run['status'],'final':run['final'],'trace':run['trace']}


def delivery_receipt(body: dict, cap: dict) -> dict:
    key=memo_key(cap['namespace'],cap['program'],cap['initial'],cap['budget'])
    require(key==body['memo_key'] and cap['vm']==VM_ID, 'capsule bound to another computation')
    require(cap['program']==body['program'] and cap['initial']==body['initial']
            and cap['budget']==body['budget'], 'capsule request mismatch')
    fresh=body['mode']=='EXECUTE'
    return {'kind':'execution-receipt','job':digest(body),'program':cap['program'],'input':cap['initial'],
            'budget':cap['budget'],'steps':cap['steps'],'status':cap['status'],'final':cap['final'],
            'trace':cap['trace'],'mode':body['mode'],'capsule':digest(cap),
            'new_steps':cap['steps'] if fresh else 0,'delivery_units':1}


def initial_state(spec: dict, symbols: Sequence[str]) -> dict:
    require(len(symbols) <= 4096, 'input limit')
    return {'state':spec['start'],'head':0,'cells':[[i,s] for i,s in enumerate(symbols) if s != spec['blank']]}



def validate_initial(spec: dict, initial: dict) -> None:
    require(type(initial) is dict and set(initial) == {'state','head','cells'}, 'invalid machine state')
    require(type(initial['head']) is int and abs(initial['head']).bit_length() <= 63
            and type(initial['cells']) is list
            and len(initial['cells']) <= 8192, 'machine state limit')
    cells=initial['cells']
    require(all(type(row) is list and len(row) == 2 and type(row[0]) is int
                and abs(row[0]).bit_length() <= 63
                and type(row[1]) is str and 0 < len(row[1]) <= 32 and row[1] != spec['blank']
                for row in cells), 'invalid sparse tape')
    require(cells == sorted(cells) and len({x[0] for x in cells}) == len(cells), 'noncanonical tape')
    require(type(initial['state']) is str and 0 < len(initial['state']) <= 32, 'invalid control state')


def mirror_program(spec: dict) -> dict:
    """Explicit Lion Lens: conjugate execution by the tape-coordinate bijection i -> -i."""
    validate_program(spec)
    return dict(spec,table=[[q,s,n,w,{'L':'R','R':'L','S':'S'}[d]] for q,s,n,w,d in spec['table']])


def mirror_state(state: dict) -> dict:
    return {'state':state['state'],'head':-state['head'],
            'cells':sorted([[-i,s] for i,s in state['cells']])}


def run_quantum(spec: dict, initial: dict, budget: int, job_id: str) -> dict:
    require(type(budget) is int and 1 <= budget <= MAX_QUANTUM, 'invalid execution budget')
    table=validate_program(spec)
    validate_initial(spec,initial)
    tape=dict(initial['cells']); state=initial['state']; head=initial['head']; trace=[]
    for _ in range(budget):
        if state in spec['halt']:
            break
        read=tape.get(head,spec['blank'])
        require((state,read) in table, 'undefined machine transition')
        nxt,write,move=table[state,read]
        trace.append([state,head,read,nxt,write,move])
        if write == spec['blank']:
            tape.pop(head,None)
        else:
            tape[head]=write
        head += (move == 'R')-(move == 'L')
        state=nxt
    final={'state':state,'head':head,'cells':[[i,s] for i,s in sorted(tape.items())]}
    # A certified continuation must itself be an admissible next input.
    validate_initial(spec,final)
    return {'kind':'execution-receipt','job':job_id,'program':digest(spec),'input':digest(initial),
            'budget':budget,'steps':len(trace),'status':'HALTED' if state in spec['halt'] else 'SUSPENDED',
            'final':final,'trace':digest(trace)}


UNARY = {'start':'q','halt':['H'],'blank':'_',
         'table':[['q','1','q','1','R'],['q','_','H','1','S']]}
LEFT = {'start':'q','halt':['H'],'blank':'_',
        'table':[['q','1','q','1','L'],['q','_','H','1','S']]}
LOOP = {'start':'q','halt':['H'],'blank':'_',
        'table':[['q','_','q','_','R']]}


class Quorum:
    """Persistent sign-once witness model. Deliberately omits view change/reconfiguration."""
    def __init__(self, directory: Path, root: str, faulty: int = 2):
        self.root=root; self.members=[Identity(f'witness-{i}') for i in range(7)]
        self.faulty=faulty; self.dbs=[]
        for i in range(7):
            c=sqlite3.connect(str(directory/f'witness-{i}.sqlite'))
            c.execute('PRAGMA synchronous=FULL')
            c.execute('CREATE TABLE IF NOT EXISTS locks (resource TEXT PRIMARY KEY, binding TEXT NOT NULL)')
            c.commit(); self.dbs.append(c)

    def envelope(self, binding: str, resources: Sequence[str], payload: dict) -> dict:
        return {'domain':'fire-echo-v5-certificate','root':self.root,'protocol':PROTOCOL,
                'binding':binding,'resources':sorted(resources),'payload':payload}

    def certify(self, binding: str, resources: Sequence[str], payload: dict,
                reachable: Iterable[int] | None = None) -> dict:
        allowed=set(range(7) if reachable is None else reachable)
        require(len(allowed & set(range(7))) >= 5, 'quorum unreachable')
        require(len(set(resources)) == len(resources), 'duplicate reservation resource')
        message=self.envelope(binding,resources,payload); signatures=[]
        for i,(member,c) in enumerate(zip(self.members,self.dbs)):
            if i not in allowed:
                continue
            if i >= self.faulty:
                with c:
                    conflict=any((row:=c.execute('SELECT binding FROM locks WHERE resource=?',(r,)).fetchone())
                                 is not None and row[0] != binding for r in resources)
                    if conflict:
                        continue
                    for r in resources:
                        c.execute('INSERT OR IGNORE INTO locks VALUES (?,?)',(r,binding))
            signatures.append({'signer':member.id,'signature':member.sign(message)})
        require(len(signatures) >= 5, 'conflicting reservations; retain locks for recovery')
        cert={'message':message,'signatures':signatures[:5]}
        self.verify(cert,message)
        return cert

    def verify(self, cert: dict, expected: dict) -> None:
        require(cert.get('message') == expected, 'certificate bound to wrong request')
        signatures=cert.get('signatures',[])
        require(len(signatures) >= 5 and len({s['signer'] for s in signatures}) == len(signatures),
                'duplicate or insufficient signers')
        members={m.id:m.pub for m in self.members}
        for s in signatures:
            require(s['signer'] in members, 'signer outside committee')
            require(Identity.verify(members[s['signer']],expected,s['signature']), 'bad certificate signature')

    def close(self):
        for c in self.dbs:
            c.close()


class Protocol:
    def __init__(self, directory: str | Path | None = None, users: int = 16):
        self._temp=tempfile.TemporaryDirectory() if directory is None else None
        self.directory=Path(self._temp.name if self._temp else directory)
        self.directory.mkdir(parents=True,exist_ok=True)
        self.users=[Identity(f'user-{i}') for i in range(users)]
        self.keys={u.id:u for u in self.users}
        committee=[Identity(f'witness-{i}').id for i in range(7)]
        self.root=digest({'inscription':INSCRIPTION,'protocol':PROTOCOL,'genesis_owner':self.users[0].id,
                          'committee':committee})
        self.quorum=Quorum(self.directory,self.root)
        self.db=sqlite3.connect(str(self.directory/'ledger.sqlite'))
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS cas (id TEXT PRIMARY KEY, data BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS notes (id TEXT PRIMARY KEY, data BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS spent (id TEXT PRIMARY KEY, tx TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS commits (tx TEXT PRIMARY KEY, certificate TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS reservations (note TEXT PRIMARY KEY, job TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS memos (key TEXT PRIMARY KEY, capsule TEXT NOT NULL, certificate TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, data BLOB NOT NULL,
                status TEXT NOT NULL, receipt TEXT, outputs BLOB);
        ''')
        self.db.commit()
        stored=self.meta('root','')
        require(not stored or stored == self.root, 'database belongs to a different pinned protocol')

    def meta(self, key: str, default: str = '0') -> str:
        row=self.db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
        return default if row is None else row[0]

    def setmeta(self,key: str,value: Any):
        self.db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',(key,str(value)))

    @property
    def epoch(self) -> int:
        return int(self.meta('epoch'))

    def put(self, x: Any) -> str:
        raw=canon(x); h=hashlib.sha256(raw).hexdigest()
        self.db.execute('INSERT OR IGNORE INTO cas VALUES (?,?)',(h,raw))
        # No silent repair of corrupted data under an already-present address.
        row=self.db.execute('SELECT data FROM cas WHERE id=?',(h,)).fetchone()
        require(bytes(row[0]) == raw, 'CAS collision or corruption')
        return h

    def get(self, h: str) -> Any:
        row=self.db.execute('SELECT data FROM cas WHERE id=?',(h,)).fetchone()
        require(row is not None, 'missing CAS object')
        raw=bytes(row[0]); require(hashlib.sha256(raw).hexdigest() == h, 'CAS hash mismatch')
        return json.loads(raw)

    def bootstrap(self) -> Paper:
        require(self.meta('root','') == '', 'genesis already exists; cannot mint again')
        body={'kind':'genesis','root':self.root,'inscription':INSCRIPTION,'protocol':PROTOCOL}
        with self.db:
            parent=self.put(body)
            p=Paper(self.root,self.users[0].id,ZERO,ONE,Choice.fresh((0,0,0),0),parent,0)
            self._insert(p); self.put(MANIFEST); self.setmeta('root',self.root)
        return p

    def _insert(self,p:Paper):
        self.put(p.body())
        self.db.execute('INSERT INTO notes VALUES (?,?)',(p.id,canon(p.body())))

    def notes(self) -> list[Paper]:
        return [Paper.from_body(json.loads(raw)) for _,raw in self.db.execute('SELECT id,data FROM notes')]

    def live(self,note_id:str, job: str | None = None) -> Paper:
        row=self.db.execute('SELECT data FROM notes WHERE id=?',(note_id,)).fetchone()
        require(row is not None, 'paper spent or missing')
        p=Paper.from_body(json.loads(row[0]))
        require(p.id == note_id and self.get(note_id) == p.body(), 'note/CAS mismatch')
        p.choice.ages(self.epoch)
        lock=self.db.execute('SELECT job FROM reservations WHERE note=?',(note_id,)).fetchone()
        require(lock is None or lock[0] == job, 'paper reserved for an unfinished job')
        return p

    def total(self) -> Phi:
        return sum((p.fire for p in self.notes()),ZERO)

    def advance(self, reachable: Iterable[int] | None = None) -> None:
        require(not self.db.execute("SELECT 1 FROM jobs WHERE status='PENDING'").fetchone(),
                'resolve pending jobs before epoch change in this model')
        e=self.epoch+1
        payload={'kind':'epoch','epoch':e,'parent':self.meta('epoch_head','GENESIS')}
        cert=self.quorum.certify(digest(payload),[f'epoch:{e}'],payload,reachable)
        with self.db:
            h=self.put({'epoch':payload,'certificate':cert})
            self.setmeta('epoch',e); self.setmeta('epoch_head',h)

    def _make_outputs(self,intent:dict) -> list[Paper]:
        h=digest(intent)
        return [Paper(self.root,s['owner'],Phi.parse(s['lo']),Phi.parse(s['hi']),
                      Choice(tuple(s['choice']['bits']),tuple(s['choice']['since'])),
                      h,i,s['service_seq'],s['service_head']) for i,s in enumerate(intent['outputs'])]

    @staticmethod
    def _coverage(notes: Sequence[Paper]) -> list[tuple[Phi,Phi]]:
        merged=[]
        for p in sorted(notes,key=lambda p:p.lo):
            if merged:
                lo,hi=merged[-1]
                require(hi <= p.lo, 'overlapping Fire intervals')
                if hi == p.lo:
                    merged[-1]=(lo,p.hi); continue
            merged.append((p.lo,p.hi))
        return merged

    def _validate_bundle(self, inputs: Sequence[Paper], outs: Sequence[Paper]):
        require(len({p.id for p in inputs}) == len(inputs), 'duplicate input')
        require(all(p.root == self.root for p in inputs), 'cross-root input')
        require(self._coverage(inputs) == self._coverage(outs), 'Fire coverage changed')
        require(sum((p.fire for p in inputs),ZERO) == sum((p.fire for p in outs),ZERO), 'Fire conservation')
        for p in outs:
            p.choice.ages(self.epoch)
            require(p.owner in self.keys,'unknown recipient key')

    def _apply(self, intent:dict, cert:dict, inputs:Sequence[Paper], extras:Sequence[Any]=(),
               fail_at:str|None=None, job:str|None=None, receipt:str|None=None,
               memo:tuple[str,str,str]|None=None) -> list[Paper]:
        outs=self._make_outputs(intent); self._validate_bundle(inputs,outs)
        tx=digest(intent)
        # Each failpoint below occurs inside one SQLite transaction, not after a partial commit.
        with self.db:
            for p in inputs:
                self.live(p.id,job)
            self.put(intent)
            cert_head=self.put({'kind':'certified-transition','intent':tx,'certificate':cert})
            self.db.execute('INSERT INTO commits VALUES (?,?)',(tx,cert_head))
            for x in extras:
                self.put(x)
            for p in inputs:
                self.db.execute('DELETE FROM notes WHERE id=?',(p.id,))
                self.db.execute('INSERT INTO spent VALUES (?,?)',(p.id,tx))
            if fail_at == 'after_consume':
                raise OSError('injected I/O failure after consumes')
            for i,p in enumerate(outs):
                self._insert(p)
                if i == 0 and fail_at == 'after_first_output':
                    raise OSError('injected I/O failure after first output')
            if job:
                self.db.execute('DELETE FROM reservations WHERE job=?',(job,))
                self.db.execute("UPDATE jobs SET status='DONE',receipt=?,outputs=? WHERE id=?",
                                (receipt,canon([p.id for p in outs]),job))
            if memo:
                key,cap,cert_id=memo
                self.db.execute('INSERT OR IGNORE INTO memos VALUES (?,?,?)',memo)
                row=self.db.execute('SELECT capsule FROM memos WHERE key=?',(key,)).fetchone()
                require(row is not None and row[0]==cap, 'conflicting result cache')
            if fail_at == 'before_commit':
                raise OSError('injected I/O failure before commit')
        return outs

    def _ordinary(self, kind:str, inputs:Sequence[Paper], specs:Sequence[dict],
                  authorizers:Sequence[Identity], details:dict|None=None,
                  reachable:Iterable[int]|None=None, fail_at:str|None=None) -> list[Paper]:
        intent={'kind':kind,'root':self.root,'protocol':PROTOCOL,'epoch':self.epoch,
                'inputs':[p.id for p in inputs],'outputs':list(specs),'details':details or {}}
        outs=self._make_outputs(intent); self._validate_bundle(inputs,outs)
        owners={p.owner for p in inputs}; auth={a.id:a.sign(intent) for a in authorizers}
        require(owners <= auth.keys(), 'missing owner authorization')
        for o in owners:
            require(Identity.verify(self.keys[o].pub,intent,auth[o]),'bad owner signature')
        postcards=[{'recipient':p.owner,'reply_to':inputs[0].owner,'intent':digest(intent)} for p in outs]
        signed=[dict(pc,signature=self.keys[pc['recipient']].sign(pc)) for pc in postcards]
        for pc in signed:
            body={k:v for k,v in pc.items() if k != 'signature'}
            require(Identity.verify(self.keys[pc['recipient']].pub,body,pc['signature']),'invalid postcard')
        cert=self.quorum.certify(digest(intent),['note:'+p.id for p in inputs],intent,reachable)
        return self._apply(intent,cert,inputs,[{'authorizations':auth,'postcards':signed}],fail_at)

    def fracture(self,note_id:str,owner:Identity, **kwargs) -> tuple[Paper,Paper]:
        p=self.live(note_id); require(p.owner == owner.id,'wrong owner')
        mid=p.lo+p.fire*INV
        result=self._ordinary('fracture',[p],[output(p,hi=mid),output(p,lo=mid)],[owner],**kwargs)
        return tuple(result)

    def transfer(self,note_id:str,owner:Identity,recipient:Identity,bits:Sequence[int]|None=None,
                 service:Identity|None=None,**kwargs) -> tuple[Paper,Paper]:
        p=self.live(note_id); require(p.owner == owner.id,'wrong owner')
        bits=p.choice.bits if bits is None else tuple(bits)
        changed=p.choice.change(bits,self.epoch)
        if owner.id != recipient.id:
            changed=Choice.fresh(bits,self.epoch)
        k=sum(a != b for a,b in zip(p.choice.bits,bits))
        fee=p.fire*(invpow(14)+k*invpow(12)); cut=p.lo+fee
        service=service or self.users[-1]
        specs=[output(p,lo=cut,owner=recipient.id,choice=changed,reset_service=owner.id != recipient.id),
               output(p,hi=cut,owner=service.id,choice=Choice.fresh((1,0,1),self.epoch),reset_service=True)]
        return tuple(self._ordinary('transfer',[p],specs,[owner],**kwargs))

    def snapshot(self,offers:Sequence[Paper]) -> Snapshot:
        require(bool(offers), 'empty service snapshot')
        for p in offers:
            self.live(p.id)
        snap=Snapshot(self.epoch,tuple(offers))
        self._coverage(offers)
        payload={'kind':'certify-snapshot','snapshot':snap.id,'epoch':self.epoch}
        cert=self.quorum.certify(snap.id,[f'snapshot:{self.epoch}'],payload)
        with self.db:
            self.put(snap.body()); self.put({'snapshot':snap.id,'certificate':cert})
            self.setmeta('snapshot',snap.id)
        return snap

    def _continuity(self, old:Paper) -> Paper:
        # A snapshot offer may advance by paid work, but not change principal, owner or choices.
        for p in self.notes():
            if (p.lo,p.hi,p.owner,p.choice) == (old.lo,old.hi,old.owner,old.choice):
                return self.live(p.id)
        raise Halt('offered service changed since snapshot; wait for next epoch')

    def checked_memo(self,key:str) -> tuple[dict,str] | None:
        row=self.db.execute('SELECT capsule,certificate FROM memos WHERE key=?',(key,)).fetchone()
        if row is None:
            return None
        cap=self.get(row[0]);saved=self.get(row[1])
        require(type(cap) is dict and cap.get('kind')=='checked-machine-capsule','invalid capsule')
        require(cap.get('vm')==VM_ID,'foreign VM capsule')
        require(key==memo_key(cap['namespace'],cap['program'],cap['initial'],cap['budget']),
                'cache index points to another computation')
        payload={'kind':'certified-machine-result','key':key,'capsule':row[0]}
        require(saved.get('payload')==payload,'capsule certificate mismatch')
        expected=self.quorum.envelope(digest(payload),['memo:'+key],payload)
        self.quorum.verify(saved['certificate'],expected)
        return cap,row[1]

    def prepare(self,payer_id:str,payer:Identity,snapshot:Snapshot,spec:dict,initial:dict,budget:int,
                overlay:LocalOverlay|None=None,reachable:Iterable[int]|None=None) -> str:
        require(snapshot.epoch == self.epoch and snapshot.id == self.meta('snapshot',''), 'uncertified or stale snapshot')
        require(self.get(snapshot.id) == snapshot.body(),'snapshot/CAS mismatch')
        p=self.live(payer_id); require(p.owner == payer.id,'wrong payer')
        spec=canonical_program(spec)
        # Validate/bound state without silently trusting a worker-provided starting state.
        require(type(budget) is int and 1 <= budget <= MAX_QUANTUM,'invalid job budget')
        require(type(initial) is dict, 'invalid initial state')
        require(initial.get('state') not in spec['halt'],'already halted: no new paid work')
        require(len(canon(initial)) <= 1_000_000,'input state too large')
        validate_initial(spec,initial)
        slot=int(self.meta('slot'))
        a=self._continuity(snapshot.select(p,0,slot))
        # External auditing uses a different public key; not a claim of different human operators.
        exclude=a.owner if a.owner != p.owner else None
        b=self._continuity(snapshot.select(p,1,slot,exclude))
        require(len({p.id,a.id,b.id}) == 3,'job input collision')
        network=overlay or LocalOverlay(self.notes())
        outward=network.dispatch(a,p.owner,p,0)
        echo=network.dispatch(b,p.owner,a,1)
        price=UNIT_PRICE
        namespace='public' if a.choice.bits[0] else 'owner:'+p.owner
        key=memo_key(namespace,digest(spec),digest(initial),budget)
        cached=self.checked_memo(key)
        mode='DELIVER' if cached is not None else 'EXECUTE'
        maximum=DELIVERY_PRICE+(price*budget if cached is None else ZERO)
        require(maximum < p.fire,'budget exceeds funding')
        body={'kind':'funded-quantum','root':self.root,'protocol':PROTOCOL,'epoch':self.epoch,
              'snapshot':snapshot.id,'slot':slot,'payer':p.id,'speaker':a.id,'listener':b.id,
              'program':digest(spec),'initial':digest(initial),'budget':budget,'price':price.pair(),
              'outward':list(outward),'echo':list(echo),
              'mode':mode,'namespace':namespace,'memo_key':key,
              'capsule':digest(cached[0]) if cached is not None else None,
              'memo_certificate':cached[1] if cached is not None else None,
              'delivery_price':DELIVERY_PRICE.pair()}
        job=digest(body)
        authorization={'payer':payer.id,'job':job,'max_fee':maximum.pair(),'reply_to':payer.id}
        authsig=payer.sign(authorization)
        require(Identity.verify(payer.pub,authorization,authsig),'bad payer funding signature')
        postcards=[{'job':job,'role':role,'recipient':x.owner,'reply_to':payer.id}
                   for x,role in ((a,'speak'),(b,'listen'))]
        signed=[dict(pc,signature=self.keys[pc['recipient']].sign(pc)) for pc in postcards]
        for pc in signed:
            pcbody={k:v for k,v in pc.items() if k != 'signature'}
            require(Identity.verify(self.keys[pc['recipient']].pub,pcbody,pc['signature']),'bad service postcard')
        cert=self.quorum.certify(job,['note:'+x.id for x in (p,a,b)]+['slot:'+str(slot)],body,reachable)
        with self.db:
            self.put(spec);self.put(initial);self.put(body)
            self.put({'job':job,'authorization':authorization,'signature':authsig,'postcards':signed,'certificate':cert})
            self.db.execute('INSERT INTO jobs VALUES (?,?,\'PENDING\',NULL,NULL)',(job,canon(body)))
            for x in (p,a,b):
                self.db.execute('INSERT INTO reservations VALUES (?,?)',(x.id,job))
            self.setmeta('slot',slot+1)
        return job

    def work(self,job:str) -> dict:
        body=self.get(job)
        a=self.live(body['speaker'],job)
        require(a.choice.bits[2]==0,'only speak services propose or deliver')
        if body['mode']=='DELIVER':
            cached=self.checked_memo(body['memo_key'])
            require(cached is not None and digest(cached[0])==body['capsule']
                    and cached[1]==body['memo_certificate'],'prepared capsule unavailable or changed')
            cap=cached[0]
        else:
            require(body['mode']=='EXECUTE','invalid execution mode')
            cap=capsule(run_quantum(self.get(body['program']),self.get(body['initial']),
                                    body['budget'],job),body['namespace'])
        return delivery_receipt(body,cap)

    def settle(self,job:str,receipt:dict,*,fail_at:str|None=None,
               reachable:Iterable[int]|None=None,bad_signature:bool=False) -> list[Paper]:
        row=self.db.execute('SELECT data,status,receipt,outputs FROM jobs WHERE id=?',(job,)).fetchone()
        require(row is not None,'unknown funded job')
        if row[1] == 'DONE':
            require(row[2] == digest(receipt),'conflicting completion receipt')
            # Idempotent response even if descendants have subsequently moved.
            return [Paper.from_body(self.get(h)) for h in json.loads(row[3])]
        body=json.loads(row[0]); require(digest(body) == job and self.get(job) == body,'job/CAS mismatch')
        p,a,b=[self.live(body[k],job) for k in ('payer','speaker','listener')]
        require(b.choice.bits[2] == 1,'only a listen service checks the echoed result')
        memo=None;extra=[]
        if body['mode']=='DELIVER':
            cached=self.checked_memo(body['memo_key'])
            require(cached is not None and digest(cached[0])==body['capsule']
                    and cached[1]==body['memo_certificate'],'prepared capsule unavailable or changed')
            cap=cached[0]
        else:
            require(body['mode']=='EXECUTE','invalid execution mode')
            cap=capsule(run_quantum(self.get(body['program']),self.get(body['initial']),
                                    body['budget'],job),body['namespace'])
        expected=delivery_receipt(body,cap)
        require(canon(receipt)==canon(expected),'wrong input, result, job, trace, mode or budget')
        require(receipt['steps'] > 0,'no paid progress')
        rh=digest(receipt)
        echo={'job':job,'receipt':rh,'recipient':b.owner,'reply_to':p.owner}
        signature=self.keys[b.owner].sign(dict(echo,forged=True) if bad_signature else echo)
        require(Identity.verify(self.keys[b.owner].pub,echo,signature),'forged result postcard')
        speaker_sig=self.keys[a.owner].sign({'job':job,'receipt':rh})
        require(Identity.verify(self.keys[a.owner].pub,{'job':job,'receipt':rh},speaker_sig),'forged worker receipt')
        if body['mode']=='EXECUTE':
            payload={'kind':'certified-machine-result','key':body['memo_key'],'capsule':digest(cap)}
            ccert=self.quorum.certify(digest(payload),['memo:'+body['memo_key']],payload,reachable)
            saved={'payload':payload,'certificate':ccert}
            extra=[cap,saved];memo=(body['memo_key'],digest(cap),digest(saved))
        fee=Phi.parse(body['price'])*receipt['new_steps']+Phi.parse(body['delivery_price'])
        fa,fb=fee*INV,fee*invpow(2)
        require(fa+fb == fee and ZERO < fee < p.fire,'invalid metered fee')
        ca,cb=p.lo+fa,p.lo+fee
        specs=[output(p,lo=cb),
               output(a,service_seq=a.service_seq+1,service_head=rh),
               output(b,service_seq=b.service_seq+1,service_head=rh),
               output(p,hi=ca,owner=a.owner,choice=Choice.fresh(a.choice.bits,self.epoch),reset_service=True),
               output(p,lo=ca,hi=cb,owner=b.owner,choice=Choice.fresh(b.choice.bits,self.epoch),reset_service=True)]
        intent={'kind':'settle-quantum','root':self.root,'protocol':PROTOCOL,'epoch':self.epoch,
                'inputs':[x.id for x in (p,a,b)],'outputs':specs,
                'details':{'job':job,'receipt':rh,'steps':receipt['steps'],
                           'mode':body['mode'],'new_steps':receipt['new_steps'],'memo_key':body['memo_key'],
                           'fee':fee.pair(),'capsule':digest(cap),
                           'memo_certificate':memo[2] if memo else body['memo_certificate']}}
        self._validate_bundle((p,a,b),self._make_outputs(intent))
        cert=self.quorum.certify(digest(intent),['result:'+job],intent,reachable)
        return self._apply(intent,cert,(p,a,b),extra+[receipt,receipt['final'],
                           {'echo':echo,'signature':signature,'speaker_signature':speaker_sig}],
                           fail_at,job,rh,memo)

    def audit(self) -> dict:
        notes=self.notes()
        require(self._coverage(notes) == [(ZERO,ONE)],'root principal no longer partitions exactly')
        require(self.total() == ONE,'nonconserved Fire')
        verified_parents=set()
        for p in notes:
            require(self.get(p.id) == p.body(),'CAS paper mismatch')
            parent=self.get(p.parent)
            if parent.get('kind') != 'genesis' and p.parent not in verified_parents:
                row=self.db.execute('SELECT certificate FROM commits WHERE tx=?',(p.parent,)).fetchone()
                require(row is not None,'missing transition certificate index')
                saved=self.get(row[0])
                resources=(["result:"+parent['details']['job']] if parent['kind'] == 'settle-quantum'
                           else ['note:'+x for x in parent['inputs']])
                self.quorum.verify(saved['certificate'],self.quorum.envelope(p.parent,resources,parent))
                verified_parents.add(p.parent)
            if p.service_head:
                self.get(p.service_head)
        for (key,) in self.db.execute('SELECT key FROM memos'):
            self.checked_memo(key)
        return {'supply':self.total().pair(),'live_papers':len(notes),
                'certified_result_capsules':self.db.execute('SELECT count(*) FROM memos').fetchone()[0],
                'pending_jobs':self.db.execute("SELECT count(*) FROM jobs WHERE status='PENDING'").fetchone()[0],
                'paid_jobs':self.db.execute("SELECT count(*) FROM jobs WHERE status='DONE'").fetchone()[0],
                'epoch':self.epoch,'slots_reserved':int(self.meta('slot'))}

    def close(self):
        self.db.close(); self.quorum.close()
        if self._temp:
            self._temp.cleanup()


def demo(jobs:int=12) -> dict:
    p=Protocol(); g=p.bootstrap(); payer,rest=p.fracture(g.id,p.users[0]); s,l=p.fracture(rest.id,p.users[0])
    s,_=p.transfer(s.id,p.users[0],p.users[1],(1,0,0))
    l,_=p.transfer(l.id,p.users[0],p.users[2],(1,1,1))
    for _ in range(12): p.advance()
    snap=p.snapshot([s,l]);mesh=PaperMesh(p.notes());states=[]
    for i in range(jobs):
        spec=UNARY if i%2 == 0 else LOOP
        initial=initial_state(spec,tuple('111') if i%2 == 0 else ())
        job=p.prepare(payer.id,p.users[0],snap,spec,initial,8,overlay=mesh)
        body=p.get(job);inputs=[p.live(body[k],job) for k in ('payer','speaker','listener')]
        receipt=p.work(job);out=p.settle(job,receipt);mesh.publish(p,inputs,out);payer=out[0]
        states.append({'job':job,'logical_steps':receipt['steps'],'new_steps':receipt['new_steps'],
                       'mode':receipt['mode'],'status':receipt['status']})
    out={'model':'Fire Echo v5; public test keys, not production','audit':p.audit(),'quanta':states}
    p.close();return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['demo'],nargs='?',default='demo')
    parser.add_argument('--jobs',type=int,default=12)
    args=parser.parse_args()
    require(1 <= args.jobs <= 10000,'jobs outside model limit')
    print(json.dumps(demo(args.jobs),indent=2))


if __name__ == '__main__':
    main()
