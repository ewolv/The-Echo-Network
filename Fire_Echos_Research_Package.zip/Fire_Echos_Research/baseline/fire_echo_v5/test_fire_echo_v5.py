#!/usr/bin/env python3
"""Reproducible research tests, not a security certification or a network benchmark."""
from __future__ import annotations
import argparse, copy, itertools, json, random, statistics, tempfile, time, sys
from pathlib import Path
from dataclasses import replace
from collections import Counter
import fire_echo_v5 as f
import legacy_regressions as legacy
import baseline_v4 as baseline
SEED=20260906

def halt(fn):
    try: fn()
    except f.Halt:return
    raise AssertionError('expected fail-closed rejection')

def stamp(p):
    # Accounting plus result-cache state, not read-only verification effort.
    return (tuple(sorted(x.id for x in p.notes())), p.total().pair(),
            tuple(p.db.execute('SELECT key,capsule,certificate FROM memos ORDER BY key')),
            tuple(p.db.execute('SELECT id,status,receipt,outputs FROM jobs ORDER BY id')))

class Meter:
    """Instrument interpreter calls rather than infer physical work from a receipt."""
    def __init__(self):
        self.original=f.run_quantum;self.phase='other';self.steps=Counter();self.calls=Counter()
    def __enter__(self):
        def counted(*a,**k):
            r=self.original(*a,**k);self.steps[self.phase]+=r['steps'];self.calls[self.phase]+=1
            return r
        f.run_quantum=counted;return self
    def __exit__(self,*args):f.run_quantum=self.original
    def invoke(self,phase,fn):
        old=self.phase;self.phase=phase
        try:return fn()
        finally:self.phase=old

def fixture(path=None,inside=False):
    p=f.Protocol(path);g=p.bootstrap();payer,rest=p.fracture(g.id,p.users[0]);a,b=p.fracture(rest.id,p.users[0])
    a,_=p.transfer(a.id,p.users[0],p.users[0 if inside else 1],(0 if inside else 1,0,0))
    b,_=p.transfer(b.id,p.users[0],p.users[0 if inside else 2],(0 if inside else 1,1,1))
    for _ in range(5):p.advance()
    snap=p.snapshot([a,b]);mesh=f.PaperMesh(p.notes())
    return p,payer,a,b,snap,mesh

def prepare(p,payer,snap,mesh,spec=None,initial=None,budget=32):
    spec=f.UNARY if spec is None else spec
    initial=f.initial_state(spec,'1'*15) if initial is None else initial
    return p.prepare(payer.id,p.keys[payer.owner],snap,spec,initial,budget,overlay=mesh)

def complete(p,job,mesh,meter=None):
    body=p.get(job);ins=[p.live(body[k],job) for k in ('payer','speaker','listener')]
    receipt=p.work(job) if meter is None else meter.invoke('speaker',lambda:p.work(job))
    outs=p.settle(job,receipt) if meter is None else meter.invoke('listener',lambda:p.settle(job,receipt))
    mesh.publish(p,ins,outs)
    return outs,receipt

def negative_controls():
    # Real v4: every repeat re-executes. Changing note hashes also invalidates old contacts.
    p=baseline.Protocol();g=p.bootstrap();payer,rest=p.fracture(g.id,p.users[0]);a,b=p.fracture(rest.id,p.users[0])
    a,_=p.transfer(a.id,p.users[0],p.users[1],(1,0,0));b,_=p.transfer(b.id,p.users[0],p.users[2],(1,1,1))
    snap=p.snapshot([a,b]);net=baseline.LocalOverlay(p.notes());worker_steps=0;old_target=a.id
    for _ in range(8):
        job=p.prepare(payer.id,p.users[0],snap,baseline.UNARY,baseline.initial_state(baseline.UNARY,'1'*15),32)
        r=p.work(job);worker_steps+=r['steps'];out=p.settle(job,r);payer=out[0];new_a=out[1]
    failed=False
    try:net.route(old_target,new_a.id,0)
    except baseline.Halt:failed=True
    assert failed and worker_steps==128;p.close()
    # No old bit can speed a cold program; age and result reuse are different properties.
    ages=[]
    for age in (0,21,144):
        c=f.Choice((1,0,0),(0,0,0));c.density(age)
        ages.append(f.run_quantum(f.UNARY,f.initial_state(f.UNARY,'1'*15),32,'age-control')['steps'])
    assert ages==[16,16,16]
    # Why paying one ticket per note fails without conserved-mass weighting.
    return {'v4_repeated_requests':8,'v4_worker_steps':worker_steps,
            'v4_old_hash_contacts_fail_after_renewal':failed,
            'cold_execution_steps_at_ages_0_21_144':ages,
            'naive_64_fragments_share_against_one_equal_paper':64/65,
            'finding':'Age is policy seniority, not a physical speedup. Reuse needs retained verified results.'}

def reuse_and_billing(jobs=128):
    p,payer,a,b,snap,mesh=fixture();contacts=copy.deepcopy(mesh.contacts);modes=Counter();fees=[]
    old_heads=(a.id,b.id);ports=(a.port,b.port);initial=f.initial_state(f.UNARY,'1'*31)
    with Meter() as meter:
        for _ in range(jobs):
            job=prepare(p,payer,snap,mesh,initial=initial,budget=64)
            out,r=complete(p,job,mesh,meter);payer=out[0];modes[r['mode']]+=1
            fees.append(out[3].fire+out[4].fire)
            assert (out[1].port,out[2].port)==ports and mesh.contacts==contacts
            assert out[1].choice==a.choice and out[2].choice==b.choice
    assert modes=={'EXECUTE':1,'DELIVER':jobs-1}
    assert meter.steps=={'speaker':32,'listener':32}
    assert fees[0]==f.UNIT_PRICE*33 and all(x==f.DELIVERY_PRICE for x in fees[1:])
    assert out[1].id!=old_heads[0] and out[2].id!=old_heads[1]
    current=stamp(p);assert [x.id for x in p.settle(job,r)]==[x.id for x in out] and stamp(p)==current
    audit=p.audit();p.close()
    naive=f.UNIT_PRICE*(33*jobs);actual=sum(fees,f.ZERO)
    return {'requests':jobs,'modes':dict(modes),'actual_interpreter_steps':dict(meter.steps),
            'without_reuse_worker_plus_listener_steps':64*jobs,
            'with_reuse_worker_plus_listener_steps':64,
            'TM_transition_reduction_fraction':1-1/jobs,
            'modeled_cold_fee_units':33,'modeled_repeat_delivery_fee_units':1,
            'total_fees_exact':actual.pair(),'total_fees_display':actual.display(),
            'total_fees_without_reuse_display':naive.display(),
            'total_fee_reduction_fraction':1-float(actual.display())/float(naive.display()),
            'neighbor_table_rebuilds':0,'result_capsules':audit['certified_result_capsules'],
            'settlement_replay_extra_payments':0,'audit':audit}

def dependency_and_scope():
    p,payer,a,b,snap,mesh=fixture();record=[]
    scenarios=[('baseline',f.UNARY,f.initial_state(f.UNARY,'111'),8,'EXECUTE'),
               ('identical',f.UNARY,f.initial_state(f.UNARY,'111'),8,'DELIVER'),
               ('table_order_only',dict(f.UNARY,table=list(reversed(f.UNARY['table']))),f.initial_state(f.UNARY,'111'),8,'DELIVER'),
               ('changed_input',f.UNARY,f.initial_state(f.UNARY,'11'),8,'EXECUTE'),
               ('changed_budget',f.UNARY,f.initial_state(f.UNARY,'111'),16,'EXECUTE'),
               ('changed_program',f.LEFT,f.initial_state(f.LEFT,'111'),8,'EXECUTE')]
    for name,spec,initial,budget,expected in scenarios:
        job=prepare(p,payer,snap,mesh,spec,initial,budget);out,r=complete(p,job,mesh);payer=out[0]
        assert r['mode']==expected;record.append({'change':name,'mode':r['mode']})
    # A route-direction change resets only that clock and does not change pure-result identity.
    a=p._continuity(a);b=p._continuity(b);old_age=a.choice.ages(p.epoch);old_port=a.port
    new,fee=p.transfer(a.id,p.keys[a.owner],p.keys[a.owner],(1,1,0))
    mesh.publish(p,[a],[new,fee]);assert new.choice.ages(p.epoch)==(old_age[0],0,old_age[2]) and new.port==old_port
    p.advance();snap=p.snapshot([new,b])
    job=prepare(p,payer,snap,mesh,initial=f.initial_state(f.UNARY,'111'),budget=8)
    out,r=complete(p,job,mesh);assert r['mode']=='DELIVER';record.append({'change':'east_to_west','mode':r['mode']})
    # Signed capsules live in authorization namespaces, not accidentally public aliases.
    cap_key=p.get(job)['memo_key'];body=p.get(job)
    own_key=f.memo_key('owner:'+payer.owner,body['program'],body['initial'],body['budget'])
    assert own_key!=cap_key and p.checked_memo(own_key) is None
    p.audit();p.close()
    # Test an actual inside job stores a differently scoped capsule.
    pp,pa,aa,bb,ss,mm=fixture(inside=True);jj=prepare(pp,pa,ss,mm,initial=f.initial_state(f.UNARY,'111'),budget=8)
    oo,rr=complete(pp,jj,mm);bbd=pp.get(jj)
    assert bbd['namespace']=='owner:'+pa.owner and bbd['memo_key']!=cap_key
    pp.audit();pp.close()
    return {'dependency_cases':record,'scope_namespaces_do_not_alias':True,
            'scope_is_authorization_not_encryption':True,'channel_local_clock_reset':'PASS'}

def attacks_and_recovery():
    checks=[]
    p,payer,a,b,snap,mesh=fixture()
    j=prepare(p,payer,snap,mesh,initial=f.initial_state(f.UNARY,''),budget=8)
    r=p.work(j);before=stamp(p)
    for field,val in [('new_steps',True),('delivery_units',True),('mode','DELIVER'),('capsule','0'*64)]:
        bad=dict(r);bad[field]=val;halt(lambda bad=bad:p.settle(j,bad));assert stamp(p)==before
        checks.append('reject malformed '+field)
    ins=[p.live(p.get(j)[k],j) for k in ('payer','speaker','listener')]
    out=p.settle(j,r);mesh.publish(p,ins,out);payer=out[0]
    # A valid previous payment receipt is not authorization for a new payment.
    j2=prepare(p,payer,snap,mesh,initial=f.initial_state(f.UNARY,''),budget=8);fresh=p.work(j2);before=stamp(p)
    halt(lambda:p.settle(j2,r));assert stamp(p)==before;checks.append('old receipt cannot pay a new job')
    bad=dict(fresh,mode='EXECUTE',new_steps=fresh['steps'])
    halt(lambda:p.settle(j2,bad));assert stamp(p)==before;checks.append('cached result cannot bill new transitions')
    # Failed outcome verification leaves the already-reserved authorized inputs intact.
    halt(lambda:p.settle(j2,fresh,reachable=[0,1,2,3]));assert stamp(p)==before;checks.append('subquorum delivery remains pending')
    out2=p.settle(j2,fresh);payer=out2[0];audit=p.audit();p.close()
    # The cache must be checked, not trusted because it is under a hash-looking name.
    for corruption in ('data','missing','certificate','foreign_key'):
        p,payer,a,b,snap,mesh=fixture();j=prepare(p,payer,snap,mesh);out,r=complete(p,j,mesh);payer=out[0]
        body=p.get(j);key=body['memo_key'];row=p.db.execute('SELECT capsule,certificate FROM memos WHERE key=?',(key,)).fetchone()
        if corruption=='data':
            with p.db:p.db.execute('UPDATE cas SET data=? WHERE id=?',(b'{}',row[0]))
        elif corruption=='missing':
            with p.db:p.db.execute('DELETE FROM cas WHERE id=?',(row[0],))
        elif corruption=='certificate':
            saved=p.get(row[1]);msg=saved['certificate']['message']
            saved['certificate']['signatures']=[{'signer':u.id,'signature':u.sign(msg)} for u in p.users[3:8]]
            with p.db:
                h=p.put(saved);p.db.execute('UPDATE memos SET certificate=? WHERE key=?',(h,key))
        else:
            fake_key=f.digest('foreign-key')
            with p.db:p.db.execute('UPDATE memos SET key=? WHERE key=?',(fake_key,key))
            key=fake_key
        before=stamp(p);halt(lambda:p.checked_memo(key));assert stamp(p)==before;checks.append('reject cache '+corruption);p.close()
    for failpoint in ('after_consume','after_first_output','before_commit'):
        with tempfile.TemporaryDirectory() as directory:
            p,payer,a,b,snap,mesh=fixture(directory);j=prepare(p,payer,snap,mesh);r=p.work(j);before=stamp(p)
            try:p.settle(j,r,fail_at=failpoint)
            except OSError:pass
            else:raise AssertionError('missing injected failure')
            assert stamp(p)==before and p.db.execute('SELECT count(*) FROM memos').fetchone()[0]==0
            p.close();p=f.Protocol(directory);assert stamp(p)==before
            out=p.settle(j,r);assert p.audit()['certified_result_capsules']==1
            state=stamp(p);p.settle(j,r);assert stamp(p)==state;p.close()
        checks.append('cache and money rollback together: '+failpoint)
    return {'passed_checks':checks,'count':len(checks),'post_attack_audit':audit}

def resource_closure():
    # Reproduce the boundary found after the first v5 pass, now require safe rejection.
    spec={'start':'q','halt':['H'],'blank':'_', 'table':[['q','_','H','1','S']]}
    initial={'state':'q','head':8192,'cells':[[i,'1'] for i in range(8192)]}
    f.validate_initial(spec,initial)
    halt(lambda:f.run_quantum(spec,initial,1,'overfull-result'))
    edge={'state':'q','head':(1<<63)-1,'cells':[]}
    halt(lambda:f.run_quantum(f.LOOP,edge,1,'overwide-head'))
    p,payer,a,b,snap,mesh=fixture()
    job=prepare(p,payer,snap,mesh,spec,initial,1);before=stamp(p)
    halt(lambda:p.work(job));assert stamp(p)==before
    audit=p.audit();assert audit['pending_jobs']==1 and audit['supply']==[1,0]
    p.close()
    return {'overfull_continuation_rejected':True,'overwide_head_rejected':True,
            'no_payment_for_resource_failure':True,'funding_left_reserved':True,
            'certified_cancellation_implemented':False,'audit':audit}


def paid_age(jobs=384):
    rng=random.Random(SEED);p=f.Protocol();g=p.bootstrap();left,old=p.fracture(g.id,p.users[0])
    young,rest=p.fracture(left.id,p.users[0]);payer,listener=p.fracture(rest.id,p.users[0])
    old,_=p.transfer(old.id,p.users[0],p.users[1],(1,0,0));listener,_=p.transfer(listener.id,p.users[0],p.users[3],(1,1,1))
    for _ in range(21):p.advance()
    young,_=p.transfer(young.id,p.users[0],p.users[2],(1,0,0));assert old.fire==young.fire
    snap=p.snapshot([old,young,listener]);mesh=f.PaperMesh(p.notes());contacts=copy.deepcopy(mesh.contacts)
    counts=Counter();earnings={old.owner:f.ZERO,young.owner:f.ZERO};modes=Counter()
    with Meter() as meter:
        for _ in range(jobs):
            initial=f.initial_state(f.UNARY,'1'*rng.randrange(1,33))
            job=prepare(p,payer,snap,mesh,initial=initial,budget=64)
            out,r=complete(p,job,mesh,meter);payer=out[0]
            counts[out[1].owner]+=1;earnings[out[3].owner]+=out[3].fire;modes[r['mode']]+=1
            assert mesh.contacts==contacts
    assert counts[old.owner] > counts[young.owner]
    report={'paid_deliveries':jobs,'equal_initial_service_fire':True,
            'old_choice_ages':[21,21,21],'young_choice_ages':[0,0,0],
            'old_allocations':counts[old.owner],'young_allocations':counts[young.owner],
            'old_Fire_fees_display':earnings[old.owner].display(),
            'young_Fire_fees_display':earnings[young.owner].display(),
            'old_Fire_fees_exact':earnings[old.owner].pair(),'young_Fire_fees_exact':earnings[young.owner].pair(),
            'modes':dict(modes),'actual_interpreter_steps':dict(meter.steps),'audit':p.audit()}
    p.close();return report

def routes_and_modes():
    rng=random.Random(SEED);pool=[legacy.synthetic(f.ZERO,f.ONE,'owner-0')]
    for depth in range(7):
        out=[]
        for p in pool:
            mid=p.lo+p.fire*f.INV
            out.extend([replace(p,hi=mid,parent=f'd{depth}',index=0),replace(p,lo=mid,parent=f'd{depth}',index=1)])
        pool=out
    pool=[replace(p,owner=f'host-{i%32}') for i,p in enumerate(pool)]
    mesh=f.PaperMesh(pool);ids=list(mesh.heads);hops=[]
    for i in range(2000):
        source,target=rng.sample(ids,2);path=mesh.route(source,target,i%2);assert path[-1]==target;hops.append(len(path)-1)
    # All papers for each failed owner go offline together.
    failed=set(rng.sample([f'host-{i}' for i in range(32)],10))
    mesh.online={k for k,n in mesh.heads.items() if n.owner not in failed}
    survivors=sorted(mesh.online);counts=Counter()
    for i in range(2000):
        source,target=rng.sample(survivors,2)
        try:path=mesh.route(source,target,i%2);assert path[-1]==target;counts['delivered']+=1
        except f.Halt:counts['halted']+=1
    assert sum(counts.values())==2000
    # Physical partition modeled by distinct reachability sets, no perfect-ring reconstruction.
    half=set(sorted(mesh.heads)[:64]);mesh.online=half;cross=0
    for i in range(500):
        source=rng.choice(sorted(half));target=rng.choice(sorted(set(ids)-half))
        halt(lambda:mesh.route(source,target,i%2));cross+=1
    modes=[]
    for scope,direction,role in itertools.product((0,1),repeat=3):
        source=pool[0];service=replace(pool[1],owner=source.owner if scope==0 else 'external',choice=f.Choice((scope,direction,role),(0,0,0)))
        net=f.PaperMesh([source,service]+pool[2:]);path=net.dispatch(service,source.owner,source,role)
        halt(lambda:net.dispatch(service,source.owner,source,1-role))
        modes.append({'bits':[scope,direction,role],'route_hops':len(path)-1})
    return {'logical_ports':128,'modeled_owners':32,'healthy_routes':2000,'mean_hops':statistics.mean(hops),'max_hops':max(hops),
            'whole_owners_offline':10,'surviving_ports':len(survivors),'after_churn':dict(counts),
            'cross_partition_halts':cross,'dispatch_modes':modes}

def stress(jobs=1200,seed=SEED):
    rng=random.Random(seed);p=f.Protocol(users=40);g=p.bootstrap();pool=[g]
    for _ in range(5):
        out=[]
        for n in pool:out.extend(p.fracture(n.id,p.users[0]))
        pool=out
    payers=pool[:8];services={}
    for i,n in enumerate(pool[8:]):
        ss,_=p.transfer(n.id,p.users[0],p.users[i+1],(1,rng.randrange(2),i%2));services[ss.id]=ss
        if i%4==0:p.advance()
    for _ in range(6):p.advance()
    snap=p.snapshot(list(services.values()));mesh=f.PaperMesh(p.notes());contacts=copy.deepcopy(mesh.contacts)
    counts=Counter();logical_steps=0;new_steps=0;checkpoint=f.initial_state(f.LOOP,[])
    with Meter() as meter:
        for i in range(jobs):
            if i and i%100==0:
                p.advance();old=rng.choice(list(services.values()));bits=list(old.choice.bits);bits[1]^=1
                newer,fee=p.transfer(old.id,p.keys[old.owner],p.keys[old.owner],bits)
                mesh.publish(p,[old],[newer,fee]);del services[old.id];services[newer.id]=newer
                counts['paid_direction_changes']+=1;snap=p.snapshot(list(services.values()))
            pi=rng.randrange(len(payers));payer=payers[pi];kind=rng.randrange(4)
            if kind in (0,1):
                spec=f.UNARY;initial=f.initial_state(spec,'1'*rng.randrange(1,25));budget=32
            elif kind==2:
                spec=f.LEFT;initial=f.initial_state(spec,'111');budget=8
            else:
                spec=f.LOOP;initial=checkpoint;budget=rng.randrange(1,17)
            if i%41==0:
                before=stamp(p)
                halt(lambda:p.prepare(payer.id,p.keys[payer.owner],snap,spec,initial,budget,overlay=mesh,reachable=[0,1,2,3]))
                assert stamp(p)==before;counts['subquorum_prepare_rejected']+=1
            job=prepare(p,payer,snap,mesh,spec,initial,budget);body=p.get(job)
            ins=[p.live(body[k],job) for k in ('payer','speaker','listener')]
            r=meter.invoke('speaker',lambda:p.work(job))
            if i%29==0:
                before=stamp(p);bad=dict(r,trace='bad-trace')
                halt(lambda:meter.invoke('rejected_check',lambda:p.settle(job,bad)))
                assert stamp(p)==before;counts['tampered_receipts_rejected']+=1
            if i%97==0:
                before=stamp(p)
                try:meter.invoke('rollback_check',lambda:p.settle(job,r,fail_at='after_first_output'))
                except OSError:pass
                else:raise AssertionError('rollback not injected')
                assert stamp(p)==before;counts['rolled_back_and_retried']+=1
            out=meter.invoke('listener',lambda:p.settle(job,r));mesh.publish(p,ins,out)
            del services[body['speaker']];del services[body['listener']]
            services[out[1].id]=out[1];services[out[2].id]=out[2];payers[pi]=out[0]
            counts[r['mode']]+=1;counts[r['status']]+=1;new_steps+=r['new_steps'];logical_steps+=r['steps']
            if kind==3:checkpoint=r['final']
            assert mesh.contacts==contacts
            if i%100==0:assert p.total()==f.ONE
        measured=dict(meter.steps)
    audit=p.audit();assert audit['paid_jobs']==jobs and audit['pending_jobs']==0 and audit['supply']==[1,0]
    assert measured['speaker']==measured['listener']==new_steps
    p.close();return {'seed':seed,'completed_jobs':jobs,'metrics':dict(counts),'logical_TM_steps_delivered':logical_steps,
                      'new_TM_steps_paid':new_steps,'instrumented_interpreter_steps':measured,
                      'neighbor_table_rebuilds':0,'final_audit':audit}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--jobs',type=int,default=1200);ap.add_argument('--seed',type=int,default=SEED)
    ap.add_argument('--out',default='test_results_v5.json');ap.add_argument('--stress-only',action='store_true');args=ap.parse_args()
    assert 1<=args.jobs<=10000
    result={'status':'RUNNING','seed':args.seed,'protocol_id':f.PROTOCOL,'python':sys.version.split()[0],'tests':{}}
    started=time.perf_counter()
    functions=[('v4_negative_controls',negative_controls),('exact_phi',legacy.exact_properties),
               ('mass_split_invariance',legacy.scheduler_properties),('TM_and_lens',legacy.machine_properties),
               ('baseline_safety_on_v5',legacy.safety_and_recovery),('quorum_boundary',legacy.quorum_bound),
               ('abrupt_process_exit',legacy.abrupt_process_crash),('price_split_invariance',legacy.pricing_is_not_paper_size),
               ('self_service_no_mint',legacy.self_work_does_not_mint),('result_reuse_and_billing',reuse_and_billing),
               ('precise_dependencies_and_scope',dependency_and_scope),('cache_attacks_and_crashes',attacks_and_recovery),('continuation_resource_closure',resource_closure),
               ('funded_aging_example',paid_age),('stale_local_routes_and_modes',routes_and_modes)]
    if args.stress_only:functions=[]
    functions.append(('mixed_paid_network',lambda:stress(args.jobs,args.seed)))
    for name,fn in functions:
        tick=time.perf_counter();print('RUN',name,flush=True)
        try:result['tests'][name]=fn()
        except Exception as e:
            result['status']='FAIL';result['failed_test']=name;result['error']=repr(e)
            Path(args.out).write_text(json.dumps(result,indent=2)+'\n');raise
        print('PASS',name,round(time.perf_counter()-tick,3),'seconds',flush=True)
        Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
    result['status']='PASS';result['elapsed_seconds']=round(time.perf_counter()-started,3)
    Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'seconds':result['elapsed_seconds'],'output':args.out}),flush=True)
if __name__=='__main__':main()
