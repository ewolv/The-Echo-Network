#!/usr/bin/env python3
"""Exact symbolic derivations and complete finite Boolean checks for Fire Echos.
CAS here means SymPy computer algebra, not content-addressed storage.
"""
from __future__ import annotations
import argparse, itertools, json, platform, time
from pathlib import Path
import sympy as s
from sympy.logic.boolalg import SOPform, simplify_logic
import fire_echos_s1 as f


def run() -> dict:
    started=time.perf_counter();phi=(1+s.sqrt(5))/2
    w,w1,w2=s.symbols('w w1 w2', nonnegative=True)
    g0,g1,g2=s.symbols('g0 g1 g2', nonnegative=True)
    a,H,d0,c=s.symbols('a H d0 c', positive=True)
    rho=s.symbols('rho',positive=True)
    records={}
    def identity(name, expression):
        reduced=s.simplify(expression)
        assert reduced==0,(name,reduced)
        records[name]={'residual':str(reduced),'status':'PASS'}
    identity('phi_defining_equation',phi**2-phi-1)
    identity('exact_fracture',w/phi+w/phi**2-w)
    identity('symbolic_mul_reduction',(w1+w2*phi)*(g0+g1*phi)-(w1*g0+w2*g1+(w1*g1+w2*g0+w2*g1)*phi))
    density=6-g0-g1-g2
    identity('no_weight_by_fracture',(w1+w2)*density-w1*density-w2*density)
    identity('selective_reset_loss',w*density-w*(6-1-g1-g2)-w*(1-g0))
    identity('courier_conservation',w-(w-w1-w2)-w1-w2)
    identity('service_fee_fracture',w-w/phi-w/phi**2)
    identity('zero_supply_cut',s.solve(s.Eq(0,w1+w2),w1)[0]+w2)
    t,r,v,step=s.symbols('t r v step',real=True)
    identity('moving_frame_conjugacy',(r+v*t+step)-v*(t+1)-(r+step-v))
    identity('aging_gap_transport',phi**(-(a+1))-phi**(-a)/phi)
    # Baseline and final choice law: increasing but concave forfeited opportunity.
    forfeiture=w*(1-phi**(-a))/3
    derivatives={'loss':str(forfeiture),'first':str(s.diff(forfeiture,a)),
                 'second':str(s.diff(forfeiture,a,2)),
                 'increases':True,'accelerates':False,
                 'interpretation':'for w>0 and a>=0 before the engineering cap'}
    assert s.simplify(s.diff(forfeiture,a)-w*s.log(phi)*phi**(-a)/3)==0
    assert s.simplify(s.diff(forfeiture,a,2)+w*s.log(phi)**2*phi**(-a)/3)==0
    # Deliberately rejected unbounded quadratic switching price.
    quadratic=d0+c*a*a
    identity('quadratic_switch_acceleration',s.diff(quadratic,a,2)-2*c)
    limit=s.limit(quadratic,a,s.oo)
    assert limit==s.oo
    # Optional bounded S curve: symbolic, not installed in S1.
    curve=a*a/(H*H+a*a)
    identity('bounded_S_curve_second_derivative',s.diff(curve,a,2)-2*H*H*(H*H-3*a*a)/(H*H+a*a)**3)
    # All 256 single-output Boolean functions of the three user choices.
    bits=s.symbols('outside west listen')
    states=list(itertools.product((0,1),repeat=3));canonical=set();evaluations=0
    all_tables={}
    for mask in range(256):
        minterms=[list(b) for j,b in enumerate(states) if mask>>j&1]
        expr=simplify_logic(SOPform(bits,minterms),form='dnf')
        outputs=[]
        for j,b in enumerate(states):
            answer=int(bool(expr.subs(dict(zip(bits,b)))))
            assert answer==(mask>>j)&1
            outputs.append(answer);evaluations+=1
        key=tuple(outputs);assert key not in canonical;canonical.add(key)
        all_tables[str(mask)]=str(expr)
    # Every old state, next state and age checks three independent clock updates.
    transitions=0
    for age in range(145):
        for old in states:
            orig=f.Choice(old,(0,0,0))
            for new in states:
                changed=orig.change(new,age)
                assert changed.since==tuple(age if x!=y else 0 for x,y in zip(old,new))
                expected=sum((f.ONE-f.invpow(age) for x,y in zip(old,new) if x!=y),f.ZERO)
                assert orig.density(age)-changed.density(age)==expected
                transitions+=1
    # All 48 signed relabelings of the Boolean cube for every board and state.
    # Scalar board composition is INPUT relabeling, not a conjugacy on scalar outputs.
    relabelings=0
    for perm in itertools.permutations(range(3)):
        for flip in states:
            forward={b:tuple(b[perm[i]]^flip[i] for i in range(3)) for b in states}
            inverse={out:inn for inn,out in forward.items()}
            assert len(inverse)==8
            for mask in range(256):
                for b in states:
                    restored=inverse[forward[b]]
                    assert ((mask>>states.index(restored))&1)==((mask>>states.index(b))&1)
                    relabelings+=1
    ages=[]
    for n in [0,1,2,3,5,10,21,144]:
        m=f.Phi(2)-f.invpow(n)
        ages.append({'age':n,'equal_age_multiplier_exact':m.pair(),
                     'display':m.display(18),
                     'one_bit_weight_loss_per_unit_principal':str(s.N((1-phi**(-n))/3,12))})
    # Ordered pairs of 5-of-7 quorums. A conflict is possible if all their
    # intersection signers are faulty and honest members sign at most once.
    quorums=list(itertools.combinations(range(7),5));q_results=[]
    for faulty in range(4):
        bad=set(range(faulty));possible=[]
        for A in quorums:
            for B in quorums:
                if set(A)&set(B)<=bad:possible.append([list(A),list(B)])
        if faulty<=2:assert not possible
        else:assert possible
        q_results.append({'faulty':faulty,'ordered_quorum_pairs':441,'possible_conflicting_pairs':len(possible),
                          'example':possible[:1]})
    return {'status':'PASS','python':platform.python_version(),'sympy':s.__version__,
            'seconds':round(time.perf_counter()-started,3),'identities':records,
            'forfeiture_derivatives':derivatives,
            'rejected_accelerating_price':{'expression':str(quadratic),'limit':str(limit),
                'finding':'Positive quadratic growth eventually exceeds a finite payment budget.'},
            'optional_not_implemented_S_curve':str(curve),
            'boolean_functions':256,'boolean_evaluations':evaluations,
            'choice_transition_cases':transitions,'Boolean_relabeling_checks':relabelings,
            'canonical_boolean_functions':len(canonical),'age_curve':ages,
            'quorum_pair_analysis':q_results,'finite_domain':'three-input single-output Boolean functions only',
            'truth_table_forms':all_tables}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='symbolic_results.json');args=ap.parse_args()
    result=run();Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('truth_table_forms','age_curve','identities')},indent=2))
