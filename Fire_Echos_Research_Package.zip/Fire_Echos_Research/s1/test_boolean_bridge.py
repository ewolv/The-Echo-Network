#!/usr/bin/env python3
"""Frozen Boolean programs, later branch selection, and eight funded requests.
The frozen program and previous receipts are never edited. This is delayed
input selection / persistent computation, not physical retrocausality.
"""
import argparse,itertools,json
from pathlib import Path
import fire_echos_s1 as f
from test_s1 import fixture,prepare,complete,halt,stamp


def board(mask):
    rows=[]
    for prefix_len in range(3):
        for prefix in itertools.product('01',repeat=prefix_len):
            prefix=''.join(prefix);state='q'+prefix
            for bit in '01':
                path=prefix+bit
                if len(path)==3:
                    index=int(path,2);rows.append([state,bit,'halt',str((mask>>index)&1),'S'])
                else:rows.append([state,bit,'q'+path,bit,'R'])
    return {'start':'q','halt':['halt'],'blank':'_','table':rows}


def main(out):
    executions=0
    for mask in range(256):
        spec=board(mask);sealed=f.digest(f.canonical_program(spec))
        for state in itertools.product('01',repeat=3):
            initial=f.initial_state(spec,state)
            run=f.run_quantum(spec,initial,8,'boolean-audit')
            last=dict(run['final']['cells'])[2]
            assert int(last)==((mask>>int(''.join(state),2))&1)
            assert run['status']=='HALTED' and run['steps']==3
            assert f.digest(f.canonical_program(spec))==sealed
            executions+=1
    p,payer,old,young,listener,snap,mesh=fixture();spec=board(0b10010110)
    program=f.digest(f.canonical_program(spec));jobs=[];answers=[]
    for state in itertools.product('01',repeat=3):
        initial=f.initial_state(spec,state);job=prepare(p,payer,snap,mesh,spec,initial)
        outputs,receipt=complete(p,job,mesh);payer=outputs[0]
        jobs.append(job);answers.append(int(dict(receipt['final']['cells'])[2]))
        assert receipt['program']==program
        assert outputs[3].fire+outputs[4].fire==f.DELIVERY_PRICE
    assert len(set(jobs))==8 and all(p.get(j)['program']==program for j in jobs)
    # Historical data verifies by its content hash. A changed board has a new
    # identity, not retroactive authority to replace an earlier board.
    changed=f.digest(f.canonical_program(board(0b10010111)))
    assert changed!=program
    audit=p.audit();p.close()
    result={'status':'PASS','boolean_programs':256,'input_evaluations':executions,
            'machine_steps_per_evaluation':3,'paid_branch_requests':8,'outputs':answers,
            'frozen_program_id':program,'all_paid_requests_same_program':True,
            'changed_board_changes_identity':True,'audit':audit,
            'scope':'Complete three-input/single-output Boolean layer; eight branches integrated with funded S1 tickets.'}
    Path(out).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='boolean_bridge_results.json');main(p.parse_args().out)
