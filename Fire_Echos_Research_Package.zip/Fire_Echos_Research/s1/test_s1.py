#!/usr/bin/env python3
"""Integration and adversarial tests of the S1 research fork.
No production keys, remote witnesses or actual network traffic are involved.
"""
from __future__ import annotations
import argparse, copy, itertools, json, os, random, subprocess, sys, tempfile, time
from collections import Counter
from dataclasses import replace
from pathlib import Path
import fire_echos_s1 as f


def halt(fn):
    try: fn()
    except f.Halt: return
    raise AssertionError('expected rejection')


def stamp(p):
    return (tuple(sorted(x.id for x in p.notes())),p.total().pair(),
        tuple(p.db.execute('SELECT id,status,receipt,outputs FROM jobs ORDER BY id')),
        tuple(p.db.execute('SELECT key,capsule,certificate FROM memos ORDER BY key')))


def fixture(path=None):
    p=f.Protocol(path);g=p.bootstrap()
    left,old=p.fracture(g.id,p.users[0]);young,rest=p.fracture(left.id,p.users[0]);payer,listener=p.fracture(rest.id,p.users[0])
    old,_=p.transfer(old.id,p.users[0],p.users[1],(1,0,0))
    listener,_=p.transfer(listener.id,p.users[0],p.users[3],(1,1,1))
    for _ in range(21):p.advance()
    young,_=p.transfer(young.id,p.users[0],p.users[2],(1,0,0))
    assert old.fire==young.fire
    snap=p.snapshot([old,young,listener]);mesh=f.PaperMesh(p.notes())
    return p,payer,old,young,listener,snap,mesh


def prepare(p,payer,snap,mesh,spec=None,initial=None,**kwargs):
    spec=f.UNARY if spec is None else spec
    initial=f.initial_state(spec,'111') if initial is None else initial
    return p.prepare(payer.id,p.keys[payer.owner],snap,spec,initial,8,overlay=mesh,**kwargs)


def complete(p,job,mesh,**kwargs):
    b=p.get(job);inputs=[p.live(b[k],job) for k in ('payer','speaker','listener')]
    r=p.work(job);out=p.settle(job,r,**kwargs);mesh.publish(p,inputs,out)
    return out,r


def targeted_income(jobs=1024):
    p,payer,old,young,listener,snap,mesh=fixture();labels={old.owner:'old',young.owner:'young'}
    count=Counter();steps=Counter();income={'old':f.ZERO,'young':f.ZERO};modes=Counter()
    initial_funding=payer.fire
    for i in range(jobs):
        who=labels[snap.select(payer,0,int(p.meta('slot'))).owner]
        # Adversarial cost targeting is still possible, but it cannot alter the
        # agreed gross fee of one accepted ticket in this fixed service class.
        if who=='young':
            spec=f.LOOP;initial={'state':'q','head':i*32,'cells':[]}
        else:
            spec=f.UNARY;initial=f.initial_state(spec,'')
        job=prepare(p,payer,snap,mesh,spec,initial);out,r=complete(p,job,mesh);payer=out[0]
        assert out[3].fire+out[4].fire==f.DELIVERY_PRICE
        count[who]+=1;steps[who]+=r['new_steps'];income[who]+=out[3].fire;modes[r['mode']]+=1
        assert out[3].choice.ages(p.epoch)==(0,0,0) and out[4].choice.ages(p.epoch)==(0,0,0)
    assert initial_funding-payer.fire==f.DELIVERY_PRICE*jobs
    assert income['old']==f.DELIVERY_PRICE*f.INV*count['old']
    assert income['young']==f.DELIVERY_PRICE*f.INV*count['young']
    audit=p.audit();p.close()
    return {'paid_tickets':jobs,'allocations':dict(count),'gross_speaker_fee_units':dict(count),
            'speaker_income_exact':{k:v.pair() for k,v in income.items()},
            'old_gross_fee_share':count['old']/jobs,'actual_new_steps':dict(steps),'modes':dict(modes),
            'audit':audit,'scope':'fixed tariff, continuous shared eligibility, no skipping; gross income, not profit'}


def long_job_and_reuse():
    p,payer,old,young,listener,snap,mesh=fixture();state=f.initial_state(f.LOOP,[])
    labels={old.owner:'old',young.owner:'young'};counts=Counter();start=payer.fire;history=[];steps=0
    for _ in range(32):
        job=prepare(p,payer,snap,mesh,f.LOOP,state);out,r=complete(p,job,mesh);payer=out[0]
        state=r['final'];steps+=r['new_steps'];history.append(job);counts[labels[out[1].owner]]+=1
    assert steps==256 and state['head']==256 and len(set(history))==32
    assert start-payer.fire==32*f.DELIVERY_PRICE
    # Reuse saves interpreter steps; the S1 flat reservation price does NOT fall.
    repeated=f.initial_state(f.UNARY,'111');modes=Counter();new=0;fees=[]
    for _ in range(128):
        job=prepare(p,payer,snap,mesh,f.UNARY,repeated);out,r=complete(p,job,mesh);payer=out[0]
        modes[r['mode']]+=1;new+=r['new_steps'];fees.append(out[3].fire+out[4].fire)
    assert modes=={'EXECUTE':1,'DELIVER':127} and new==4
    assert all(x==f.DELIVERY_PRICE for x in fees)
    audit=p.audit();p.close()
    return {'long_job_steps':steps,'required_paid_tickets':32,'workers_paid':dict(counts),
            'repeated_requests':128,'repeat_modes':dict(modes),'repeat_worker_plus_listener_steps':2*new,
            'no_reuse_worker_plus_listener_steps':1024,'repeat_fee_units':128,
            'explicit_tradeoff':'S1 reuse reduces interpreter work, not the agreed flat ticket price','audit':audit}


def grouping_and_fracture():
    p,payer,old,young,listener,snap,mesh=fixture();original=f.MassTree([old,young],21)
    pieces=[old]
    for _ in range(6):
        nxt=[]
        for n in pieces:
            mid=n.lo+n.fire*f.INV
            nxt.extend([replace(n,hi=mid),replace(n,lo=mid)])
        pieces=nxt
    split=f.MassTree(pieces+[young],21);differences=0
    for i in range(8192):
        if original.select(*f.slot_fraction(i)).owner!=split.select(*f.slot_fraction(i)).owner:differences+=1
    assert differences==0
    rng=random.Random(260907);base=[original.select(*f.slot_fraction(i)).owner for i in range(4096)]
    for _ in range(100):
        cursor=0;reconstructed=[]
        while cursor<4096:
            length=min(rng.randint(1,64),4096-cursor)
            reconstructed.extend(original.select(*f.slot_fraction(i)).owner for i in range(cursor,cursor+length))
            cursor+=length
        assert reconstructed==base
    # Equal mass, all age together: only relative weights matter.
    fresh=[replace(n,choice=f.Choice.fresh(n.choice.bits,21)) for n in (old,young)]
    both_old=[replace(n,choice=f.Choice(n.choice.bits,(0,0,0))) for n in fresh]
    t0,t1=f.MassTree(fresh,21),f.MassTree(both_old,21)
    same_age=sum(t0.select(*f.slot_fraction(i)).owner!=t1.select(*f.slot_fraction(i)).owner for i in range(4096))
    assert same_age==0;p.close()
    return {'split_descendants':64,'coordinates':8192,'owner_selection_differences':differences,
            'regroupings':100,'tickets_per_regrouping':4096,'all_age_together_differences':same_age,
            'naive_one_note_one_vote_share':64/65,'mass_weighted_equal_seniority_share':0.5}


def ticket_safety_and_restart():
    with tempfile.TemporaryDirectory() as temp:
        p,payer,old,young,listener,snap,mesh=fixture(temp);checks=[]
        before=stamp(p)
        halt(lambda:p.prepare(payer.id,p.keys[payer.owner],snap,f.UNARY,f.initial_state(f.UNARY,'111'),7,overlay=mesh))
        assert stamp(p)==before;checks.append('wrong class / quantum')
        halt(lambda:prepare(p,payer,snap,mesh,reachable=[0,1,2,3]));assert stamp(p)==before
        checks.append('subquorum before reservation')
        job=prepare(p,payer,snap,mesh);r=p.work(job);b=p.get(job)
        ins=[p.live(b[k],job) for k in ('payer','speaker','listener')]
        before=stamp(p)
        halt(lambda:prepare(p,payer,snap,mesh));assert stamp(p)==before;checks.append('reserved input double use')
        bad=dict(r,trace='tampered');halt(lambda:p.settle(job,bad));assert stamp(p)==before;checks.append('tampered execution receipt')
        halt(lambda:p.settle(job,r,bad_signature=True));assert stamp(p)==before;checks.append('forged final postcard')
        for phase in ('after_consume','after_first_output','before_commit'):
            try:p.settle(job,r,fail_at=phase)
            except OSError:pass
            else:raise AssertionError('fault was not injected')
            assert stamp(p)==before;checks.append('rollback '+phase)
        p.close();p=f.Protocol(temp);assert stamp(p)==before;checks.append('database reopen retains reservation')
        out=p.settle(job,r);after=stamp(p);again=p.settle(job,r)
        assert [n.id for n in out]==[n.id for n in again] and stamp(p)==after;checks.append('idempotent completion')
        halt(lambda:p.settle(job,bad));assert stamp(p)==after;checks.append('conflicting replay rejected')
        assert p.audit()['supply']==[1,0];p.close()
    return {'checks':checks,'check_count':len(checks)}


def echo_cases():
    p=f.Protocol();note=p.bootstrap();sender=p.users[0];recipient=p.users[1];cap=f.DELIVERY_PRICE*4
    offer=f.echo_offer(p,note.id,sender,recipient,cap)
    offer=f.echo_append(offer,p.users[2],f.DELIVERY_PRICE)
    offer=f.echo_append(offer,p.users[3],f.DELIVERY_PRICE)
    checks=[];before=stamp(p);signature=recipient.sign(f.echo_acceptance(offer))
    # Different failure classes, each checked before account mutation.
    bad=copy.deepcopy(offer);bad['body']['recipient']=p.users[4].id
    halt(lambda:f.echo_check(p,bad));checks.append('changed recipient')
    bad=copy.deepcopy(offer);bad['hops'][0]['body']['fee']=(f.DELIVERY_PRICE*2).pair()
    halt(lambda:f.echo_check(p,bad));checks.append('unsigned fee change')
    bad=f.echo_append(offer,p.users[2],f.DELIVERY_PRICE)
    halt(lambda:f.echo_check(p,bad));checks.append('courier loop')
    bad=f.echo_append(offer,p.users[4],f.DELIVERY_PRICE*3)
    halt(lambda:f.echo_check(p,bad));checks.append('fee cap exceeded')
    bad=f.echo_offer(p,note.id,sender,recipient,cap,1)
    bad=f.echo_append(f.echo_append(bad,p.users[2],f.DELIVERY_PRICE),p.users[3],f.DELIVERY_PRICE)
    halt(lambda:f.echo_check(p,bad));checks.append('hop bound exceeded')
    bad=copy.deepcopy(offer);bad['hops'].reverse()
    halt(lambda:f.echo_check(p,bad));checks.append('reordered signed chain')
    bad=copy.deepcopy(offer);bad['hops'][0]['signature']='00'*64
    halt(lambda:f.echo_check(p,bad));checks.append('bad courier signature')
    halt(lambda:f.echo_commit(p,offer,'00'*64));checks.append('missing recipient acceptance')
    halt(lambda:f.echo_commit(p,offer,signature,reachable=[0,1,2,3]));checks.append('subquorum acceptance')
    alternate=f.echo_offer(p,note.id,sender,recipient,cap)
    alternate=f.echo_append(alternate,p.users[4],f.DELIVERY_PRICE)
    halt(lambda:f.echo_commit(p,alternate,signature));checks.append('recipient signed another chain')
    assert stamp(p)==before
    for phase in ('after_consume','after_first_output','before_commit'):
        try:f.echo_commit(p,offer,signature,fail_at=phase)
        except OSError:pass
        else:raise AssertionError('expected rollback')
        assert stamp(p)==before;checks.append('echo rollback '+phase)
    out=f.echo_commit(p,offer,signature);after=stamp(p)
    assert len(out)==3 and out[0].fire+out[1].fire+out[2].fire==note.fire
    assert all(n.choice.ages(p.epoch)==(0,0,0) for n in out[1:])
    halt(lambda:f.echo_commit(p,offer,signature));assert stamp(p)==after;checks.append('payment replay')
    # Copying a competing valid offer does not give it independent money.
    halt(lambda:f.echo_commit(p,alternate,recipient.sign(f.echo_acceptance(alternate))))
    assert stamp(p)==after;checks.append('second valid competing fee chain')
    audit=p.audit();p.close()
    return {'checks':checks,'check_count':len(checks),'accepted_chains':1,'couriers_paid':2,
            'recipient_value_exact':out[0].fire.pair(),'fee_sum_exact':(out[1].fire+out[2].fire).pair(),
            'audit':audit,'limitation':'signatures do not prove independent forwarding work or defeat Sybil relays'}


def echo_stress(jobs=600,seed=20260927):
    rng=random.Random(seed);p=f.Protocol(users=40);note=p.bootstrap();metrics=Counter();fee_total=f.ZERO
    for i in range(jobs):
        sender=p.keys[note.owner];recipient=rng.choice([x for x in p.users if x.id!=sender.id])
        hops=rng.sample([x for x in p.users if x.id not in (sender.id,recipient.id)],rng.randrange(0,9))
        offer=f.echo_offer(p,note.id,sender,recipient,f.DELIVERY_PRICE*8)
        for courier in hops:offer=f.echo_append(offer,courier,f.DELIVERY_PRICE)
        signature=recipient.sign(f.echo_acceptance(offer));before=stamp(p)
        if i%31==0:
            halt(lambda:f.echo_commit(p,offer,'00'*64));assert stamp(p)==before;metrics['bad_acceptance_rejected']+=1
        if i%37==0:
            halt(lambda:f.echo_commit(p,offer,signature,reachable=[0,1,2,3]));assert stamp(p)==before;metrics['subquorum_rejected']+=1
        out=f.echo_commit(p,offer,signature);note=out[0];metrics['courier_outputs']+=len(hops)
        fee_total+=sum((n.fire for n in out[1:]),f.ZERO)
        if i%43==0:
            after=stamp(p);halt(lambda:f.echo_commit(p,offer,signature));assert stamp(p)==after;metrics['replay_rejected']+=1
    assert note.fire+fee_total==f.ONE;audit=p.audit();p.close()
    return {'seed':seed,'payments':jobs,'metrics':dict(metrics),'courier_fee_total_exact':fee_total.pair(),'audit':audit}


def mixed_stress(jobs=800,seed=20260928):
    rng=random.Random(seed);p,payer,old,young,listener,snap,mesh=fixture();counts=Counter();new_steps=0
    for i in range(jobs):
        spec=f.UNARY if rng.randrange(2) else f.LOOP
        initial=f.initial_state(spec,'1'*rng.randrange(0,8)) if spec is f.UNARY else {'state':'q','head':rng.randrange(64),'cells':[]}
        before=stamp(p)
        if i%41==0:
            halt(lambda:prepare(p,payer,snap,mesh,spec,initial,reachable=[0,1,2,3]));assert stamp(p)==before;counts['subquorum_rejected']+=1
        job=prepare(p,payer,snap,mesh,spec,initial);r=p.work(job);before=stamp(p)
        if i%29==0:
            halt(lambda:p.settle(job,dict(r,trace='tampered')));assert stamp(p)==before;counts['receipt_rejected']+=1
        if i%97==0:
            try:p.settle(job,r,fail_at='before_commit')
            except OSError:pass
            else:raise AssertionError('expected injected failure')
            assert stamp(p)==before;counts['rollback_retried']+=1
        out,r=complete(p,job,mesh);payer=out[0];counts[r['mode']]+=1;new_steps+=r['new_steps']
        assert out[3].fire+out[4].fire==f.DELIVERY_PRICE
    audit=p.audit();p.close()
    return {'seed':seed,'tickets':jobs,'counts':dict(counts),'new_worker_steps':new_steps,'audit':audit}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='s1_results.json');ap.add_argument('--stress-only',action='store_true')
    ap.add_argument('--jobs',type=int,default=800);ap.add_argument('--seed',type=int,default=20260928);args=ap.parse_args()
    result={'status':'RUNNING','protocol_id':f.PROTOCOL,'tests':{},'python':sys.version.split()[0]};start=time.perf_counter()
    sequence=[] if args.stress_only else [
        ('targeted_fixed_price_income',targeted_income),('long_job_and_result_reuse',long_job_and_reuse),
        ('fracture_and_request_grouping',grouping_and_fracture),('ticket_failures_and_restart',ticket_safety_and_restart),
        ('signed_echo_attack_cases',echo_cases),('signed_echo_payments',echo_stress)]
    sequence.append(('mixed_tickets',lambda:mixed_stress(args.jobs,args.seed)))
    for name,fn in sequence:
        tick=time.perf_counter();print('RUN',name,flush=True)
        try:result['tests'][name]=fn()
        except Exception as exc:
            result['status']='FAIL';result['failed_test']=name;result['error']=repr(exc)
            Path(args.out).write_text(json.dumps(result,indent=2)+'\n');raise
        print('PASS',name,round(time.perf_counter()-tick,3),flush=True)
        Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
    result['status']='PASS';result['seconds']=round(time.perf_counter()-start,3)
    Path(args.out).write_text(json.dumps(result,indent=2)+'\n');print('PASS',result['seconds'],flush=True)
if __name__=='__main__':main()
