# Fire Echos — Research Edition S1

Concept: Eric James Wolverton. Research, implementation iteration and white paper prepared with ChatGPT, 6 September 2026.

**Research software only. All signing keys in these fixtures are publicly derivable test identities. Do not use this code, its keys or its databases for live funds.** This package is a local exact-accounting and computation model, not a deployed peer-to-peer currency, independent Byzantine consensus implementation or investment product.

## Read first

`WHITE_PAPER.md` is the editable text of the 23-page crimson-and-old-paper white paper. `RESULTS_SUMMARY.md` summarizes the fresh experiments. `results/` contains the six evidence datasets cited as E1–E6 in the paper and their available logs. Numeric JSON pairs encode exact `a + b*phi`, where `phi^2 = phi + 1`; a negative coefficient is not necessarily a negative value.

The original v5 and reward-audit folders are preserved as prior project material. Their pre-existing logs/reports/results are **historical**, not new evidence. Only the top-level `results/` files are the fresh recorded executions for this edition.

## Environment and reproduction

Measured environment: Python 3.13.5, SymPy 1.14.0, cryptography 46.0.4 and SQLite 3.46.1. The dependency pins reproduce the study; they are not a recommendation of production security support. Use an isolated environment, and do not disable Python assertions with `-O` or `-OO`.

```sh
python -m venv .venv
# Activate the virtual environment using your operating system's usual command.
python -m pip install -r requirements.txt
python reproduce.py
```

The full runner verifies the supplied SHA-256 manifest, executes all six evidence commands, and creates a new timestamped directory under `rerun_results/`. It does not overwrite the supplied results. A full run normally takes several minutes; hardware, package versions and concurrency affect runtime. Seeds select deterministic model workloads, not secure randomness. Timings, temporary paths and some environment fields need not be byte-for-byte identical on another machine.

For package smoke checks only:

```sh
python reproduce.py --quick
python s1/fire_echos_s1.py demo --jobs 12
```

The quick run checks symbolic mathematics, the finite Boolean-machine bridge and 24 mixed S1 tickets. It does **not** reproduce the headline workload totals. The demo is local; it has no network send command, private key custody or connection to real assets.

## Individual evidence commands

Run from this package's root. The scripts resolve their own Python imports; direct commands require the destination directory to exist.

```sh
mkdir rerun_manual
python baseline/fire_echo_v5/test_fire_echo_v5.py --jobs 1800 --seed 20260926 --out rerun_manual/v5_fresh_rerun.json
python prior_audit/Fire_Echo_Reward_Audit/reward_audit.py --jobs 384 --seed 20260926 --out rerun_manual/v5_reward_rerun.json
python s1/symbolic_analysis.py --out rerun_manual/symbolic_results.json
python s1/test_s1.py --jobs 800 --seed 20260928 --out rerun_manual/s1_results.json
python s1/test_s1.py --stress-only --jobs 600 --seed 20260929 --out rerun_manual/s1_seed2.json
python s1/test_boolean_bridge.py --out rerun_manual/boolean_bridge_results.json
```

The existing v5 reward audit deliberately ends with `COMPLETE; INCOME-GUARANTEE COUNTEREXAMPLE REPRODUCED`. This is not an assertion failure or a universal reward guarantee. The old request-count rule can give old paper more jobs but less fee income when prices differ. S1's implemented fixed-price tickets address that specific failure under a stable eligible snapshot, fixed tariff, consecutive tickets and continuous availability.

## Files and interpretation

- `s1/fire_echos_s1.py`: new fixed-price eight-step ticket model and recipient-approved, capped courier chains.
- `s1/changes_from_v5.patch`: actual unified change from the unchanged original implementation.
- `s1/symbolic_analysis.py`: exact SymPy identities, all 256 three-input single-output Boolean functions, independent clock transitions and quorum-pair enumeration.
- `s1/test_s1.py`: end-to-end paid ticket tests, continuations, reuse, split invariance, failure/restart, courier signatures, replay and mixed workloads.
- `s1/test_boolean_bridge.py`: all 2,048 Boolean-board executions compiled to a deterministic machine, plus eight paid branches of one frozen program.
- `baseline/fire_echo_v5/`: unchanged baseline code, dependencies, report and historical evidence.
- `prior_audit/Fire_Echo_Reward_Audit/`: unchanged earlier audit with its expected baseline import tree.
- `results/`: fresh white-paper evidence, separate from all historical files.
- `SHA256SUMS.json`: integrity hashes of supplied package files. This detects changes relative to the supplied manifest; it is not an authenticated author signature.

## Monetary and safety boundaries

The test genesis has one nominal Fire. A free carrier or a zero balance cannot become positive principal by subdivision alone. A real deployment needs common asset identity, an admitted issuance rule and distribution. Each independent experiment starts from its own test genesis; do not add those independent supplies together.

Age increases a bounded principal-weighted opportunity to earn requester-funded service fees; it never mints Fire, proves uptime or establishes market purchasing power. Same-owner continuity preserves policy ages. Ownership changes reset them. New fee notes begin young. Stored checked results can save repeated machine execution; aging alone cannot make a cold computation faster.

The final rule makes changing an older bit more costly in lost service priority, but the cost is bounded and concave, not endlessly accelerating. The quadratic accelerating monetary levy and bounded alternative were symbolically analyzed, not installed.

Five of seven fixed local signing stores form the modeled certificate boundary under at most two faulty sign-once witnesses. The trusted local reducer is not seven independent remote validators. Invalid evidence or insufficient quorum stops the transition; pending valid reservations can remain locked. Secure time, independent consensus, cancellation/recovery, real discovery/transport/retention, custody and realistic pricing remain deployment work. Courier signatures authorize a selected fee chain; they do not prove independent people, necessary relays or a globally cheapest route.

Editing the protocol source changes its implementation hash and protocol identity. Use a fresh database for changed rules. The included public test keys must never be repurposed as secrets.
