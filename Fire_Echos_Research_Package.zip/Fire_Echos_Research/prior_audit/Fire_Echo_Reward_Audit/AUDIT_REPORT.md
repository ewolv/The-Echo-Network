# Fire Echo — Independent Reward and Canon Audit

**Date:** 6 September 2026  
**Concept:** Eric James Wolverton  
**Audited implementation:** the existing, unchanged `fire_echo_v5.py`  
**Verdict:** **80/100, B− as a research prototype. Not production-ready.**

The score is an engineering assessment, not a probability of safety or a financial return estimate. The principal finding is that age produces a funded service advantage under matched conditions, but the current request-count scheduler does not ensure an age-proportional share of fees when request prices differ.

## What was actually executed

The original v5 regression suite was rerun, with its mixed workload using the fresh seed `20260916` and 1,200 paid jobs. The original non-stress tests retain their own fixed seeds. The complete suite passed in this environment. The new `reward_audit.py` adds two 384-request paid experiments, explicit canon-conjugacy tests, availability and switching-cost checks, relative-value negative controls, and a separate candidate allocation experiment.

The baseline Python source was not changed. The candidate service-ticket correction is **an allocation-only model**, not an integrated v6 wallet, distributed implementation, or demonstrated production repair.

Environment: Python 3.13.5, cryptography 46.0.4. Those are measured reproduction versions, not a recommendation to use these public test keys or this prototype for real funds.

Protocol identity:

```text
2a8c0bb9fbfbe11305f6b42e43a803a3fabfe8c90d458d638134f2e7426cb836
```

## 1. “I go so fast, you go backwards”: an explicit canon conjugate

One exact interpretation is a change of moving reference frame. Let canonical evolution be

```text
F_s(t,h) = (t+1, h+s)
x_v(t,r) = (t, r+v*t)
```

Then the transported evolution is

```text
x_v^-1(F_s(x_v(t,r))) = (t+1, r+s-v).
```

For `s=1` and `v=3`, canonical movement is +1 while relative movement is −2. The descriptions agree after transport back to the same canonical state. All 10,000 randomized integer-coordinate tests passed. This is an interpretation used for the model, not a claim that the phrase specifies a unique mathematical transformation or that committed history changes.

The Fire-specific counterpart uses age and the remaining gap to full seniority:

```text
effective_age_i = min(certified_epoch - changed_epoch_i, 144)
gap_i = phi^(-effective_age_i)
M = Fire * (2 - (gap_1 + gap_2 + gap_3)/3)
```

Before the cap, advancing unchanged age multiplies the gap by phi^-1. Increasing age and decreasing gap describe the same development in opposite coordinate directions. On the 145-element effective-age domain, the map from age to gap is one-to-one; every capped aging transition passed the exact conjugacy test. Raw timestamps are retained separately: the capped score alone cannot reconstruct full history.

Changing a policy resets its gap to 1. On unchanged principal, it forfeits `Fire*(1-gap_i)/3` of selection mass, before accounting for the separately charged change fee. All 432 single-channel reset checks passed. Other channels remain intact. Executing a Turing-machine step is not itself a policy change.

## 2. Does aging add funded value?

Yes, for comparable eligible services under the implemented tariff. The positive experiment compared equal-principal speaker papers at epoch 21, with ages `(21,21,21)` and `(0,0,0)`. One warm-up computation was completed and excluded from the income comparison; all 384 measured requests were identically priced certified-result deliveries.

| Measurement | Older paper | Younger paper |
|---|---:|---:|
| Paid measured deliveries | 255 | 129 |
| Speaker fee units | 255 | 129 |
| Share of measured speaker fees | 66.40625% | 33.59375% |

The older paper earned **1.976744 times** the younger paper's fees in this finite schedule. One speaker fee unit equals phi^-33 Fire. Payments came from requester principal, not newly minted Fire. Total supply remained exactly the pair `[1,0]`, meaning `1 + 0*phi`. Service-continuity papers preserved their ages and every new fee paper started at age zero.

This demonstrates an operational entitlement to a greater share of comparably priced work. It does not demonstrate an asset-price increase, guaranteed profit, independently measured willingness to pay, or more aggregate wealth merely because all papers age.

The relative-value controls found zero owner-selection changes across 4,096 coordinates when both competitors aged together. An unused paper matured without earning a payment. A cold program still needed 16 transitions at ages 0, 21, and 144.

The rule also matures quickly. For three equally aged channels, the multiplier is approximately 1.382 at age 1, 1.910 at age 5, 1.992 at age 10, and 1.999959 at age 21. More than 99% of the available bonus is reached by age 10. Growth stops at effective age 144, at exactly `2 - phi^-144`, still less than 2. The epoch is a protocol unit, not a demonstrated unit of secure physical time.

## 3. Reproduced limitation: request share is not fee share

The v5 report already acknowledges unequal-cost and strategic-timing limitations. The new experiment quantifies one.

Because the next selected service is predictable, a synthetic requester assigned inexpensive work to slots selecting the older speaker, and fresh 256-transition jobs to slots selecting the younger speaker. Every request was funded and legally settled. This was not a forged receipt or an accounting attack.

| Measurement | Older paper | Younger paper |
|---|---:|---:|
| Paid requests | 255 | 129 |
| Speaker fee units | 256 | 33,153 |
| Share of speaker fees | 0.76626% | 99.23374% |

The older paper's 256 units include its one cold 1-step request, priced as one execution unit plus one delivery unit; later old-paper requests cost one delivery unit each. Each younger-paper request cost 257 units. The younger paper performed much more fresh work and was paid accordingly. Thus this is a counterexample to unconditional age-proportional income, not evidence that larger payment for larger computation is inherently wrong.

The distinction matters: allocating two requests to one worker and one request to another is not the same as allocating twice the paid service. Principal remained exactly conserved.

## 4. Candidate correction: schedule fixed-price service units

The allocation experiment replaces one scheduling opportunity per variable-price request with consecutive, equal-tariff service tickets. A request consumes as many tickets as its billable service requires. An expensive request cannot pass through as a single cheap scheduling turn.

Using the counterexample's **same 33,409 total fee units**, the unchanged exact mass-tree selection rule allocated:

| Candidate allocation | Older paper | Younger paper |
|---|---:|---:|
| Fixed-price service tickets | 22,272 | 11,137 |
| Conditional share of paid ticket fees | 66.66467% | 33.33533% |

The theoretical old share under those masses is 66.66621%. The allocated speaker and listener fees sum exactly to the same fixed budget. A 64-way fracture produced zero owner-selection differences across 4,096 coordinates. Grouping the same consecutive tickets into requests does not change the aggregate schedule under a frozen eligible snapshot.

**Scope:** these are allocation results, not 33,409 newly settled wallet transactions. End-to-end integration still needs explicit continuation between workers, an accounting definition of service units, prices for verification/delivery/coordination, persistent ticket consumption, and safe handling of cancellation and membership changes. There is no claim that crossing worker boundaries is free or that every task can be subdivided efficiently. Selective skipping of known tickets must not become a new manipulation route. The existing fail-closed accounting should remain separate from the incentive policy.

## 5. Where useful computational value appears

The v5 cache test was rerun unchanged. For 128 identical requests representing a 32-transition computation, it recorded one EXECUTE and 127 DELIVER operations. Worker-plus-listener interpreter transitions fell from the no-reuse baseline of 8,192 to 64: **99.21875% fewer interpreter transitions**. Under the demonstration tariff, total fees fell by about 96.2121%.

This is retained, checked computation doing useful work. It is not age making cold computation run faster, nor a measured end-to-end wall-clock speedup. Storage, hashes, signatures, network transport, database operations, and failures are not free. Exact dependency-sensitive memoization is an established foundation for this distinction [R1].

The system therefore has two complementary mechanisms: age weights access to funded service; certified reusable results reduce repeated computation. The existing implementation correctly permits young papers to use public checked results. Artificially making them recompute would create a penalty, not computational value.

## 6. Other findings that affect the grade

### Switching-price calibration

One legal same-owner east/west change transformed ages `(21,21,21)` into `(21,0,21)`, and the multiplier fell from about 1.999959 to 1.666639. The paid fee was approximately 0.0016323093 Fire on approximately 0.3803266661 Fire principal, or **0.429186%**.

At this demonstration tariff, that single change fee equaled approximately **12,864.55 cached-delivery speaker fees**. This is not a market-price forecast, but it identifies a calibration issue: the policy may strongly discourage adaptation. Loss of seniority already penalizes a reset; the explicit fee should have a justified relationship to update and coordination costs.

### Availability and certified age

Removing the currently selected service from the modeled online set caused 32 consecutive preparations to reject without a payout or advancing the slot. Accounts remained intact, but the queue did not make progress. The broader continuation-limit test left an invalid funded job pending because certified cancellation is not implemented.

Passing epochs does not prove continuous storage, connectivity, or service availability. The test harness supplies epochs. Age is policy seniority unless additional service evidence is explicitly required.

### Safety has a stated boundary

The fresh 1,200-job mixed workload completed 327 EXECUTE and 873 DELIVER jobs. It rejected 42 tampered receipts and 30 subquorum preparations. Thirteen injected settlement failures rolled back and then retried successfully. Its final audit had 2,467 live papers, zero pending jobs, and exact supply `[1,0]`.

The separate abrupt-process-exit test recovered without partial committed outputs. This does not cover every power-loss, faulty-disk, operating-system, or distributed failure. SQLite's atomicity is an established implementation mechanism with explicit system assumptions [R2].

With seven witnesses and a threshold of five, two quorums intersect in at least three witnesses. Assuming at most two faulty witnesses and persistent honest sign-once behavior, their intersection contains an honest witness. The exhaustive model admitted zero conflicts for 0–2 faulty witnesses. With three faulty witnesses, 6 of 81 modeled vote assignments admitted conflicts, and the negative control constructed conflicting signed certificates. Those assignments are exhaustive cases in the specified model, not probabilities of an attack.

Full Byzantine state-machine replication requires more than this certificate-counting and trusted local reducer [R3]. Public deterministic test keys, secure-time gaps, missing cancellation/reconfiguration, and local rather than independently replicated state prevent a production-readiness claim. Canonical byte identity helps stable hashing and signing, but is not by itself semantic correctness or consensus [R4].

## 7. Grade

| Research category | Awarded | Maximum | Reason |
|---|---:|---:|---|
| Exact accounting and canonical state | 23 | 25 | Exact principal and partition invariants; trusted local validation remains a boundary. |
| Age entitlement and independent resets | 18 | 20 | Funded matched-work premium, bounded mass, fresh reward clocks; time semantics need deployment design. |
| Checked execution and useful reuse | 18 | 20 | Executable, resumable model and measured reuse; not a remote succinct computation proof. |
| Strategic reward robustness | 7 | 15 | Predictable variable-price request allocation can reverse the income premium. |
| Recovery and operational completeness | 4 | 10 | Tested rollback, but pending-work locks, secure epochs, independent consensus and discovery remain incomplete. |
| Reproducibility and test visibility | 10 | 10 | Unchanged source, new executable audit, raw results, negative controls and reproduction instructions. |
| **Total** | **80** | **100** | **B− research prototype; not production-ready.** |

**Design conclusion:** preserve policies without resetting them for useful computation; let their age weight funded service units; preserve certified results as reusable knowledge; consume payment authority once; keep Fire conserved. The current age mechanism works, but the stronger claim that older choices robustly receive more fee value needs the allocation correction and its end-to-end validation.

## Reproduction and evidence

New results are in `v5_rerun.json` and `reward_results.json`. The latter deliberately ends with `COMPLETE; INCOME-GUARANTEE COUNTEREXAMPLE REPRODUCED`, rather than calling the entire reward hypothesis a pass. Function names are the keys in each file's `tests` map. `README.md` contains exact commands.

Baseline implementation references: `Choice.density`, `MassTree.select`, `Snapshot.select`, `Protocol.prepare`, `Protocol.settle`, `Protocol.advance`, and `Quorum`. The pre-existing report is `Fire_Echo_v5_Design_and_Test_Report.md` in the original project library; its unequal-cost caveat was not treated as a newly discovered design intention.

### Primary foundations

[R1] Acar, Blelloch, Harper. *Selective Memoization*. POPL 2003; author manuscript also available as arXiv:1106.0447. Supports precise dependency-aware reuse, not endorsement of Fire Echo.

[R2] SQLite. *Atomic Commit in SQLite* and its stated hardware/operating-system assumptions. The main v5 ledger uses WAL; witness stores use SQLite as well. Different journaling mechanisms must not be conflated with a proof against every storage fault.

[R3] Castro and Liskov. *Practical Byzantine Fault Tolerance*. OSDI 1999. Supports fault-bound and independent-replication distinctions, not security certification of this local prototype.

[R4] RFC 8785. *JSON Canonicalization Scheme*. 2020. Supports the role of invariant representation in hashing/signing. The prototype uses its own restricted Python JSON encoding; this audit does not certify RFC 8785 interoperability.
