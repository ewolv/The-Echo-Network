# Fire Echo Reward Audit — 6 September 2026

Start with `AUDIT_REPORT.md`. This is a reproducible research review, not production wallet software. Every baseline identity is derived from a public test seed. Never put real funds or secret wallet keys into these programs.

## What is included

`baseline/fire_echo_v5/` contains unchanged v5 source and its required regression modules. `reward_audit.py` is the new reward/canon audit. `v5_rerun.json` and `reward_results.json` record executions from this review. The new reward audit deliberately records a counterexample to unconditional age-proportional fee income.

The fixed-price service-ticket correction in `ticket_repair()` is allocation-only. It does not modify the baseline wallet or implement complete distributed paid execution.

## Reproduce

Measured environment: Python 3.13.5 and cryptography 46.0.4. Create an isolated Python environment, then from this directory run:

```sh
python -m pip install -r baseline/fire_echo_v5/requirements.txt
python baseline/fire_echo_v5/test_fire_echo_v5.py --jobs 1200 --seed 20260916 --out rerun_local.json
python reward_audit.py --jobs 384 --seed 20260916 --out rewards_local.json
```

The non-stress portions of the inherited suite retain their original fixed seeds; the seed argument changes the mixed stress workload. Schedules in the paired income experiments are deterministic. Durations can vary. Do not use `python -O`, which would disable test assertions.

Expected results: the inherited suite passes; the new audit completes with the income-guarantee counterexample reproduced. Uniform paid requests produce an old-to-young speaker-income ratio around 1.98. The deliberately price-targeted request sequence gives the old paper about 0.766% of speaker fees despite most request assignments. The fixed-price allocation-only candidate returns its share to about 66.665% under the stated assumptions.

No original library artifact was overwritten and no new artifact was uploaded to the persistent library. Source-file hashes are in `SHA256SUMS.json`. The protocol itself pins the v5 source hash, so editing that file changes the protocol identity.
