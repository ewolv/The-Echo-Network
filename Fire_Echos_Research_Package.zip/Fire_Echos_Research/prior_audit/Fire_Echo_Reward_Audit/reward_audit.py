#!/usr/bin/env python3
"""Independent Fire Echo v5 reward audit. Research tests, not a money wallet.

Run beside the supplied baseline directory:
    python reward_audit.py --out reward_results.json
All wallet operations below use the unchanged v5 implementation and public TEST
keys. 'ticket_repair' is explicitly a scheduler-only experiment, not a v6 wallet.
"""
from __future__ import annotations
import argparse
from collections import Counter
from dataclasses import replace
from fractions import Fraction
import json
from pathlib import Path
import random
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'baseline' / 'fire_echo_v5'))
import fire_echo_v5 as f
import test_fire_echo_v5 as tests


def number(x: f.Phi) -> float:
    """Display/statistical calculation only, never spend authorization."""
    return float(x.display(18))


def exact_conjugacies(seed: int) -> dict:
    # x_v maps a moving coordinate to the canonical coordinate.
    rng = random.Random(seed)
    backwards = 0
    for _ in range(10000):
        t, h, s, v = [rng.randrange(-1000, 1001) for _ in range(4)]
        canonical_h = h + v*t
        evolved_t, evolved_h = t+1, canonical_h+s
        relative_h = evolved_h-v*evolved_t
        assert relative_h == h+s-v
        assert relative_h+v*evolved_t == evolved_h
        backwards += (s > 0 and v > s)
    # A genuine finite-domain Lens for EFFECTIVE age, not a lossless history map.
    forward = {a: f.invpow(a) for a in range(f.HORIZON+1)}
    backward = {g:a for a,g in forward.items()}
    assert len(backward) == f.HORIZON+1
    for a,g in forward.items():
        g_next=max(f.invpow(f.HORIZON),g*f.INV)
        assert backward[g_next] == min(a+1,f.HORIZON)
        c=f.Choice((1,0,0),(0,0,0))
        assert c.density(a) == f.Phi(6)-3*g
    reset_checks=0
    for age in range(1,145):
        original=f.Choice((1,0,0),(0,0,0))
        for channel in range(3):
            bits=list(original.bits);bits[channel]^=1
            changed=original.change(bits,age)
            expected=list((age,)*3);expected[channel]=0
            assert changed.ages(age)==tuple(expected)
            assert original.density(age)-changed.density(age)==f.ONE-f.invpow(age)
            reset_checks+=1
    curve=[]
    for age in (0,1,2,3,5,10,21,144):
        gap=f.invpow(age)
        curve.append({'age_epochs':age,'gap_exact':gap.pair(),
                      'gap_display':gap.display(18),
                      'equal_age_factor_display':number(f.Phi(2)-gap)})
    return {'moving_frame_cases':10000,'forward_world_backward_relative_cases':backwards,
            'effective_age_conjugacy_cases':145,'single_channel_reset_cases':reset_checks,
            'age_curve':curve,'cap_warning':'Capped effective age is canonicalized; raw timestamps are retained separately.'}


def age_fixture():
    p=f.Protocol();g=p.bootstrap()
    left,old=p.fracture(g.id,p.users[0])
    young,rest=p.fracture(left.id,p.users[0])
    payer,listener=p.fracture(rest.id,p.users[0])
    old,_=p.transfer(old.id,p.users[0],p.users[1],(1,0,0))
    listener,_=p.transfer(listener.id,p.users[0],p.users[3],(1,1,1))
    for _ in range(21):p.advance()
    young,_=p.transfer(young.id,p.users[0],p.users[2],(1,0,0))
    assert old.fire==young.fire
    snap=p.snapshot([old,young,listener]);mesh=f.PaperMesh(p.notes())
    return p,payer,old,young,listener,snap,mesh


def paid_comparison(jobs: int, targeted: bool) -> dict:
    p,payer,old,young,listener,snap,mesh=age_fixture()
    owners={old.owner:'old',young.owner:'young'}
    income={'old':f.ZERO,'young':f.ZERO};count=Counter();modes=Counter();units=Counter()
    costs=[];labels=[];new_steps=0;warmups=0
    start_principal=payer.fire
    with tests.Meter() as meter:
        # Uniform workload is prewarmed, so all measured tasks have identical cost.
        if not targeted:
            initial=f.initial_state(f.UNARY,'1111')
            job=tests.prepare(p,payer,snap,mesh,initial=initial,budget=8)
            outs,_=tests.complete(p,job,mesh,meter);payer=outs[0];warmups=1
        measured_start=payer.fire
        for i in range(jobs):
            slot=int(p.meta('slot'));selected=snap.select(payer,0,slot)
            who=owners[selected.owner]
            if targeted and who=='young':
                spec=f.LOOP;initial={'state':'q','head':i*300,'cells':[]};budget=256
            else:
                spec=f.UNARY;initial=f.initial_state(spec,'1111' if not targeted else '');budget=8 if not targeted else 1
            job=tests.prepare(p,payer,snap,mesh,spec=spec,initial=initial,budget=budget)
            outs,r=tests.complete(p,job,mesh,meter);payer=outs[0]
            assert outs[1].owner==selected.owner
            fee_units=r['new_steps']+1
            assert outs[3].fire==f.UNIT_PRICE*f.INV*fee_units
            assert outs[4].fire==f.UNIT_PRICE*f.invpow(2)*fee_units
            count[who]+=1;units[who]+=fee_units;income[who]+=outs[3].fire
            new_steps+=r['new_steps'];costs.append(fee_units);labels.append(who);modes[r['mode']]+=1
            assert outs[3].choice.ages(p.epoch)==(0,0,0)
        assert measured_start-payer.fire==f.UNIT_PRICE*sum(costs)
        assert sum(income.values(),f.ZERO)==(measured_start-payer.fire)*f.INV
        audit=p.audit()
        work=dict(meter.steps)
    assert audit['supply']==[1,0] and audit['pending_jobs']==0
    result={'jobs_measured':jobs,'warmup_jobs_excluded_from_income':warmups,
            'equal_initial_principal_exact':old.fire.pair(),
            'old_ages':[21,21,21],'young_ages':[0,0,0],
            'allocations':dict(count),'speaker_fee_units':dict(units),
            'speaker_income_exact':{k:v.pair() for k,v in income.items()},
            'speaker_income_display':{k:v.display(18) for k,v in income.items()},
            'old_fee_share':units['old']/sum(units.values()),
            'old_to_young_income_ratio':units['old']/units['young'],
            'modes':dict(modes),'new_speaker_TM_steps_measured':new_steps,
            'instrumented_steps_including_warmup':work,
            'audit':audit,'request_fee_unit_sequence':costs,
            'selected_owner_sequence':labels}
    p.close();return result


def ticket_repair(costs: list[int]) -> dict:
    """Fixed-price-ticket allocation ONLY. No new consensus or VM implemented."""
    p,payer,old,young,listener,snap,mesh=age_fixture()
    tree=f.MassTree([old,young],21);owners={old.owner:'old',young.owner:'young'}
    count=Counter()
    for slot in range(sum(costs)):
        selected=tree.select(*f.slot_fraction(slot));count[owners[selected.owner]]+=1
    ideal=number(old.mass(21))/number(old.mass(21)+young.mass(21))
    # Request regrouping/permutation cannot change the consumed consecutive slots.
    rng=random.Random(7107)
    grouping_checks=0
    for _ in range(100):
        shuffled=list(costs);rng.shuffle(shuffled)
        cursor=0
        for cost in shuffled:
            start=cursor;cursor+=cost
            assert cursor-start==cost
        assert cursor==sum(costs)
        grouping_checks+=1
    # Same-coordinate fracture must still give the same owner.
    fragments=[old]
    for depth in range(6):
        newer=[]
        for n in fragments:
            mid=n.lo+n.fire*f.INV
            newer.extend((replace(n,hi=mid,parent=f'audit-{depth}',index=0),
                          replace(n,lo=mid,parent=f'audit-{depth}',index=1)))
        fragments=newer
    split=f.MassTree(fragments+[young],21)
    assert split.mass==tree.mass
    mismatches=sum(tree.select(*f.slot_fraction(i)).owner != split.select(*f.slot_fraction(i)).owner
                   for i in range(4096))
    assert mismatches==0
    budget=f.UNIT_PRICE*sum(costs)
    speaker_allocations={who:f.UNIT_PRICE*f.INV*n for who,n in count.items()}
    listener_allocation=f.UNIT_PRICE*f.invpow(2)*sum(costs)
    assert sum(speaker_allocations.values(),f.ZERO)+listener_allocation==budget
    result={'status':'SCHEDULER-ONLY CANDIDATE; NOT INTEGRATED INTO V5',
            'allocated_budget_exact':budget.pair(),
            'allocated_speaker_fees_exact':{k:v.pair() for k,v in speaker_allocations.items()},
            'allocated_listener_fee_exact':listener_allocation.pair(),
            'allocation_conserves_budget_exactly':True,
            'fixed_price_service_tickets':sum(costs),'tickets_per_owner':dict(count),
            'old_fee_share_if_each_ticket_is_completed_and_paid':count['old']/sum(costs),
            'ideal_old_share':ideal,'request_grouping_checks':grouping_checks,
            'fragment_count':64,'same_coordinate_fracture_checks':4096,'fracture_mismatches':mismatches,
            'assumptions':['fixed snapshot, all offered services remain eligible and available',
                           'each ticket has equal funded tariff, including explicitly priced delivery',
                           'all consecutive reserved tickets settle; no selective skipping',
                           'jobs can be safely continued across service units',
                           'replication, cancellation, overhead, and integration remain to be designed']}
    p.close();return result


def availability_and_switching() -> dict:
    # Merely passing epochs does not require service, so an unused choice matures.
    p,payer,old,young,listener,snap,mesh=age_fixture()
    before=tests.stamp(p)
    assert old.choice.ages(p.epoch)==(21,21,21)
    assert p.audit()['paid_jobs']==0
    slot=int(p.meta('slot'));winner=snap.select(payer,0,slot)
    mesh.online.discard(winner.port)
    halts=0
    for _ in range(32):
        tests.halt(lambda:tests.prepare(p,payer,snap,mesh))
        assert tests.stamp(p)==before and int(p.meta('slot'))==slot
        halts+=1
    p.close()
    # Cost and seniority of one legal, same-owner east/west change.
    p,payer,old,young,listener,snap,mesh=age_fixture()
    changed,fee=p.transfer(old.id,p.keys[old.owner],p.keys[old.owner],(1,1,0))
    assert changed.choice.ages(p.epoch)==(21,0,21)
    assert changed.fire+fee.fire==old.fire
    per_delivery=f.UNIT_PRICE*f.INV
    equivalent=number(fee.fire)/number(per_delivery)
    # Verify no funding/work => no automatic payout; the change moves existing Fire.
    audit=p.audit();assert audit['supply']==[1,0] and audit['paid_jobs']==0
    result={'unserved_paper_ages':[21,21,21],
            'unserved_paper_multiplier':number(old.choice.density(21))/3,
            'automatic_age_income':0,
            'offline_selected_service_rejections':halts,'slot_advanced_while_offline':False,
            'single_route_change':{'before_ages':[21,21,21],'after_ages':[21,0,21],
                                   'fire_before':old.fire.display(18),'fee_exact':fee.fire.pair(),
                                   'fee_display':fee.fire.display(18),
                                   'fraction_of_service_principal':number(fee.fire)/number(old.fire),
                                   'equivalent_speaker_cached_delivery_fees':equivalent,
                                   'before_multiplier':number(old.choice.density(21))/3,
                                   'after_multiplier':number(changed.choice.density(21))/3},
            'audit':audit}
    p.close();return result



def relative_value_controls() -> dict:
    """A common age multiplier redistributes no share and creates no work."""
    w=f.invpow(3)
    young=[f.Paper('relative-test','A',f.ZERO,w,f.Choice.fresh((1,0,0),21),'fixture',0),
           f.Paper('relative-test','B',w,2*w,f.Choice.fresh((1,0,0),21),'fixture',1)]
    aged=[replace(n,choice=f.Choice(n.choice.bits,(0,0,0))) for n in young]
    before=f.MassTree(young,21);after=f.MassTree(aged,21)
    differences=sum(before.select(*f.slot_fraction(i)).owner != after.select(*f.slot_fraction(i)).owner
                    for i in range(4096))
    assert differences==0
    raw=[]
    for age in (0,21,144):
        c=f.Choice((1,0,0),(0,0,0));c.density(age)
        raw.append(f.run_quantum(f.UNARY,f.initial_state(f.UNARY,'1'*15),32,'cold-control')['steps'])
    assert raw==[16,16,16]
    c=f.Choice((1,0,0),(0,0,0))
    assert c.density(144)==c.density(1000000)
    return {'all_workers_age_together_coordinates':4096,
            'relative_allocation_changes':differences,
            'cold_steps_at_ages_0_21_144':raw,
            'score_stops_growing_after_epoch_age':144,
            'conclusion':'Seniority is a relative service allocation rule, not faster cold computation or new principal.'}


def main() -> None:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=HERE/'reward_results.json')
    ap.add_argument('--jobs',type=int,default=384)
    ap.add_argument('--seed',type=int,default=20260916)
    args=ap.parse_args()
    if not 64<=args.jobs<=4096:ap.error('--jobs must be between 64 and 4096')
    result={'status':'RUNNING','purpose':'Independent reward/canon audit of unchanged v5',
            'protocol_id':f.PROTOCOL,'seed':args.seed,'python':sys.version.split()[0],'tests':{}}
    start=time.perf_counter()
    sequence=[('canon_conjugacies',lambda:exact_conjugacies(args.seed)),
              ('equal_priced_paid_work',lambda:paid_comparison(args.jobs,False)),
              ('predictable_slot_variable_price_counterexample',lambda:paid_comparison(args.jobs,True)),
              ('ticket_repair_allocation_only',lambda:ticket_repair(result['tests']['predictable_slot_variable_price_counterexample']['request_fee_unit_sequence'])),
              ('availability_and_switching',availability_and_switching),
              ('relative_value_controls',relative_value_controls)]
    for name,fn in sequence:
        print('RUN',name,flush=True)
        try:result['tests'][name]=fn()
        except Exception as exc:
            result['status']='FAILED_TO_COMPLETE';result['failed_test']=name;result['error']=repr(exc)
            args.out.write_text(json.dumps(result,indent=2)+'\n');raise
        args.out.write_text(json.dumps(result,indent=2)+'\n')
        print('RECORDED',name,flush=True)
    result['status']='COMPLETE; INCOME-GUARANTEE COUNTEREXAMPLE REPRODUCED'
    result['elapsed_seconds']=round(time.perf_counter()-start,3)
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],result['elapsed_seconds'],flush=True)

if __name__=='__main__':main()
