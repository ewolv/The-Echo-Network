#!/usr/bin/env python3
"""Reproduce Fire Echos research. Public TEST keys only; never live money.

Default: run the six white-paper evidence experiments.
--quick: package/smoke checks only, not the headline workload totals.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def verify_manifest() -> None:
    expected = json.loads((ROOT / "SHA256SUMS.json").read_text())
    for relative, digest in expected.items():
        path = ROOT / relative
        if not path.is_file():
            raise RuntimeError(f"Missing packaged evidence/source: {relative}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            raise RuntimeError(f"Package differs from its supplied manifest: {relative}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick", action="store_true", help="Run packaging smoke checks instead of the full experiments")
    parser.add_argument("--output-dir", type=Path, help="Use a new, empty output directory")
    args = parser.parse_args()
    if not __debug__:
        parser.error("Do not run assertion-based research tests with Python -O or -OO.")
    verify_manifest()
    if args.output_dir is None:
        tag = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        output = ROOT / "rerun_results" / tag
    else:
        output = args.output_dir.resolve()
    if output == ROOT or output == ROOT / "results" or ROOT / "results" in output.parents:
        parser.error("Choose a separate output directory; supplied evidence must not be overwritten.")
    if output.exists() and any(output.iterdir()):
        parser.error("The output directory must be new or empty.")
    output.mkdir(parents=True, exist_ok=True)
    base = ROOT / "baseline" / "fire_echo_v5"
    audit = ROOT / "prior_audit" / "Fire_Echo_Reward_Audit"
    s1 = ROOT / "s1"
    commands = [
        ("symbolic_results", s1, ["symbolic_analysis.py"]),
        ("boolean_bridge_results", s1, ["test_boolean_bridge.py"]),
    ]
    if args.quick:
        commands += [("s1_quick_mixed", s1, ["test_s1.py", "--stress-only", "--jobs", "24", "--seed", "20260930"])]
    else:
        commands = [
            ("v5_fresh_rerun", base, ["test_fire_echo_v5.py", "--jobs", "1800", "--seed", "20260926"]),
            ("v5_reward_rerun", audit, ["reward_audit.py", "--jobs", "384", "--seed", "20260926"]),
            ("symbolic_results", s1, ["symbolic_analysis.py"]),
            ("s1_results", s1, ["test_s1.py", "--jobs", "800", "--seed", "20260928"]),
            ("s1_seed2", s1, ["test_s1.py", "--stress-only", "--jobs", "600", "--seed", "20260929"]),
            ("boolean_bridge_results", s1, ["test_boolean_bridge.py"]),
        ]
    summary = {"mode": "quick package checks" if args.quick else "full evidence reproduction", "python": sys.version, "runs": []}
    for name, cwd, command in commands:
        result_path = output / (name + ".json")
        full = [sys.executable, *command, "--out", str(result_path)]
        print("RUN", name, flush=True)
        started = time.perf_counter()
        with (output / (name + ".log")).open("w") as log:
            completed = subprocess.run(full, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=False)
        row = {"experiment": name, "command": full, "seconds": round(time.perf_counter() - started, 3), "returncode": completed.returncode}
        if completed.returncode == 0 and result_path.is_file():
            result = json.loads(result_path.read_text())
            row["result_status"] = result.get("status")
            # The v5 audit intentionally reports a reproduced counterexample.
            ok = result.get("status") in ("PASS", "COMPLETE; INCOME-GUARANTEE COUNTEREXAMPLE REPRODUCED")
        else:
            ok = False
        summary["runs"].append(row)
        (output / "runner_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        if not ok:
            print(f"STOP: inspect {output / (name + '.log')}", file=sys.stderr)
            return 1
        print("COMPLETE", name, row["result_status"], flush=True)
    print(f"Results: {output}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
