# Fire Echos
## Conserved phi paper, signed courier payments, and time-aged choice
Concept: Eric James Wolverton. Computational study prepared with ChatGPT. 6 September 2026.

E R I C   J A M E S   W O L V E R T O N

> The central proposition
> Preserve the history of a choice, let that history weight access to funded service, and never confuse a larger opportunity with newly created money.

A symbolic design and experimental white paper
Research edition S1 • 6 September 2026

Concept: Eric James Wolverton
Computational study and document preparation: ChatGPT

Includes an unchanged v5 baseline rerun, a new fixed-ticket research fork, signed courier-payment tests, exact symbolic derivations, and reproducible source code.

RESEARCH SOFTWARE — NOT A LIVE CURRENCY OR SECURITY CERTIFICATION



## Executive summary

Fire Echos treats a piece of phi paper as a canonical money-state object: it identifies existing principal, its current owner, three persistent Boolean policies, their certified ages, and the evidence needed to create a successor. Paper circulates through an ad-hoc service overlay. The same accounting engine can pay a recipient and a bounded chain of couriers, or reserve a ticket for checked computation.

The refined mechanism separates **principal**, **seniority**, and **knowledge**. Principal is conserved. Seniority is a bounded scheduling advantage earned by keeping a policy-owner relationship unchanged. Knowledge is a retained, checked result that may avoid repeated computation. None automatically creates market demand, purchasing power, or additional Fire.

| Fresh evidence | Measured result |
| --- | --- |
| Symbolic and Boolean analysis | 12 zero-residual identities; all 256 three-input Boolean functions checked. |
| Baseline v5 mixed workload | 1,800 paid jobs; exact final Fire = 1; 63 tampered receipts rejected. |
| S1 integrated service workloads | 2,592 paid tickets across the stated reward, continuation, reuse, mixed and Boolean experiments. |
| S1 courier workload | 600 payments; 2,401 courier outputs; exact total Fire = 1. |
| Reward correction | Older service earned 682 of 1,024 fixed-price tickets: 66.6016% of gross speaker fees. |


The important observed failure was economic, not an accounting error. In the old request-count scheme, a requester could place low-priced work in old-note slots and high-priced work in young-note slots. The old service still received more requests, but only 0.7663% of the fees. S1 replaces variable-price turns with a fixed-price reservation for at most eight machine transitions or one checked-result delivery. Long computations resume across multiple tickets. [E2, E4]

> Meaning of “turn off rather than corrupt”
> A conforming local state machine refuses an unproven transition. Five of seven fixed witnesses are required; the safety argument assumes at most two faulty witnesses. Missing evidence or quorum can stop progress. The experiments do not establish unconditional safety against every adversary or a global physical shutoff.

All monetary results are from local research models with public deterministic test keys. The delivered code is reproducible experimental evidence, not production wallet software. [E1–E6]



## Reader’s map and notation

| Pages | Topic |
| --- | --- |
| 4–5 | What can start at zero; exact principal and the paper object |
| 6–8 | The three choices; frozen computation; Lens and Lion semantics |
| 9–11 | Age, switching cost, and the fixed-ticket reward correction |
| 12–15 | Funded execution, signed courier chains, safety and the network |
| 16–18 | Verification methods, measured workloads and actual iteration |
| 19–20 | Economic limits, deployment conditions and conclusions |
| 21–23 | Reproduction, proof notes and primary references |


This paper has three evidence levels. **Derived** statements follow from explicitly written equations or finite symbolic checks. **Measured** statements are recorded in the new JSON logs. **Proposed** deployment features are not silently treated as implemented. The S1 source is a new fork with a different protocol identity; it does not overwrite the original v5 artifacts.

| Symbol / term | Meaning |
| --- | --- |
| φ | (1 + √5)/2, with φ² = φ + 1 |
| w | Existing spendable principal; an exact element a + bφ |
| b = (b₀,b₁,b₂) | Inside/outside, east/west, and talk/listen policies |
| t, sᵢ, aᵢ | Certified epoch, last policy-change epoch, and age t − sᵢ |
| W, M | Exact scheduler weight W; equivalent display weight M = W/3 |
| p | One fixed S1 ticket price, φ⁻³² Fire in the demonstration |
| CAS (algebra) | SymPy computer algebra, used for this study |
| Content-addressed store | Hash-indexed immutable objects; not the symbolic algebra engine |


An epoch is a model unit. The harness advances and certifies epochs; it does not supply a secure wall-clock oracle. “Age” therefore means certified policy seniority, not independently proven continuous uptime. “Paid” means existing test principal was transferred through the model’s settlement rule. It is not evidence of real customers or exchange-market prices.

Evidence keys [E1] through [E6] refer to the supplied code and fresh results. [P1–P2] identify the earlier project documents. [R1–R8] identify external primary foundations. Full entries appear on pages 21 and 23.



## The zero-value origin

The motivating image is deliberately simple: anyone can copy the paper, cut a piece, address it, and participate. A rigorous account must distinguish a **blank protocol carrier**, a **nominal monetary quantity**, and a **market valuation**. A free copy of software can be available to everyone while containing no spendable principal. Its ability to accept a funded payment is useful; the copy itself is not a new balance.

### A cut transfers an amount; it does not create it

```text
w = wφ⁻¹ + wφ⁻²
```

For a funded note, the φ identity gives two smaller descendants whose values sum to the parent. If the parent literally contains zero principal, positive children cannot result under conservation. With nonnegative outputs, 0 = w₁ + w₂ implies w₁ = w₂ = 0. A positive first payment must instead have a funding input, an explicitly authorized issuance rule, or a redeemable obligation. A new label alone supplies none of those.

```text
blank 0 + funded input w  →  recipient w − fees + courier fees
```

The safe operational interpretation is therefore: **blank paper starts at zero; a funded cut carries existing value**. An owner can sponsor a blank recipient or pay it for service. The recipient’s first fee begins a balance, not a private mint. Splitting that balance preserves the same asset and accounting history.

### What the executable model actually initializes

Both v5 and S1 initialize one nominal Fire in one deterministic test wallet and partition the interval [0,1). That fixture has no asserted dollar price and is not a demonstrated fair launch. A free, zero-balance bootstrap wrapper is a conceptual interface; the executable ledger admits funded positive notes. Production issuance and initial distribution remain explicit deployment decisions, not results of the simulator. [E1, E4]

### One common asset, not infinitely many interchangeable mints

Independent nodes can run the same protocol and accept descendants of the same recognized root. Independently creating a different root does not make its units redeemable for the first root’s units. The manifest, root, authorized issuance policy, committee and epoch rules define the accounting domain. S1 changes the manifest, so its test Fire is a different experimental domain from v5 Fire.

> Simplification retained
> Anyone may start a wallet. Anyone may receive a funded piece. No participant may turn a zero-balance copy into positive conserved principal merely by cutting, waiting, forwarding, or self-paying.



## Exact money and the paper object

Amounts are stored as integer pairs (a,b), denoting a + bφ. Multiplication reduces with φ² = φ + 1. Comparisons use exact integer inequalities rather than binary floating point. Decimal values shown in tables and figures are explanatory only. The symbolic study confirmed the defining identity, multiplication reduction and fracture conservation. [E3]

```text
(a + bφ)(c + dφ) = (ac + bd) + (ad + bc + bd)φ
```

Every live note owns a half-open interval [lo,hi) of the same root, with amount w = hi − lo. A valid transition consumes complete input intervals and creates nonoverlapping outputs with exactly the same coverage. Checking coverage is stronger than checking only a scalar sum: two overlapping claims cannot masquerade as distinct pieces whose arithmetic happens to add up.

| Stored field | Purpose |
| --- | --- |
| protocol + root | Rule identity and common accounting domain |
| owner | Public-key identity authorized to spend the resting note |
| lo, hi | Exact principal interval; the amount is derived |
| bits[3], since[3] | Persistent policies and their individual certified origins |
| parent + output index | The transition that created this immutable state |
| service sequence + head | Continuity of checked service and its latest receipt |
| note ID / service port | Content hash of this state; separately derived stable routing identity |


An offered payment additionally names a target recipient. The resting note’s owner is not silently rewritten when a packet is copied. The signed offer and accepted successor specify the change of ownership. Content-addressed storage holds the prior objects and proofs; the paper need carry only a current head and enough bootstrap information to obtain them.

### Bounded metadata does not mean history-free verification

Hash references make the current object compact, but do not remove the need to retain and validate relevant history. The reference implementation keeps a ledger, spent-input records, witness locks and a content-addressed object store. It is not a no-ledger system or a constant-time light-client proof. Exact coefficients, tape states and request sizes have explicit finite resource bounds. Missing required data causes refusal, not an invented balance.

A fixed S1 update stamp is φ⁻³² Fire. A note too small to cover a positive stamp must reject that operation or use a separately funded path; limitless mathematical subdivision is not a promise that every tiny note remains economical to spend.



## Three choices, eight policies

The three bits are durable service policies. They are not the rapidly changing instruction bits of a running machine. They determine who can use an offered service, which logical direction carries a request, and whether the service proposes or checks a result. All eight combinations remain meaningful.

| Channel | Bit 0 | Bit 1 |
| --- | --- | --- |
| b₀: scope | Inside: same requester key | Outside: different requester key |
| b₁: direction | East: increasing hash direction | West: decreasing hash direction |
| b₂: role | Talk: compute or deliver | Listen: replay-check or authenticate |


These are logical coordinates and key relationships. East is not physical longitude; inside does not imply encryption; a different public key is not proof of an independent person. The network and the interpreter enforce a selected policy, but three bits do not describe the entire machine tape, program, resource budget or security state.

### Inheritance is continuity, not multiplication

| Transition | Treatment of the three clocks |
| --- | --- |
| Wait through a certified epoch | The three unchanged choices become older. |
| Same-owner fracture | Both descendants inherit the choices; their amounts and aggregate weight add to the parent. |
| Successful service renewal | Preserve principal and policy ages on the service-continuity note. |
| Change one policy | Reset only that clock; the other two retain their origins. |
| Change owner | Reset all clocks: S1 follows v5’s policy-owner seniority convention. |
| Receive a new fee output | All three clocks start fresh; the old worker’s age is not copied onto new earnings. |


The complete finite clock-transition test covered every old bit pattern, every next pattern and every effective age from 0 to 144: 8 × 8 × 145 = **9,280 cases**. It checked both selective reset and the exact loss of scheduling weight. [E3]

> A deliberate boundary
> S1 does not sell an unchanged age history to a new owner. An aged worker can earn fees; newly received money starts young. Bearer-transferable seniority would be a different economic policy requiring new analysis, not a silent property of this model.



## Choice against an immutable past

The project’s time convention can be made precise. The **past** consists of committed constants: a program, an earlier state, an origin timestamp or a checked receipt. The **present** is an authorized state-transition step. The **future** consists of inputs or continuations that are not yet resolved. A later choice may select a new continuation of a frozen computation without altering any earlier committed result.

```text
immutable program P + later input b  →  new receipt for P(b)
```

### A complete three-input Boolean board

A single-output Boolean function of three bits is completely described by eight output bits. There are 2⁸ = 256 such boards. SymPy simplified every board and evaluated every input, giving 2,048 checked outcomes. A separate compiler constructed bounded Turing-machine tables for the same 256 boards. All 2,048 machine evaluations halted after exactly three transitions with the correct answer. [E3, E6]

One parity board was then paid to answer all eight inputs through S1. Eight separate funding authorizations produced eight receipts referring to the same immutable program identity. The outputs were 0, 1, 1, 0, 1, 0, 0, 1. Altering the board produced a different program identity; it did not authorize replacement of the earlier board or its receipts. [E6]

### A stored choice is not a changed historical fact

The economic policies on a paper and the input bits of an arbitrary Boolean board are different objects. The policies direct service and carry seniority. A board is a didactic frozen computation that may accept a later authorized input. The bridge test demonstrates funded evaluation of historical code; it does not make every arbitrary board input an inherited monetary option, and it does not let money revise a settled result.

A fixed policy can still preserve an ongoing right to act. Keeping “outside / east / talk” unchanged preserves access to an eligible service role. Flipping one bit is a new present transaction: it can lead to a different future, but sacrifices that channel’s accumulated seniority. This is the concrete sense in which the old paper remembers choices while the world continues.

> What the test does not claim
> No physical retrocausality was measured. No future action changes a previously committed receipt. “Choice in the computational past” means a new authorized branch evaluated against preserved historical structure.



## The Lens and the Lion canon

The Lens is an explicitly invertible change of representation. If x maps a state space A bijectively to X, transporting an operation means unlocking to X, applying the operation there, and relocking to A. The domains, inverse and operation must actually exist.

```text
Fˣ = x⁻¹ ∘ F ∘ x
```

The Lion role is narrower than “all meanings are automatically equal.” For this implementation it is deterministic representation: canonical transition tables and restricted JSON objects yield repeatable content identities. Equivalent row orderings do not change a program’s identity. Arbitrary semantic equivalence of Python programs is not decided. Canonical serialization is an established prerequisite for stable hashing and signing, not a substitute for validation or consensus. [R2]

### “I go so fast, you go backwards” as a valid conjugate

```text
Fₛ(t,h) = (t + 1, h + s)
xᵥ(t,r) = (t, r + vt)
```

```text
xᵥ⁻¹(Fₛ(xᵥ(t,r))) = (t + 1, r + s − v)
```

For s = 1 and v = 3, canonical displacement is +1 and relative displacement is −2. Both descriptions map to the same event. SymPy reduced the transported expression to this result exactly. The fresh baseline reward audit also reran 10,000 integer-coordinate checks. This is one precise interpretation of the user’s modeling phrase, not a physical reversal of time. [E2–E3]

### Age and the shrinking gap

```text
g(a) = φ⁻ᵃ;     g(a + 1) = g(a)/φ
```

As an unchanged choice gets older, its distance from full seniority gets smaller. Age increases while the remaining gap decreases: two opposite coordinate descriptions of the same evolution. The effective-age domain 0…144 maps one-to-one onto its gap values; the capped score does not reconstruct unbounded raw history. The timestamps are therefore retained separately.

The baseline additionally passed 500 random-program tape-reflection cases and 325 stop/resume cases. These tests concern explicit machine transformations and continuations. They do not show that a bijection grants arbitrary algebraic laws to a function with incompatible domains, or that a canonical hash proves external truth. [E1]



## How age earns an advantage

For each policy i, let aᵢ = t − sᵢ and uᵢ = min(aᵢ,144). Define a bounded persistence bonus hᵢ = 1 − φ⁻ᵘⁱ. The equivalent service mass M and the exact scheduler weight W are:

```text
M = w[1 + (h₀ + h₁ + h₂)/3]
W = 3M = w[6 − Σᵢ φ⁻ᵘⁱ]
```

The code uses W, so division by three is never needed to select a branch. For nonnegative ages and positive principal, w ≤ M < 2w. Age changes eligibility weight, not the note’s spendable amount. It is a policy-defined advantage, not a measured discovery about the intrinsic price of memory.

![Figure](figures/age_weight.png)

Figure 1. Displayed curve for three equally aged policies. The engineering cap is 144 epochs; the curve already approaches its bound rapidly. Exact arithmetic, not this plot, controls the ledger.

At ages 0, 1, 5, 10 and 21 the equal-age multiplier is approximately 1, 1.382, 1.910, 1.992 and 1.999959. More than 99% of the possible bonus is reached by age 10. This is an important calibration finding: an epoch duration must be selected deliberately before deployment. No claim that ten seconds or ten years is appropriate follows from the mathematics. [E3]

### Why cutting does not copy the reward

```text
W(w₁ + w₂, a) = W(w₁,a) + W(w₂,a)
```

The weight is linear in conserved principal. Subdivision distributes the old claim instead of cloning it. S1’s fixed-snapshot test replaced one service interval with 64 descendants and found zero owner-selection differences across 8,192 coordinates. This does not prove immunity to membership changes, selective availability or independent routing strategies. [E4]



## Change becomes more expensive

The cost of changing an old policy can be defined without inventing money or imposing an ever-growing monetary fine. On unchanged principal, resetting channel i removes that channel’s persistence bonus. The loss of service mass is:

```text
ΔMᵢ(a) = (w/3)(1 − φ⁻ᵃ),     before the age cap
```

For w > 0, this loss grows as the choice ages. Two unmodified channels preserve their contribution. The changed policy must age again to recover its lost priority. In that operational sense, introducing a change becomes more expensive over time even though the old history itself is never edited.

```text
dΔM/da = (w ln φ / 3)φ⁻ᵃ > 0
d²ΔM/da² = −(w(ln φ)² / 3)φ⁻ᵃ < 0
```

The continuous extension makes the tradeoff explicit: the chosen cost increases but does **not** accelerate. It is concave and eventually capped. These derivative identities were checked symbolically. The discrete implementation uses integer epochs. S1 also charges one small, fixed update stamp, rather than v5’s balance-proportional surcharge for each changed bit. [E3–E4]

### The accelerating candidate and why it was not installed

An alternative D(a) = d₀ + ca² with c > 0 has D″(a) = 2c: an accelerating monetary change price. But its limit is infinite, so it eventually exceeds any fixed finite budget. That would make adaptation unaffordable by construction, not demonstrate useful purchasing power. SymPy confirmed both the acceleration and divergence; the candidate was rejected.

A bounded S-curve h(a) = a²/(H² + a²) provides an optional early acceleration interval: its second derivative is positive only for a < H/√3, then negative. This candidate was symbolically analyzed but is **not implemented** in S1. Choosing it would change the protocol identity and require scheduler, reset and economic tests again. The current paper prefers the smaller inherited φ rule.

> Final policy
> Preserve growing, bounded switching opportunity cost. Do not promise endless acceleration, infinite deflation or rising external prices. A system should retain room to adapt rather than make every mature choice practically irreversible.

The more meaningful design parameter is the relation among epoch duration, useful service demand, availability, update costs and the maximum seniority advantage. The simulation supplies a mechanism and calibration questions, not an economically optimal setting.



## The reward rule after iteration

The fresh audit reproduced a genuine limitation in v5. With equal-price requests, old and young equal-principal services received 255 and 129 paid deliveries. When expensive work was targeted at predictable young-service slots, the same request counts produced only 256 old-service fee units against 33,153 young-service units. Exact principal still conserved. Job share was not fee share. [E2]

![Figure](figures/fee_share.png)

Figure 2. These are separate controlled experiments, not market returns. The S1 experiment is end-to-end settlement, rather than the earlier audit’s allocation-only candidate.

### The S1 correction

One scheduling turn now buys one predefined service reservation: at most eight Turing-machine transitions with checked delivery, or one authenticated delivery of an already checked result. Every accepted ticket has the same demonstration price p = φ⁻³². A 256-transition computation therefore requires 32 tickets and may continue across different workers. It cannot consume a single cheap scheduling turn and then bill 256 variable units.

In 1,024 adversarially cost-targeted S1 tickets, the old service earned 682 ticket fees and the young service earned 342: **66.6016% versus 33.3984%**. Costs still differed: the old worker performed one new transition and the young worker 2,736. Fixed gross receipts therefore do not guarantee fair profit or equal physical work. Workers must accept a tariff appropriate to the bounded service class. [E4]

The condition is narrow and deliberate: a frozen eligible snapshot, continuous availability, consecutive tickets without strategic skipping, and one common tariff. Regrouping a fixed ticket sequence into requests does not change its allocation. Cancellations, selected-worker failures and changing membership are not solved by changing the tariff.



## From funded ticket to receipt

The money-state graph and the machine-state graph meet at an authorized ticket. A program is a bounded transition table; the interpreter executes that table; the result becomes checked data; a committed receipt permits successor paper states. The algorithm is expressed through the data structure, but still needs an interpreter, processors, storage and transport.

```text
LIVE → RESERVED → CHECKED → COMMITTED
Failure before commit: reject or retain the prior reservation
```

The payer first signs a job binding its live funding note, current service snapshot, consecutive slot, program, complete initial state, eight-step budget, selected talk and listen services, routing paths and fixed quote. Service acceptance postcards and a quorum certificate bind the reservation. Funding is not freely spendable elsewhere while the job is pending.

A talk service runs the bounded machine or supplies a previously certified result. A listen service replays new work or authenticates the exact cached result. Different service keys are required for the external case, but key separation alone does not prove organizational independence. The result receipt binds the job and dependencies, not merely a plausible output.

### One transaction creates the entire paid outcome

Settlement consumes the payer note and two service-continuity notes. It creates payer change, two renewed service notes and two fresh fee notes. Service principal and unchanged policy ages persist. The fee pieces begin at age zero. The receipt and any new cached-result certificate become visible in the same local SQLite transaction. [E4]

```text
talk fee = pφ⁻¹;    listen fee = pφ⁻²
payer change + talk fee + listen fee = payer input
```

Repeating a completed receipt returns the original outcome without paying again. A conflicting receipt is rejected. An interrupted local transaction rolls back its uncommitted outputs; a persistent reservation may be retried with the same authorization. SQLite supplies the implementation mechanism under its operating-system and storage assumptions, not a proof against every possible hardware failure. [R4]

> Three different stopping states
> HALTED is successful program completion. SUSPENDED is successful exhaustion of a bounded quantum with a valid continuation. Protocol rejection is a failure to authorize a money transition. These states must never be counted interchangeably as either success or corruption.



## A payment travels by signed echoes

S1 adds a separate, tested courier-payment path. The sender first cuts the desired gross payment into a funded note. It signs an immutable offer naming the input, recipient, original choices, total fee cap and maximum hop count. A courier may copy that offer and append a signed fee claim; appending alone neither spends nor reserves money.

```text
sender offer → signed hop → signed hop → recipient acceptance
recipient value = gross input − sum of accepted courier fees
```

Each hop binds the offer hash, previous signed-hop hash, courier identity and a positive exact fee. S1 permits at most eight hops. Repeated keys, endpoint keys charged as couriers, broken ordering, bad signatures, negative or zero fees and claims above the sender’s cap are rejected. A different set of keys could still belong to one adversary; this is not a Sybil-proof work measurement.

### What the recipient signs

The recipient’s acceptance names the offer hash and the hash of the entire selected chain. Accepting one candidate does not approve competing chains. The accepted transaction creates the recipient output and all courier outputs at once, using disjoint slices of the original input. The sender need not issue a new signature for every later hop because the original authorization already bound the recipient and fee limits.

The common input’s spent-resource record prevents another chain from independently consuming the same money. A recipient signature alone is not finality: the input must remain live, all evidence must validate, and the fixed witness threshold must certify its unique consumption. A replay cannot pay couriers twice.

### Echo does not mean every broadcast earns a fee

Only the accepted chain is paid. Duplicates and losing routes have no separate claim. A recipient can compare the offers it actually receives, but the model does not discover a globally cheapest route or guarantee that every useful forwarder gets compensated. Recipients can refuse to sign, and senders or relays can waste effort before acceptance. Real transport pricing, flood limits and recipient non-cooperation remain deployment concerns.

The deterministic attack cases exercised altered recipients, changed fees, loops, reordered chains, invalid signatures, excess fees and hops, insufficient quorum, a signature for another chain, replay and three injected rollback points. The separate randomized workload settled 600 payments with 2,401 courier outputs; copied offers created no additional principal. [E4]



## Fail closed, within a stated boundary

Every irreversible accounting step must have exact conservation, valid authority, coherent lineage, admissible resource bounds and an unspent input. Invalid packets are rejected before a money-state mutation. A conflicting valid request can instead leave persistent locks that need recovery. “OFF” is a refusal to make an unproven transition; it is not a claim that arbitrary bad traffic instantly powers down every machine.

### The fixed-committee argument

```text
n = 7, q = 5, f ≤ 2
|Q₁ ∩ Q₂| ≥ 2q − n = 3 > f
```

Two five-member quorums intersect in at least three witnesses. If at most two are faulty, at least one intersection member is honest. If that witness durably refuses to authorize two bindings for the same resource, two conflicting certificates cannot both form. This is an assumption-based intersection argument. A full Byzantine replicated state machine needs substantially more machinery than certificate counting. [R3]

The new symbolic enumeration checked all 441 ordered pairs of five-member quorums for each fixed faulty set of size 0, 1, 2 and 3. No potentially conflicting pair existed through two faults. With three specified faulty witnesses, six pairs could share only faulty members. These are exhaustive combinatorial cases, not estimated attack probabilities. [E3]

### What the software does not independently establish

The seven witnesses are local persistent signing stores driven by a trusted transition reducer. They are not seven independently administered hosts replaying a complete Byzantine consensus protocol. Keys are intentionally public deterministic test keys. Time, snapshots and initial peer contacts are supplied by the harness. The model has no production key custody, view change, dynamic membership, certified cancellation or recovery from every form of state loss.

If the fault bound is exceeded, conflicting certificates can become possible before honest observers reconcile their views. The correct claim is not “every attack makes the network halt before damage.” It is: **under the declared validation and authority assumptions, the tested local reducer does not accept an unproven accounting transition**. An unavailable quorum or missing evidence sacrifices progress rather than guessing a balance.

A partitioned offline recipient may see a signed promise, not final spendable money. Deterministic consensus cannot in general guarantee termination in a fully asynchronous system with even one crash failure; practical progress needs additional assumptions. [R5]



## The network and reusable history

The overlay uses paper-derived logical service ports. A state hash changes after a renewal; a port derived from the root, owner and right interval boundary can persist across ordinary service updates. A cached neighbor can therefore learn a new certified head without the simulator rebuilding every contact table. Fracture and ownership changes can create new ports that still require discovery.

The fresh v5 route regression modeled 128 ports on 32 owner identities. All 2,000 healthy routes delivered. After ten whole owners were removed, stale local contacts delivered 1,928 of 2,000 attempts and halted 72. All 500 deliberately cross-partition attempts halted. These are logical reachability experiments, not measurements on real phones, radios or Internet hosts. [E1]

### Reuse knowledge, not payment authority

```text
result key = H(VM, namespace, program, full input state, budget)
```

A retained result can answer repeated requests with exactly matching dependencies. Each new delivery still needs a fresh funded job and acceptance. A changed program, input, virtual machine or authorization namespace cannot borrow an unrelated certificate. Result reuse is an established dependency-sensitive computation technique; it is not a consequence of the monetary age score. [R6]

In v5’s repeated-request control, 128 requests for a 32-transition calculation required 64 worker-plus-listener transitions instead of 8,192 without reuse: 99.21875% fewer interpreter transitions. This is not a measured end-to-end speedup. S1’s own 128-request, four-transition case used eight worker-plus-listener transitions instead of 1,024. Its fixed reservation price deliberately remained 128 ticket units. [E1, E4]

### Complexity and operational cost

The authenticated sum tree supports logarithmic selection descent after construction, but the whole reference wallet is not logarithmic. It scans live notes to locate continuity, retains transaction history, verifies signatures and accesses databases. Tiny phi fragments increase object count; long exact coefficients increase arithmetic cost. A compact current head does not imply constant total storage.

The network cannot infer honest independent identities merely because it contains many note vertices. Uptime, discovery, bandwidth, retention, transport authentication, denial-of-service resistance and committee independence must be supplied and tested separately. Missing computation history is a failed verification dependency, not a reason to invent a cached answer.



## Verification method and baseline

The study used Python 3.13.5, SymPy 1.14.0, cryptography 46.0.4 and SQLite 3.46.1 in this environment. These are reproduction versions, not security recommendations. SymPy supplied actual symbolic simplification and Boolean manipulation; exact Fire arithmetic was independently enforced by the reference pair representation. [R1, E3]

| Layer | Fresh execution and scope |
| --- | --- |
| Symbolic identities | 12 expressions reduced to zero, including fracture, weight conservation, reset loss, fee conservation, conjugacy and candidate switching derivatives. |
| Finite Boolean layer | 256 functions × 8 inputs = 2,048 outcomes; 9,280 age/choice transitions; 98,304 signed cube relabeling round-trip checks. |
| Machine bridge | 2,048 compiled Boolean executions; eight distinct funded branches of one frozen program. |
| Unchanged v5 baseline | The full 16-group suite reran with 1,800 mixed paid jobs, seed 20260926. |
| Existing reward audit | Both 384-request paid experiments reran; the variable-price counterexample was reproduced, not relabeled as a pass. |
| New S1 fork | Fixed-ticket integration, courier payment, rollback/restart and two mixed-workload seeds; details on the next page. |


### Baseline results, not inherited claims

The 1,800-job v5 mixed workload completed 469 EXECUTE and 1,331 DELIVER jobs. It rejected 63 tampered receipts and 44 subquorum preparations. Nineteen injected settlement failures rolled back and then retried. Seventeen paid direction changes were included. The final partition audit found exactly one Fire, 3,673 live notes and zero pending jobs. [E1]

Other baseline checks included 5,000 algebra trials, 513 fracture depths, 18 named safety/recovery cases, continuation resource bounds, a child-process abrupt-exit test, 500 machine-reflection cases and 325 stop/resume cases. The fresh full run took 139.002 seconds in this container; this is test-suite runtime, not a transaction-per-second benchmark.

> Meaning of test coverage
> An exhaustive test covers its stated finite domain. It does not exhaust all programs, networks, disk failures, adversaries or economic strategies. Randomized workloads explore additional states; zero observed accounting failures is evidence about those executions, not a proof of universal security.



## S1 measured results

| Workload | Measured outcome |
| --- | --- |
| Targeted-price reward test | 1,024 settled tickets; old 682, young 342; old gross-fee share 66.6016%. |
| Long computation | 256 transitions executed through 32 paid eight-step tickets, with transferable continuation state. |
| Repeated computation | 128 requests; 1 execution and 127 result deliveries; 8 total worker-plus-listener transitions. |
| Frozen Boolean board | 8 paid inputs, 8 outputs and one unchanged canonical program. |
| Mixed seed 20260928 | 800 tickets: 72 EXECUTE, 728 DELIVER; 28 bad receipts and 20 subquorum preparations rejected. |
| Mixed seed 20260929 | 600 tickets: 71 EXECUTE, 529 DELIVER; 21 bad receipts and 15 subquorum preparations rejected. |
| Signed courier seed 20260927 | 600 payments, 2,401 courier outputs; 20 bad acceptances, 17 subquorum attempts and 14 replays rejected. |


The listed S1 service workloads total **2,592 paid tickets**. They exclude setup transfers, the separate deterministic safety ticket and courier payments. The two mixed workloads injected and recovered from 16 settlement failures. Each independent completed workload ended with exact Fire = [1,0] and no pending jobs. [E4–E6]

### Failure and replication-of-rights checks

The deterministic ticket suite passed eleven checks spanning wrong ticket class, insufficient quorum, reuse of reserved funding, tampered receipts, forged postcards, three rollback phases, database reopen, idempotent completion and conflicting replay. The courier suite passed fifteen checks including a valid competing route that could not spend an already consumed input. These are local API and database tests.

The fixed-snapshot fracture experiment tested 64 descendants at 8,192 scheduling coordinates with zero owner changes. One hundred regroupings of the same 4,096-ticket sequence likewise preserved its owner allocation. When equal competitors aged together, their relative allocation did not improve: zero changes across 4,096 coordinates. Age is a relative advantage, not aggregate new wealth. [E4]

The S1 main test run took 153.957 seconds and the second mixed workload 45.807 seconds in this container; concurrent load can affect those timings. The hash-checked logs record exact amounts and modes. The negative coefficient in an exact a + bφ pair is not a negative balance: positivity is determined by the value of the entire expression.



## Actual iteration, including rejection

| Candidate or finding | Decision after analysis / execution |
| --- | --- |
| Positive money from a zero input | Reject under conservation. Interpret a first valuable cut as funded by an admitted input. |
| One paper, one reward ticket | Reject: splitting into 64 papers gives 64/65 of naive tickets against one equal opponent. |
| Principal-weighted age | Retain: fracture distributes aggregate weight instead of multiplying it. |
| One scheduling turn per variable-price job | Reject as an income-proportionality rule; reproduce the old-service 0.7663% fee-share counterexample. |
| Fixed-price, eight-step reservation | Implement and settle in S1; long jobs consume consecutive tickets and carry state forward. |
| Balance-proportional update surcharge | Replace with one fixed update stamp; preserve the independent seniority loss from changing a bit. |
| Unbounded accelerating monetary difficulty | Reject: symbolic quadratic cost diverges. Bounded early acceleration remains a nonimplemented alternative. |
| Pay every copied forwarding claim | Reject: recipient approves one capped, signed chain, paid atomically from the original input. |
| Age is faster computation | Reject: cold work does not accelerate by waiting. Reuse comes from stored checked results. |
| Signature means finality | Reject: require live-input validation, unique consumption and the stated authority threshold. |


The S1 correction was deliberately incremental. It preserves the previously exercised exact-amount representation, interval accounting, service continuity, machine interpreter, result store and sign-once witness abstraction. It changes the tariff and ticket size, simplifies the update stamp, and adds a sender-capped echo-payment path. The original source remains unchanged; a unified patch is included.

No new S1 assertion failed during the recorded test runs. That fact does not erase the earlier observed reward counterexample or the known availability gaps. The study’s iteration is the explicit response to those measurements and to symbolic rejection of incompatible rules—not an invented story of dozens of successful redesigns.

> The simplified protocol
> One conserved principal. Three independent clocks. One bounded service ticket. One accepted courier chain. One certified consumption of each input. Reusable computation, but never reusable payment authority.



## Economic interpretation and limits

For a service class with fixed tariff p, comparable continuously available workers and a stable eligible snapshot, the age rule allocates a larger long-run fraction of ticket opportunities to an older equal-principal service. The finite experiments approach the ratio specified by their weights. This gives an operational meaning to valuable choice: a policy with a preserved history receives more opportunities to earn externally funded fees.

```text
gross fee share ≈ service weight / eligible total weight
net income = paid fees − real service and coordination costs
```

The approximation is a scheduling expectation under the stated workload, not a universal probability guarantee. Finite deterministic prefixes need not be perfectly proportional. A worker with twice the weight can still earn nothing when demand is absent, its role is ineligible, it is unreachable, the queue is blocked, or the recipient refuses to complete a payment.

### Why market purchasing power is not established

The ledger records Fire, not a basket of external goods. No experiment measured independent willingness to pay, exchange liquidity, real energy expenditure, customer retention or redemption. If all comparable choices age together, their relative weights stay unchanged. If rewards were simply minted to everyone for waiting, the increase in nominal balances would not by itself establish a larger command over scarce resources.

Aged paper may become attractive because a real service operator expects valuable funded work. That is an economic hypothesis requiring deployment evidence, not a price theorem proved by the Boolean game. S1’s owner-change reset also means a purchaser does not automatically buy another owner’s accumulated service seniority.

### Tradeoffs introduced by simplification

The fixed ticket reduces the specific variable-price manipulation, but charges the same reservation price for an early-halting computation, a full eight-step quantum and a cached delivery. This buys bounded capacity and verification, not identical physical effort. It removes v5’s automatic lower monetary charge for cache hits. Separate service classes could reintroduce realistic pricing, but then fairness must be analyzed within and across those classes.

The overlay’s chosen route can be longer than a globally optimal route. A receiver-approved cap limits the authorized loss to courier fees, but cannot prove that each relay was necessary. Self-payment transfers principal among related keys without creating net principal; it may nevertheless buy apparent activity or occupy service slots. No mechanism here proves honest identities or prevents every form of collusion.



## Deployment conditions and conclusion

| Required capability | Current status and acceptance criterion |
| --- | --- |
| Issuance / common asset | Test genesis only. Specify a recognized issuance rule and distribution before admitting live funds. |
| Independent consensus | Local reducer and witness stores only. Deploy independently validating replicas, recovery and membership changes. |
| Key custody / cryptography | Public test keys only. Replace them with secure custody and a reviewed signature suite; no post-quantum claim is made. |
| Time and availability | Harness-certified epochs. Define a secure epoch service and whether actual service evidence is required. |
| Cancellation and escrow recovery | Pending jobs may remain locked. Implement a certified, race-safe resolution without reusing spent authority. |
| Transport and retention | Logical contacts and local storage only. Add authenticated discovery, distribution, backups and resource limits. |
| Incentives and pricing | Controlled fixed-tariff experiment. Test real costs, strategic availability, demand, collusion and cross-class allocation. |


The research model uses Ed25519 signatures through the installed cryptography library. Signature verification detects the tested changes to signed messages, but public test keys intentionally provide no real-world secrecy or custody. EdDSA’s specification is a foundation, not a certification of this application. [R7]

### Conclusion

Fire Echos can be made coherent as an exact-principal, content-addressed money-state system with three aging service policies. The computational past supplies stable programs, origins and verified receipts. The present supplies an authorized transition. The future supplies a permitted continuation. Their interaction preserves useful choice without pretending to rewrite committed history.

The strongest new experimental result is an **integrated** reward correction: fixed-price bounded tickets restored the expected age-weighted share of gross fees in the tested adversarial workload while preserving exact principal. The separate signed-echo path demonstrated recipient-selected courier fees, atomic output construction and replay rejection. The symbolic and Boolean studies made the definitions explicit enough to test, simplify and reproduce.

> The final design principle
> Preserve choice as a service policy. Let its age weight funded opportunity. Preserve checked computation as history. Pay only an accepted, bounded obligation. When the evidence is insufficient, stop the transition rather than invent the account.



## Reproduce the evidence

The accompanying archive contains the new S1 source, a patch against v5, symbolic and integration tests, the unchanged baseline source, the prior reward audit, fresh JSON results and a source manifest. The environment pins reproduce this study; they are not a promise of ongoing production support. All included keys are publicly derivable test identities.

```text
python -m pip install -r requirements.txt
python reproduce.py
```

The runner executes independent commands and writes new results into a separate rerun directory. It does not overwrite the supplied evidence. A full rerun can take several minutes because it performs real signatures, database transactions, interpreter replay and repeated partition audits. Runtime depends on the machine and concurrent load.

| Key | Evidence file / experiment |
| --- | --- |
| E1 | results/v5_fresh_rerun.json — full v5 suite; 1,800-job mixed workload, seed 20260926. |
| E2 | results/v5_reward_rerun.json — original reward audit rerun; both 384-request experiments and the reproduced counterexample. |
| E3 | results/symbolic_results.json — SymPy identities, all Boolean tables, clock transitions and quorum-pair enumeration. |
| E4 | results/s1_results.json — S1 integrated reward test, continuation, reuse, safety, signed couriers and 800-ticket mixed workload. |
| E5 | results/s1_seed2.json — independent 600-ticket mixed workload, seed 20260929. |
| E6 | results/boolean_bridge_results.json — complete finite Boolean-machine bridge and eight paid branches. |


### Identity and integrity

S1 protocol identity (the manifest includes the implementation source hash):

b7e32bdc62883838380c82e25dbc824b987d3f90e1e3318e0b838d35229baf52

The original v5 identity is 2a8c0bb9fbfbe11305f6b42e43a803a3fabfe8c90d458d638134f2e7426cb836. A changed source or rule manifest is a changed protocol. Use fresh databases for changed rules. The supplied SHA256SUMS.json detects unintended file changes; it does not attest who authored an arbitrary replacement package.

Focused commands and experiment descriptions are in README.md. The reproduction runner uses the actual source paths in the archive, not the historical paths embedded in earlier reports. The white paper’s editable text is also included as WHITE_PAPER.md.



## Proof notes and minimal algorithms

### Conservation and non-cloning

Proof 1. Divide φ² = φ + 1 by φ². Then φ⁻¹ + φ⁻² = 1; multiplying by any admissible w gives a conserved fracture. Inductively, any finite sequence of valid fractures preserves the root’s total. The interval-coverage check additionally prevents overlap and omission.

Proof 2. For fixed choice ages, the density D = 6 − Σφ⁻ᵘⁱ does not depend on the number of descendants. Therefore (w₁ + w₂)D = w₁D + w₂D. Replacing one interval by disjoint descendants preserves its total scheduling mass. The stronger coordinate-invariance test assumes the same principal ordering and a fixed eligible snapshot.

### Selective reset

Proof 3. A reset replaces one gap gᵢ by 1 and leaves the other gaps unchanged. Thus Wbefore − Wafter = w(1 − gᵢ), or ΔMᵢ = w(1 − gᵢ)/3. This is nonnegative, increasing with age before the cap and bounded by w/3. Transfer fees reduce the remaining principal separately; the reset equation deliberately isolates the same-principal effect.

### One accepted courier chain

Proof 4. If an accepted chain has positive fees f₁…fₖ, sum F no greater than the sender’s cap and F < w, construct adjacent courier slices of lengths fᵢ and one recipient slice of length w − F. Their disjoint union is the original input interval. A single certified consumption then prevents a second chain from legally creating another set of descendants under the stated witness assumptions.

```text
validate offer signature and live input
validate each linked fee claim; enforce cap and hop bound
verify recipient signature over the selected complete chain
construct disjoint outputs; verify exact input coverage
obtain unique-consumption certificate
commit input removal, outputs and evidence atomically
```

### A symbolic simplification is not a universal semantic oracle

The 256 truth-table forms in E3 are canonical by their ordered eight outcomes. Distinct tables remain distinct regardless of how a Boolean expression is written. The 98,304 signed-cube checks verify relabeling round trips; scalar board input relabeling is not incorrectly called scalar-output conjugation. The moving-frame and machine-reflection examples use explicit genuine state-space transformations.

The finite board compiler, symbolic identities and runnable S1 protocol appear together so that a reader can distinguish algebraic proof, exhaustive finite evaluation and sampled state-machine execution. No unsupported synthesis of those three forms of evidence is required.



## Primary foundations and project sources

These references support established techniques and the earlier project context. They do not endorse Fire Echos or certify the new implementation. Empirical Fire Echos claims are sourced to the fresh evidence files on page 21.

[R1] SymPy documentation, “Logic,” and its simplification tutorial. Symbolic Boolean expressions, truth-table forms and exact expression manipulation. Documentation consulted for this study. https://docs.sympy.org/latest/modules/logic.html

[R2] A. Rundgren, B. Jordan and S. Erdtman. RFC 8785: JSON Canonicalization Scheme, 2020. Supports invariant serialized representation. S1 uses its own restricted encoding; cross-language JCS compliance is not claimed. https://www.rfc-editor.org/info/rfc8785/

[R3] M. Castro and B. Liskov. Practical Byzantine Fault Tolerance. OSDI, 1999. A replicated-state-machine foundation, substantially more complete than the simulator’s signing-store abstraction. https://www.usenix.org/conference/osdi-99/practical-byzantine-fault-tolerance

[R4] SQLite documentation. Atomic Commit in SQLite. Defines local transaction atomicity and its implementation assumptions; separate witness databases do not form one globally atomic file transaction. https://sqlite.org/atomiccommit.html

[R5] M. J. Fischer, N. A. Lynch and M. S. Paterson. Impossibility of Distributed Consensus with One Faulty Process. Journal of the ACM 32(2), 374–382, 1985. https://www.cs.princeton.edu/courses/archive/fall07/cos518/papers/flp.pdf

[R6] U. A. Acar, G. E. Blelloch and R. Harper. Selective Memoization. POPL, 2003. A primary foundation for controlled reuse and precise computational dependencies. https://www.cs.cmu.edu/~rwh/papers/memoization/popl.pdf

[R7] S. Josefsson and I. Liusvaara. RFC 8032: Edwards-Curve Digital Signature Algorithm (EdDSA), 2017. Signature algorithm specification and test vectors. https://www.rfc-editor.org/info/rfc8032/

[R8] A. Haeberlen, P. Aditya, R. Rodrigues and P. Druschel. Accountable Virtual Machines. OSDI, 2010. Related execution-accountability work; replay in this prototype is not a succinct remote computation proof. https://www.usenix.org/conference/osdi10/accountable-virtual-machines

**[P1]** Fire Echo φ Paper v5 — Preserved choices, funded execution, reusable history. Earlier project design and test report, 6 September 2026. Consulted with its actual source package, not treated as fresh experimental evidence.

**[P2]** Fire Echo — Independent Reward and Canon Audit. Earlier project audit, 6 September 2026. Its unchanged audit program was executed again for E2. The prior proposed ticket allocator was allocation-only; S1’s separate end-to-end implementation is documented here.

Interpretation of R8: accountable execution can be based on comparing recorded computation with an expected execution. S1’s trusted local checker and cached certificates remain narrower than a deployed independently verifiable execution service.
